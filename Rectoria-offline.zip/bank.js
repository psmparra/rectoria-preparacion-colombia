window.RECTORIA_BANK = {
  "version": 2,
  "source": "Simulacros 1, 2, 3 y 4 · cuadernillos y solucionarios originales",
  "verified": true,
  "verification": "560 claves y enunciados cotejados con sus documentos; sin duplicados integrales. Vigencia normativa no verificada.",
  "sources": [
    {
      "name": "Simulacro_Rector_2026_140_Preguntas.pdf",
      "sha256": "2b726b1ffbab19f3f1e257e319a8fc054957c68820f4a62b9d09084cd423e70b"
    },
    {
      "name": "Solucionario_Rector_140.pdf",
      "sha256": "38cf6409c43529fd8223f9343e16eaeb6f2e3a6749addb2906d25fa2f03e4101"
    },
    {
      "name": "Simulacro_Rector_2_140_Preguntas.pdf",
      "sha256": "0e63afee7a5a0d9da0e0e24ba9a123f1a0f7252e83829d1cdd742e0e7a8c4112"
    },
    {
      "name": "Simulacro_Rector_2_Solucionario_140.pdf",
      "sha256": "2ea3acfd5de21b685e5857fc4594c062c1875bdd77a1644319b4ce142a2655c7"
    },
    {
      "name": "Simulacro_Rector_3_140_Preguntas.pdf",
      "sha256": "8ec9e4d60d1e2163e2f30be9390d9f7150299eb0475da20435f88eb0e479c8c0"
    },
    {
      "name": "Simulacro_Rector_3_Solucionario_140.pdf",
      "sha256": "5c90ebe9f63a5dc4303ba53bc5359d564dcba0761cb83e3d0bbcb969c362df82"
    },
    {
      "name": "Simulacro_Rector_4_140_Preguntas.pdf",
      "sha256": "0d4102831a5e69b45dedc3065542369617d558c76c05a345f77278c00316b1ed"
    },
    {
      "name": "Simulacro_Rector_4_Solucionario_140.pdf",
      "sha256": "05b696c8996e330c859b2290a7efb5c7a72041f29bf45641e217408a2d8fd4e8"
    }
  ],
  "situations": [
    {
      "id": "01",
      "title": "Un PEI de papel y tres sedes desconectadas",
      "text": "Una institución oficial con tres sedes registra alta repitencia en sexto, deserción rural y diferencias profundas entre los planes de aula. El PEI fue actualizado formalmente hace cuatro años, pero sus metas no aparecen en los planes de mejoramiento ni en las decisiones sobre recursos. Un grupo docente pide autonomía absoluta para definir contenidos; las familias reclaman resultados y el Consejo Directivo propone aprobar de inmediato un nuevo PEI escrito por una consultora. Existen registros de matrícula, desempeños por período, encuestas de estudiantes y actas del gobierno escolar. El rector dispone de un trimestre para iniciar una transformación sin suspender el servicio.",
      "competency": "GESTIÓN DIRECTIVA"
    },
    {
      "id": "02",
      "title": "Consejo Directivo bajo presión",
      "text": "En una institución de 1.800 estudiantes, representantes de familias piden retirar una asignatura optativa y dedicar esas horas a preparación para pruebas externas. El Consejo Académico emitió un concepto en contra porque las competencias de formación integral quedarían afectadas. En la sesión siguiente, algunos integrantes del Consejo Directivo condicionan su aprobación del presupuesto a que el rector ejecute su propuesta curricular de inmediato. El acta registra opiniones, pero no existe un estudio de carga académica ni una revisión formal del plan de estudios. El rector debe intervenir sin desconocer los espacios de participación.",
      "competency": "GESTIÓN DIRECTIVA"
    },
    {
      "id": "03",
      "title": "Plan de mejoramiento sin aprendizaje",
      "text": "Las pruebas internas muestran que el nivel de lectura de octavo cayó durante dos años. El plan de mejoramiento institucional prevé cinco talleres sobre lectura para docentes y una feria literaria, pero no contiene línea de base, metas, responsables ni seguimiento. Una fundación ofrece donar libros si se publican fotografías de beneficiarios. Los docentes señalan que los textos no coinciden con las necesidades de comprensión inferencial detectadas. El rector recibe la exigencia de reportar una mejora al cierre del año y debe decidir con recursos limitados.",
      "competency": "GESTIÓN DIRECTIVA"
    },
    {
      "id": "04",
      "title": "Una decisión urgente y tres competencias distintas",
      "text": "Una sede presenta fallas eléctricas recurrentes. Los padres piden suspender todas las clases y construir una nueva aula, mientras los docentes solicitan adecuaciones temporales y el Consejo Directivo propone trasladar recursos del rubro destinado a textos escolares. El rector dispone de un informe técnico preliminar que identifica riesgo localizado en dos salones, pero no certifica que toda la sede sea insegura. La Secretaría de Educación no ha emitido aún concepto técnico definitivo. La institución puede reorganizar espacios y horarios mientras se tramitan acciones de mantenimiento.",
      "competency": "GESTIÓN DIRECTIVA"
    },
    {
      "id": "05",
      "title": "Ausentismo, clima laboral y funciones del rector",
      "text": "Un grupo de familias informa que varias clases no se desarrollaron durante tres semanas. El coordinador aporta registros parciales de horarios y ausencias, mientras un docente afirma que sustituyó las horas mediante guías autónomas. El sindicato pide evitar señalamientos sin prueba y la Secretaría de Educación solicita un reporte de continuidad del servicio. Parte de los estudiantes no tuvo acceso a las guías digitales. El rector debe diferenciar seguimiento al servicio, gestión de personal y eventuales actuaciones disciplinarias.",
      "competency": "GESTIÓN DIRECTIVA"
    },
    {
      "id": "06",
      "title": "Ajustes del PEI ante una nueva realidad territorial",
      "text": "Una institución urbana recibe durante el año escolar estudiantes provenientes de zonas rurales y de familias en movilidad. El PEI enfatiza proyectos productivos urbanos y carece de estrategias claras de acogida, nivelación o participación familiar. Las docentes proponen flexibilizar metodologías y evaluar competencias iniciales; algunos directivos sugieren crear grupos separados permanentes para recién llegados. La entidad territorial advierte limitaciones de planta y oferta de apoyos. El rector debe responder de inmediato y proponer ajustes de mediano plazo.",
      "competency": "GESTIÓN DIRECTIVA"
    },
    {
      "id": "07",
      "title": "Promoción anticipada bajo presión",
      "text": "En el primer período académico, la familia de una estudiante de séptimo solicita promoción anticipada. La estudiante demuestra desempeño superior en las competencias del grado y tiene evidencias favorables en convivencia y autonomía. Dos docentes apoyan la solicitud, pero argumentan que toda promoción automática debe depender del promedio aritmético; otra docente propone esperar al último período para evitar vacíos. El SIEE contiene un procedimiento de valoración integral para estos casos. La familia acepta aportar evidencias y participar en el proceso.",
      "competency": "GESTIÓN ACADÉMICA"
    },
    {
      "id": "08",
      "title": "El SIEE como garantía y no como obstáculo",
      "text": "Un colegio exhibe elevada reprobación en matemáticas. Algunas familias denuncian que los criterios para recuperación cambiaron después de conocerse las notas, mientras docentes alegan que flexibilizarlos reduciría exigencia académica. El SIEE establece seguimiento permanente, estrategias de apoyo y mecanismos de reclamación, pero no se ha socializado durante el año. El rector tiene actas del Consejo Académico, resultados por competencia, muestras de evaluaciones y reclamaciones pendientes. Se requiere recuperar confianza sin desautorizar la evaluación profesional.",
      "competency": "GESTIÓN ACADÉMICA"
    },
    {
      "id": "09",
      "title": "PIAR y derecho a la educación",
      "text": "Una estudiante con discapacidad intelectual ingresa a grado quinto y sus docentes manifiestan que no tienen experiencia con ajustes curriculares. La familia aporta un informe clínico, pero el colegio dispone principalmente de observaciones pedagógicas. El Consejo Académico propone que asista a todas las actividades, aunque sea evaluada únicamente por presencia; otro equipo pide esperar un nuevo diagnóstico médico antes de construir apoyos. El aula cuenta con oportunidades de aprendizaje cooperativo, materiales manipulativos y apoyos pedagógicos posibles.",
      "competency": "GESTIÓN ACADÉMICA"
    },
    {
      "id": "10",
      "title": "Lectura crítica de resultados externos",
      "text": "En un establecimiento de educación media, el promedio de una evaluación externa subió tres puntos, pero el porcentaje de estudiantes que presenta la prueba cayó del 94 % al 76 %. Un coordinador celebra una mejora histórica; un equipo docente observa que varios estudiantes con dificultades de aprendizaje desertaron o no fueron inscritos en la cohorte medida. La institución posee indicadores de asistencia, permanencia, desempeños internos y distribución de resultados. El rector debe presentar un informe a Consejo Directivo sin manipular ni negar el avance observado.",
      "competency": "GESTIÓN ACADÉMICA"
    },
    {
      "id": "11",
      "title": "Innovación sin criterio de evaluación",
      "text": "Una empresa ofrece una plataforma de inteligencia artificial para personalizar tareas en secundaria durante un semestre. Promete elevar resultados en 30 %, pero no presenta estudios aplicables al contexto. Los estudiantes cuentan con acceso digital desigual, existen dudas sobre tratamiento de datos y el PEI enfatiza aprendizaje colaborativo. Varios docentes desean explorar su utilidad, mientras familias piden garantías. El rector dispone de indicadores de logro y una experiencia piloto previa con recursos digitales básicos.",
      "competency": "GESTIÓN ACADÉMICA"
    },
    {
      "id": "12",
      "title": "Reorganización de horarios con enfoque académico",
      "text": "Dos docentes de ciencias se retiran temporalmente y quedan 14 grupos sin la intensidad horaria originalmente prevista. El coordinador propone reducir horas de áreas artísticas por cuatro semanas; los representantes estudiantiles reclaman equilibrio formativo y la Secretaría de Educación revisa alternativas de provisión. El rector conoce la carga de cada docente, el plan de estudios vigente, las posibilidades de laboratorios y las metas de aprendizaje. No puede contratar personal por cuenta propia, pero puede reorganizar recursos institucionales dentro de sus competencias.",
      "competency": "GESTIÓN ACADÉMICA"
    },
    {
      "id": "13",
      "title": "Recursos del FSE y urgencia pedagógica",
      "text": "Una institución cuenta con recursos del Fondo de Servicios Educativos (FSE) para dotación de aula y mantenimiento. Una inundación daña veinte computadores y parte de los materiales de laboratorio. Un proveedor ofrece equipos con entrega inmediata a cambio de un anticipo, mientras el Consejo Directivo no ha aprobado ajustes al presupuesto vigente. Algunos docentes piden comprar sin demora para recuperar clases. El rector es ordenador del gasto, pero reconoce que las adquisiciones están sometidas a reglas presupuestales y contractuales y que el FSE no tiene personería jurídica propia.",
      "competency": "GESTIÓN ADMINISTRATIVA"
    },
    {
      "id": "14",
      "title": "Una contratación aparentemente conveniente",
      "text": "Una empresa propone mantenimiento de redes por un valor ligeramente inferior al presupuesto disponible. El representante es familiar de un integrante del Consejo Directivo que ha participado en discusiones previas sobre el proyecto. La oferta incluye soporte por doce meses, pero carece de especificaciones técnicas comparables con otras propuestas. El rector teme que un proceso más riguroso demore el servicio y que al pedir una declaración de posibles conflictos aumente la tensión institucional.",
      "competency": "GESTIÓN ADMINISTRATIVA"
    },
    {
      "id": "15",
      "title": "Evaluación de desempeño y debido proceso",
      "text": "Un rector identifica dificultades persistentes en planeación y evaluación de un docente. Durante el año se han realizado observaciones de aula y reuniones informales, pero no hay retroalimentaciones escritas suficientes ni compromisos de mejora documentados. Algunas familias exigen una calificación desfavorable inmediata. El docente solicita conocer las evidencias y los criterios utilizados. La institución dispone de un cronograma de evaluación del desempeño y protocolos del régimen aplicable.",
      "competency": "GESTIÓN ADMINISTRATIVA"
    },
    {
      "id": "16",
      "title": "Dotación accesible y restricciones presupuestales",
      "text": "Una sede tiene barreras físicas para un estudiante que utiliza silla de ruedas. Las rutas de acceso a la biblioteca son estrechas y dos salones quedan en el segundo nivel sin ascensor. Hay una pequeña partida de mantenimiento y una solicitud de obras mayores ante la entidad territorial. Algunos docentes proponen que el estudiante reciba todas las clases en un aula fija; la familia plantea alternativas que favorezcan su participación con el grupo. El rector debe equilibrar seguridad, gestión de recursos y derecho de acceso.",
      "competency": "GESTIÓN ADMINISTRATIVA"
    },
    {
      "id": "17",
      "title": "Información de estudiantes y transparencia",
      "text": "Un periodista solicita a la institución estadísticas sobre ausentismo, deserción y violencia escolar durante tres años. En una hoja de cálculo entregada por coordinación figuran nombres, diagnósticos de salud, teléfonos y descripciones detalladas de conflictos de estudiantes. La alcaldía ha pedido reportes agregados para formular programas preventivos. El Consejo Directivo propone publicar toda la base porque la escuela recibe recursos públicos. El rector debe conciliar rendición de cuentas, protección de menores y utilidad pública de la información.",
      "competency": "GESTIÓN ADMINISTRATIVA"
    },
    {
      "id": "18",
      "title": "Acoso repetido con riesgo de represalias",
      "text": "Una estudiante reporta cuatro semanas de hostigamiento sistemático por un grupo de compañeros y difusión de mensajes humillantes. No se ha comunicado violencia sexual ni una conducta penal identificada; existe afectación emocional y temor de represalias. El director de grupo propone un acuerdo restaurativo inmediato frente a todo el curso, mientras la madre solicita medidas de protección y confidencialidad. El colegio ha documentado los incidentes y cuenta con Comité Escolar de Convivencia y manual actualizado.",
      "competency": "GESTIÓN COMUNITARIA"
    },
    {
      "id": "19",
      "title": "Indicio de violencia sexual en contexto escolar",
      "text": "Una adolescente comunica a la orientadora que un adulto vinculado temporalmente a actividades del colegio le habría realizado contactos físicos de contenido sexual. Manifiesta miedo y pide que no se informe a nadie. La orientadora comunica al rector la información esencial para activar protección, sin realizar entrevistas repetidas. Un miembro del equipo directivo propone abrir primero una investigación interna para decidir si existe mérito suficiente antes de llamar a las autoridades. El rector desconoce si el adulto continúa en contacto con estudiantes.",
      "competency": "GESTIÓN COMUNITARIA"
    },
    {
      "id": "20",
      "title": "Familias, participación y corresponsabilidad",
      "text": "El colegio implementa un plan contra el ausentismo. Algunas familias solicitan encuentros fuera de la jornada laboral, docentes advierten que no pueden extender todas las jornadas, y un representante de padres propone publicar semanalmente nombres de estudiantes ausentes para incentivar el cumplimiento. El registro revela que el ausentismo se concentra en dos barrios donde hay dificultades de transporte y cuidado familiar. La asociación de padres ofrece apoyar una estrategia de comunicación comunitaria, mientras el Consejo Directivo exige resultados medibles.",
      "competency": "GESTIÓN COMUNITARIA"
    },
    {
      "id": "21",
      "title": "Conflicto docente-familia con posible discriminación",
      "text": "Una familia afirma que durante una actividad un docente ridiculizó el acento regional de un estudiante recién matriculado. El docente sostiene que intentaba corregir una lectura y niega intención discriminatoria. Compañeros aportan versiones parcialmente distintas, y el estudiante pide que no se convierta el asunto en una discusión pública. El rector dispone de registros de clase, un canal formal de quejas y el equipo de orientación. La comunidad reclama una respuesta rápida, respetuosa de los derechos del estudiante y de las garantías del docente.",
      "competency": "GESTIÓN COMUNITARIA"
    },
    {
      "id": "22",
      "title": "Deserción y alianza interinstitucional",
      "text": "En grado noveno aumenta el abandono escolar entre estudiantes que cuidan hermanos menores mientras sus cuidadores trabajan. Un diagnóstico participativo señala dificultades de transporte, horarios familiares y baja percepción de pertinencia de algunos contenidos. Una ONG ofrece talleres de orientación y la alcaldía podría apoyar rutas de acceso, pero ninguna entidad ha confirmado compromisos formales. El rector cuenta con equipo de orientación, Consejo Directivo y representantes estudiantiles para actuar.",
      "competency": "GESTIÓN COMUNITARIA"
    },
    {
      "id": "23",
      "title": "Presión política sobre una decisión curricular",
      "text": "Una autoridad local pide al rector incluir una campaña institucional con símbolos personales durante la ceremonia de grados. Argumenta que ha gestionado mejoras de infraestructura y su presencia facilita futuros apoyos. Docentes y familias desean agradecer la cooperación, pero varios estudiantes expresan incomodidad con una promoción que podría interpretarse como partidista. El acto tiene fines académicos y se financia con recursos institucionales. El rector debe preservar relaciones con el territorio sin comprometer la neutralidad y la finalidad educativa.",
      "competency": "COMPETENCIAS BLANDAS"
    },
    {
      "id": "24",
      "title": "Dos coordinadores en desacuerdo",
      "text": "En una institución grande, dos coordinadores discrepan sobre el seguimiento a planeaciones. Uno defiende observaciones frecuentes con listas uniformes; la otra propone acompañamiento colaborativo y reconocimiento de la diversidad de áreas. La discusión se volvió personal y docentes perciben instrucciones contradictorias. El rector conoce que ambos enfoques contienen elementos útiles, pero la institución carece de protocolo común de seguimiento pedagógico. Debe decidir sin reforzar bandos.",
      "competency": "COMPETENCIAS BLANDAS"
    },
    {
      "id": "25",
      "title": "Error propio del rector en un reporte",
      "text": "El rector detecta que el informe enviado a la entidad territorial duplicó accidentalmente las cifras de participación familiar y presentó como terminado un taller aún pendiente. El error no alteró recursos girados, pero pudo influir en una comparación de gestión entre instituciones. Un asesor sugiere esperar a que alguien lo advierta y otro propone publicar de inmediato un comunicado con explicaciones extensas sin verificar los registros. El rector conserva los soportes originales y puede corregir el reporte formal.",
      "competency": "COMPETENCIAS BLANDAS"
    },
    {
      "id": "26",
      "title": "Decisión bajo información incompleta",
      "text": "Un rumor en redes afirma que el comedor escolar entregó alimentos en mal estado. Se conoce un caso de malestar estomacal, sin confirmación de causa, y existen fotografías de un producto de fecha legible pero sin cadena de custodia. El operador de alimentación afirma que todos los controles están al día. Varias familias exigen cerrar el comedor y otras recuerdan que muchos estudiantes dependen del servicio. El rector tiene acceso a protocolos, registros de recepción y contacto con autoridades sanitarias.",
      "competency": "COMPETENCIAS BLANDAS"
    },
    {
      "id": "27",
      "title": "Lectura crítica: el indicador que oculta ausencias",
      "text": "El comité de calidad presentó este fragmento: «La matrícula de octavo aumentó de 300 a 330 estudiantes, mientras el número de estudiantes con más del 20 % de ausencias pasó de 30 a 36. El informe concluye que la estrategia de permanencia fue exitosa porque el 90 % del estudiantado no superó el umbral de inasistencia el primer año y el 89,09 % no lo superó el segundo. El texto añade que la política debe ampliarse sin nuevas mediciones, debido a que el número de estudiantes matriculados creció». En el archivo de seguimiento no aparecen datos de traslados, motivos de ausencia ni distribución por sede. El rector debe interpretar el argumento antes de decidir recursos.",
      "competency": "LECTURA CRÍTICA"
    },
    {
      "id": "28",
      "title": "Lectura crítica: circular y alcance normativo",
      "text": "Una circular hipotética de trabajo para el ejercicio plantea: «Los cambios ordinarios en la distribución de espacios deberán ser coordinados por rectoría y comunicados oportunamente a los equipos involucrados. Cuando existan riesgos inminentes para la integridad de personas, se podrán adoptar medidas de protección provisionales de inmediato y se documentará la razón que impidió completar el trámite ordinario. Toda medida deberá revisarse tan pronto desaparezca la urgencia». El texto es una pieza construida para el simulacro, no una norma colombiana vigente. Una coordinadora propone interpretarlo como autorización permanente para cualquier cambio de infraestructura si se invoca prevención.",
      "competency": "LECTURA CRÍTICA"
    },
    {
      "id": "29",
      "title": "Lectura crítica: dos formas de explicar resultados",
      "text": "Un documento de discusión institucional afirma: «En los cursos donde docentes realizaron tutorías voluntarias, la tasa de aprobación fue de 92 %. En los cursos sin tutorías fue de 78 %. Los primeros cursos tenían, desde el comienzo del período, mejores resultados de lectura y menor ausentismo. Por tanto, es correcto afirmar que las tutorías causaron por sí solas una mejora de catorce puntos porcentuales». La rectoría conserva datos iniciales de los cursos, aunque no existió asignación aleatoria de tutorías. La propuesta de mejora pretende extender el programa al siguiente año.",
      "competency": "LECTURA CRÍTICA"
    },
    {
      "id": "30",
      "title": "Lectura crítica: derechos, límites y condiciones",
      "text": "El consejo estudiantil redacta una propuesta: «Todo estudiante debe poder expresar inquietudes sobre la evaluación sin temor a represalias. Sin embargo, el reclamo tendrá que basarse en evidencias, respetar la dignidad de otros y dirigirse por los canales institucionales. La apertura a la crítica no exime de atender acuerdos de convivencia». Una directiva lee la propuesta como autorización para cuestionar públicamente la idoneidad profesional de cualquier docente sin aportar pruebas. Otra persona interpreta que solo puede reclamar quien haya obtenido una nota reprobatoria.",
      "competency": "LECTURA CRÍTICA"
    },
    {
      "id": "31",
      "title": "Lectura crítica: de la observación a la generalización",
      "text": "En un informe institucional se lee: «De 120 estudiantes de media, 30 participaron voluntariamente en un club de debate. Entre sus participantes, 25 reportaron mayor confianza para hablar en público. El informe concluye que el club mejora la confianza de la totalidad de los estudiantes y debe reemplazar obligatoriamente otras actividades de formación oral». El cuestionario fue contestado únicamente por participantes y no se aplicó una medición previa. Existe una propuesta de ofrecer experiencias distintas según necesidades e intereses.",
      "competency": "LECTURA CRÍTICA"
    },
    {
      "id": "32",
      "title": "Razonamiento cuantitativo: ausentismo por sedes",
      "text": "La institución tiene dos sedes. En la sede Norte estudian 240 alumnos y 30 presentan inasistencia superior al 20 % de las clases. En la sede Sur estudian 160 alumnos y 12 cumplen esa misma condición. El equipo rectoral desea reducir la tasa consolidada de alta inasistencia hasta un máximo del 9 % de la matrícula total, que se supone constante durante el período evaluado. Los 42 casos actuales están contados una sola vez cada uno y no existen duplicidades. Para este ejercicio, «tasa de alta inasistencia» equivale al número de estudiantes que superan el umbral dividido entre la matrícula correspondiente.",
      "competency": "RAZONAMIENTO CUANTITATIVO"
    },
    {
      "id": "33",
      "title": "Razonamiento cuantitativo: progreso y cobertura",
      "text": "Un programa de apoyo lector tuvo 200 estudiantes inscritos durante el primer año; 130 alcanzaron la competencia esperada. Al año siguiente participaron 180 estudiantes y 126 alcanzaron la meta. El informe afirma que el programa «empeoró porque hubo cuatro estudiantes exitosos menos». La meta de la rectoría para el siguiente ciclo, suponiendo nuevamente 180 estudiantes, será alcanzar por lo menos el 75 % de logro. Los criterios de evaluación fueron equivalentes entre años y no se dispone de información para atribuir causalidad al programa.",
      "competency": "RAZONAMIENTO CUANTITATIVO"
    },
    {
      "id": "34",
      "title": "Razonamiento cuantitativo: presupuesto y contingencia",
      "text": "Para un ejercicio de priorización se dispone de un presupuesto hipotético de 48 millones de pesos, sin compromisos anteriores. Las necesidades evaluadas suman: dotación didáctica por 18 millones, ajustes de accesibilidad por 12 millones y reparaciones por 14 millones. El comité técnico recomienda conservar una reserva operativa no comprometida equivalente por lo menos al 10 % del total, aunque esa reserva constituye únicamente una condición del ejercicio y no una obligación normativa. Cualquier asignación debe además cumplir el trámite presupuestal y contractual aplicable; en este caso se comparan únicamente montos.",
      "competency": "RAZONAMIENTO CUANTITATIVO"
    },
    {
      "id": "35",
      "title": "Razonamiento cuantitativo: seguimiento de cohorte",
      "text": "Una cohorte comenzó décimo con 250 estudiantes. Durante el año, 20 se trasladaron formalmente a otros establecimientos y se confirmó su continuidad educativa; 15 abandonaron sin traslado documentado y 215 permanecieron en el colegio hasta finalizar. Para evaluar abandono en la cohorte que estuvo bajo seguimiento institucional después de excluir traslados confirmados, el equipo adopta explícitamente un denominador de 230 estudiantes. La tasa de permanencia interna sobre la matrícula inicial sigue siendo un indicador distinto. Las categorías son mutuamente excluyentes.",
      "competency": "RAZONAMIENTO CUANTITATIVO"
    },
    {
      "id": "36",
      "title": "Razonamiento cuantitativo: méritos y ponderaciones",
      "text": "En un ejercicio de cálculo de puntaje final, una aspirante a rector obtiene 92,00 en Aptitudes y Competencias Básicas; 88,00 en psicotécnica; 56,00 en la escala interna de valoración de antecedentes; y 91,00 en entrevista. Las ponderaciones del concurso son, respectivamente, 55 %, 10 %, 25 % y 10 %. Las cuatro pruebas se miden en escala de 0 a 100 antes de ponderarse. En un segundo escenario hipotético se mantiene antecedentes en 56, psicotécnica en 90 y entrevista en 90, y se pregunta qué nota principal permite alcanzar un total de 85 puntos. Estos cálculos ilustran la ponderación; no predicen puestos en una lista de elegibles.",
      "competency": "RAZONAMIENTO CUANTITATIVO"
    },
    {
      "id": "37",
      "title": "Una alerta ambiental y la continuidad educativa",
      "text": "En un colegio de cuatro sedes, una quebrada cercana presenta creciente súbita en temporada de lluvias. Un reporte comunitario señala afectación potencial de la vía de acceso a una sede; no hay alerta oficial de inundación general. Cuarenta estudiantes utilizan transporte escolar y otros llegan a pie. El Consejo Directivo dispone de un plan de gestión del riesgo desactualizado y el coordinador propone esperar la visita de una autoridad antes de cambiar cualquier operación. Familias de la zona aportan observaciones recientes y existen rutas alternas parcialmente verificadas.",
      "competency": "INTEGRACIÓN DIRECTIVA"
    },
    {
      "id": "38",
      "title": "Una decisión académica que genera conflicto jurídico",
      "text": "Un estudiante con dificultades de regulación emocional recibe una calificación reprobatoria porque se retiró del salón tras un conflicto. El docente argumenta que la convivencia incide en la evaluación integral; la familia sostiene que nunca se aplicaron instrumentos académicos equivalentes ni los apoyos pactados. El SIEE diferencia desempeño académico y conductas de convivencia, aunque contempla valoración integral y apoyos. Los hechos del conflicto se investigan por ruta separada y el rector debe evitar que una situación afecte indebidamente el derecho a la evaluación.",
      "competency": "INTEGRACIÓN DIRECTIVA"
    },
    {
      "id": "39",
      "title": "Datos institucionales e interpretación de una mejora",
      "text": "La rectoría evalúa dos sedes con contextos distintos. En la sede A, 60 de 100 estudiantes superaron una competencia en la línea de base y 78 de 100 lo lograron luego de un plan. En la sede B, 30 de 50 alcanzaron inicialmente la competencia y 36 de 50 lo hicieron después. El equipo quiere reconocer avances, pero los docentes de B sostienen que su incremento absoluto de seis estudiantes no debe compararse con el de dieciocho de A sin considerar el tamaño. Los grupos se mantuvieron estables y los instrumentos son comparables, pero no existe grupo de control.",
      "competency": "INTEGRACIÓN DIRECTIVA"
    },
    {
      "id": "40",
      "title": "Revisión integral de una decisión rectoral",
      "text": "Una institución pretende extender su jornada mediante actividades de lectura y proyectos comunitarios. La propuesta responde a necesidades detectadas en sexto, pero aún no ha considerado disponibilidad de docentes, alimentación, transporte, planeación curricular ni consulta a órganos escolares. Una fundación ofrece apoyo por seis meses, sujeto a compromisos de ejecución inmediatos. El rector debe presentar una hoja de ruta que no prometa competencias que pertenecen a la entidad territorial ni confunda convenio con autorización automática de cambios en la prestación del servicio.",
      "competency": "INTEGRACIÓN DIRECTIVA"
    },
    {
      "id": "S2-01",
      "title": "Transporte en ruta inundable",
      "text": "La ruta escolar rural atraviesa un tramo inundado durante lluvias intensas y existen reportes de incidentes. Las crecidas son intermitentes y el calendario académico se ha visto afectado varias veces. El operador solicita instrucciones, mientras las familias temen que medidas improvisadas aumenten el riesgo en el trayecto. El cronograma académico resulta vulnerable a nuevas interrupciones y los responsables operativos solicitan instrucciones claras. Las familias reclaman información oportuna acerca de las condiciones de seguridad y de las alternativas disponibles.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-02",
      "title": "Migración en mitad de período",
      "text": "Tres estudiantes recién llegados requieren cupos y ajustes de integración; algunos grupos argumentan que dañarán el promedio escolar. Las trayectorias anteriores son diversas y algunas familias no pueden aportar certificados completos de manera inmediata. El establecimiento teme conflictos por ubicación de grado y requiere un mecanismo académico de acogida. El equipo docente conoce parte de los hechos, aunque carece de toda la información familiar. La propuesta será examinada por quienes tienen a cargo protección, matrícula y acompañamiento pedagógico.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-03",
      "title": "Nota por disciplina",
      "text": "Un docente reduce automáticamente la nota de matemáticas por llegar tarde, sin relación con desempeños evaluables de la asignatura. La familia admite las llegadas tarde y solicita que la valoración de conocimientos se realice con los criterios anunciados. El docente sostiene que la sanción fortalece hábitos, pero no identifica un indicador de desempeño matemático afectado. El Consejo Académico pidió revisar los documentos institucionales y los registros concretos de desempeño. El calendario de publicación de resultados exige actuar con oportunidad sin reemplazar el juicio pedagógico por una medida disciplinaria.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-04",
      "title": "Simulacro de evacuación fallido",
      "text": "Una evacuación dejó a estudiantes de movilidad reducida sin apoyos y el informe propone repetir exactamente el ejercicio. El ejercicio ocurrió durante la jornada ordinaria y las observaciones incluyen cuellos de botella en escaleras. El plan de evacuación asigna responsabilidades genéricas y varias personas no conocen sus tareas. La situación afecta de modo desigual a los grupos y exige coordinar actores internos y externos. Antes de divulgar nuevas medidas, la institución debe distinguir entre riesgos identificados, acciones preventivas y soluciones todavía pendientes.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-05",
      "title": "Escuela de padres punitiva",
      "text": "La institución propone multar automáticamente a las familias que no puedan asistir a talleres, sin revisar circunstancias. Los acudientes apoyan los talleres, aunque cuestionan una medida que castigaría a quienes cuidan familiares enfermos o carecen de transporte. Existe un espacio participativo para acordar compromisos y modalidades de asistencia. Una propuesta externa ofrece beneficios importantes, aunque sus condiciones no han sido discutidas por todos los actores afectados. Los docentes esperan continuidad curricular y las organizaciones comunitarias solicitan claridad sobre compromisos.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-06",
      "title": "Objetivo anual inalcanzable",
      "text": "Una institución establece que toda la población alcanzará nivel avanzado en lectura en tres meses, sin diagnóstico ni recursos diferenciales. La propuesta provino de una jornada de motivación y tuvo respaldo general, aunque se desconoce el punto de partida de los grupos. La institución dispone de una cohorte con rezago persistente y desea definir apoyos escalonados sin renunciar a expectativas elevadas. Las sedes recopilaron información mediante instrumentos distintos y el equipo de calidad advierte que los resultados pueden no ser comparables. La dirección necesita sustentar prioridades sin convertir el proceso en un trámite documental.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-07",
      "title": "Violencia intrafamiliar sospechada",
      "text": "Un estudiante relata episodios de violencia familiar y pide que nadie intervenga; un docente cree suficiente remitirlo a lectura reflexiva. El relato incluye hechos que podrían continuar fuera del establecimiento y el estudiante expresa temor por su seguridad. Varios integrantes del equipo consideran que primero debe comprobarse cada detalle con la familia señalada. La situación plantea obligaciones simultáneas de acceso educativo, cuidado y comunicación institucional. Algunas medidas podrían parecer eficientes a corto plazo, pero generar consecuencias de exclusión o de tratamiento inadecuado.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-08",
      "title": "Material único para multigrado",
      "text": "La coordinación distribuye una sola guía para grados primero a quinto de una sede multigrado, sin diferenciación de objetivos. Las edades y experiencias de los estudiantes presentan diferencias importantes y una misma actividad termina en minutos para unos y resulta inaccesible para otros. El docente solicita una guía de organización que respete la progresión curricular. Los docentes tienen experiencias diferentes con la propuesta y aún no acuerdan criterios comunes de seguimiento. La rectoría busca que la innovación responda a una necesidad formativa concreta y no dependa únicamente del entusiasmo inicial.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-09",
      "title": "Escalas sin equivalencia",
      "text": "Una estudiante trasladada desde otra institución llega con una escala distinta y la coordinación pretende asignarle el promedio más bajo. El certificado de origen describe cuatro niveles de desempeño y la institución receptora emplea categorías distintas. La estudiante debe incorporarse a la evaluación del período corriente sin que la conversión se utilice como castigo por movilidad. Los resultados disponibles son heterogéneos y corresponden a estudiantes con trayectorias distintas. El equipo directivo debe resolver una reclamación sin generar precedentes incompatibles con los criterios de promoción previamente comunicados.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-10",
      "title": "Elección estudiantil impugnada",
      "text": "Una candidatura a personería denuncia que la comisión electoral publicó nuevas condiciones cuando el proceso de votación ya estaba en marcha. El recurso se presentó antes de divulgar los resultados finales y contiene capturas de una circular fechada después del cierre de inscripciones. Varios candidatos piden continuar el proceso para no afectar el calendario institucional, mientras otros reclaman igualdad de condiciones. El asunto se presentó como una solución inmediata a una necesidad reconocida, aunque algunos participantes expresaron reservas sobre la forma de decidir. Hay interés en preservar la continuidad del servicio y la confianza en los órganos colegiados.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-11",
      "title": "Cobertura de alimentación",
      "text": "El reporte de PAE muestra 168 raciones entregadas de 210 previstas el lunes y 184 de 230 el martes. La entidad territorial solicita una cifra consolidada para verificar servicio y una explicación de las raciones faltantes. La institución cuenta con programación diaria y registros de entrega por fecha. El informe será utilizado para comparar períodos o sedes y sus responsables piden explicitar los denominadores empleados. Es necesario distinguir porcentajes, cambios absolutos y resultados relativos antes de presentar conclusiones a la comunidad.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-12",
      "title": "Agresión con posible delito",
      "text": "La coordinación detecta señales de una agresión grave y propone que el comité de convivencia resuelva todo con un acuerdo privado. Existen indicadores que pueden requerir intervención de instancias externas y la familia pide privacidad. Los docentes desean resolver pronto el conflicto, pero desconocen si una conciliación escolar bastaría para atender sus consecuencias. Los testimonios disponibles presentan diferencias y aún deben contrastarse con información obtenida sin presiones. Varias personas solicitan una decisión inmediata y otras advierten sobre la posibilidad de exponer nuevamente a quienes resultaron afectados.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-13",
      "title": "Donación con costo oculto",
      "text": "Una firma ofrece tabletas gratis, pero exige asumir licencias privadas anuales no contempladas en el presupuesto. El precio inicial resulta atractivo, pero las licencias dependen de un proveedor único y deben renovarse cada año. Una sede carece de conectividad estable y la administración desconoce los costos de soporte y reposición. La necesidad fue presentada como urgente por los responsables de sede y el equipo administrativo propuso caminos diferentes. Los registros del fondo permiten reconstruir autorizaciones, disponibilidad y compromisos si se revisan de manera conjunta.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-14",
      "title": "Escuela y cabildo indígena",
      "text": "Familias indígenas solicitan incorporar saberes territoriales en un proyecto educativo y participar en su diseño. El trabajo propuesto se relaciona con prácticas agrícolas y memoria local. Los docentes buscan articularlo con desempeños del grado y la comunidad solicita que sus aportes no queden reducidos a una visita ceremonial. El encuentro inicial permitió identificar necesidades, pero no produjo un consenso sobre responsabilidades ni formas de seguimiento. La institución debe evitar que la participación se reduzca a divulgar decisiones ya adoptadas.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-15",
      "title": "Confusión entre acceso y uso",
      "text": "La rectoría informa: 'El 100 % de sedes recibió computadores; por consiguiente, todos los estudiantes desarrollaron competencias digitales'. Las actas de entrega están completas y los equipos se encuentran en inventario. Sin embargo, el informe no ofrece datos de frecuencia de uso, participación ni valoración de competencias digitales. El texto se discutirá en un espacio de participación en el que algunas personas respaldan su recomendación por experiencia directa. La revisión exige valorar la fuerza de la inferencia sin descartar automáticamente los registros aportados.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-16",
      "title": "Lectura mecánica en secundaria",
      "text": "Los docentes reportan que estudiantes resumen bien textos, pero fallan al reconocer supuestos y evaluar argumentos. En evaluaciones recientes los grupos detectaron la idea principal de textos informativos, pero confundieron conclusiones y evidencias en artículos de opinión. El equipo de lenguaje requiere intervenciones observables en tareas de aula. La iniciativa cuenta con respaldo de algunos equipos de área y reservas de quienes esperan evidencias de aprendizaje. El presupuesto admite ajustes limitados y la decisión deberá explicar qué cambio didáctico se busca observar.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-17",
      "title": "Compra fraccionada",
      "text": "El proveedor ofrece dividir una adquisición única de mobiliario en tres facturas para reducir trámites. El proveedor asegura que la división permite entregas rápidas y compromete recursos de una misma necesidad institucional. Las cotizaciones se obtuvieron en una sola negociación y los bienes se usarán durante el mismo período académico. La necesidad fue presentada como urgente por los responsables de sede y el equipo administrativo propuso caminos diferentes. Los registros del fondo permiten reconstruir autorizaciones, disponibilidad y compromisos si se revisan de manera conjunta.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-18",
      "title": "Aula segregada por comodidad",
      "text": "El rector recibe petición para ubicar sistemáticamente a estudiantes con discapacidad en un salón aparte y facilitar planeación. La propuesta fue presentada como forma de facilitar el trabajo docente y liberar espacios del aula regular. Algunas familias discrepan, pues observan que sus hijos dejarían de compartir proyectos, recreos y experiencias de aprendizaje con sus pares. Los apoyos actuales presentan diferencias entre sedes y jornadas que pueden afectar la continuidad educativa. La rectoría requiere una decisión articulada con docentes, familias y responsables administrativos sin sustituir valoraciones especializadas.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-19",
      "title": "Captura difundida en redes",
      "text": "Un estudiante denuncia hostigamiento digital y aporta capturas; un docente propone difundirlas en el grupo de familias para identificar responsables. Las imágenes incluyen números telefónicos y comentarios que permitirían identificar a las personas involucradas. La familia afectada pide medidas de protección y varios compañeros ya están compartiendo versiones parciales del incidente. El caso circuló informalmente entre integrantes de la comunidad, lo que incrementó las preocupaciones por confidencialidad. La dirección necesita distinguir las actuaciones escolares de aquellas que corresponden a otras autoridades y servicios.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-20",
      "title": "Red social con fotos de menores",
      "text": "El colegio promueve actividades mediante fotografías nominales de estudiantes sin tener claridad sobre autorizaciones. La actividad celebrada es legítima, aunque el material difundido incluye rostros reconocibles y etiquetas nominales. Los docentes plantean que una publicación institucional tendría menor riesgo que una externa, pero no existe inventario de autorizaciones. El equipo tecnológico propone una solución operativa inmediata y las coordinaciones formulan reparos sobre su alcance. La dirección debe conservar el servicio educativo mientras define controles proporcionados a la información involucrada.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-21",
      "title": "Programa alimentario interrumpido",
      "text": "Un proveedor de alimentación escolar reporta fallas graves, y la comunidad exige que rectoría lo sustituya por contrato inmediato. La interrupción afectaría a quienes dependen de la alimentación escolar y existen reportes contradictorios sobre la causa del retraso. La rectoría cuenta con actas de entrega, aunque no dirige la contratación principal del programa. La situación plantea obligaciones simultáneas de acceso educativo, cuidado y comunicación institucional. Algunas medidas podrían parecer eficientes a corto plazo, pero generar consecuencias de exclusión o de tratamiento inadecuado.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-22",
      "title": "Filtración de resultados",
      "text": "Se envía por equivocación a una lista abierta un archivo con notas y datos de identificación personal. El mensaje enviado contiene información que podría afectar derechos de estudiantes y acudientes. Algunos destinatarios confirmaron haber descargado el archivo, por lo que corregir el envío no equivale a eliminar toda exposición. La herramienta se usa en varias sedes y no todas disponen de las mismas condiciones de conectividad. Algunas decisiones podrían producir efectos duraderos sobre estudiantes, por lo que resulta importante documentar alcance y responsabilidades.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-23",
      "title": "Educación física suspendida por lluvia",
      "text": "Durante cuatro meses se han suspendido clases de educación física cada vez que llueve porque solo existe patio abierto. Las sesiones canceladas afectaron unidades completas de movimiento, autocuidado y trabajo cooperativo. La institución tiene salas amplias no deportivas y docentes interesados en diseñar actividades adaptadas. Varios actores proponen incorporar actividades novedosas, pero los planes de área no señalan desempeños ni evidencias comunes. El Consejo Académico solicita precisar la conexión entre la propuesta y las funciones escolares.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-24",
      "title": "Dato agregado y brecha",
      "text": "Un informe indica 85 % de asistencia institucional, pero oculta que dos sedes rurales apenas alcanzan 58 % y 63 %. La mayor parte de la matrícula pertenece a una sede urbana con asistencia elevada. Las dos sedes rurales tienen condiciones de movilidad distintas y la ausencia de desagregación puede afectar la priorización del apoyo. El texto se discutirá en un espacio de participación en el que algunas personas respaldan su recomendación por experiencia directa. La revisión exige valorar la fuerza de la inferencia sin descartar automáticamente los registros aportados.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-25",
      "title": "Cumplimiento ponderado de metas",
      "text": "Un plan da peso 50 % a permanencia, 30 % a lectura y 20 % a ambiente, con avances 80, 60 y 90 puntos respectivamente. Los pesos fueron aprobados antes de conocer los resultados y se pretende respetarlos para la rendición. La dirección necesita revisar escenarios de refuerzo sin modificar las ponderaciones a posteriori. La tabla alimentará decisiones sobre distribución de apoyos institucionales y debe mantener las unidades originales. Los equipos solicitan que cada cálculo pueda reconstruirse a partir de las cifras de la premisa.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-26",
      "title": "Orden verbal improcedente",
      "text": "Un superior solicita alterar un acta de contratación y afirma que asumirá cualquier responsabilidad posterior. El expediente será revisado próximamente y el cambio solicitado afectaría hechos relevantes para justificar pagos. La instrucción no fue formalizada y quien la emitió pretende que nadie conserve versiones anteriores. Una parte de la comunidad interpreta la actuación como una señal de liderazgo y otra considera que podría comprometer garantías. La rectoría debe explicar qué criterios utilizará y qué participación corresponde a cada responsable.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-27",
      "title": "Acoso laboral denunciado",
      "text": "Una docente informa presuntas conductas hostiles de su superior y solicita que el rector califique personalmente la responsabilidad disciplinaria. La denunciante pide mantener reserva y conservar su asignación, mientras circulan versiones que podrían afectar su reputación. El rector no es la instancia llamada a anticipar la calificación jurídica definitiva del conflicto. El cambio podría alterar la distribución de labores entre sedes y las condiciones de trabajo de varios equipos. Las coordinaciones solicitan criterios conocidos y un procedimiento que diferencie decisiones propias de rectoría de atribuciones externas.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-28",
      "title": "Aula virtual sin acceso",
      "text": "Una plataforma obligatoria exige teléfono inteligente, pero en una sede rural el 45 % de estudiantes no dispone de uno. Un número importante de familias comparte un solo equipo o depende de cobertura móvil inestable. La plataforma resulta útil para algunos grupos, pero la calificación propuesta ignora diferencias de acceso previas a la actividad. La herramienta se usa en varias sedes y no todas disponen de las mismas condiciones de conectividad. Algunas decisiones podrían producir efectos duraderos sobre estudiantes, por lo que resulta importante documentar alcance y responsabilidades.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-29",
      "title": "Castigo colectivo",
      "text": "Ante daños a muebles sin responsable identificado, el coordinador plantea suspender a todo el curso. No existe registro objetivo que permita atribuir el daño a una persona concreta y algunos estudiantes denuncian presión para señalar a un compañero. La medida se propone para enviar una señal de disciplina antes del próximo evento escolar. El equipo de convivencia tiene actividades preventivas programadas, pero existe una situación concreta que requiere tratamiento específico. Las familias reclaman información pertinente y garantías para todas las personas involucradas.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-30",
      "title": "Promesa fuera de competencia",
      "text": "En campaña para un cargo escolar, una persona promete que rectoría podrá crear plazas de docentes por decisión propia. La propuesta apareció en una asamblea con familias que solicitan mejorar cobertura. El establecimiento tiene estadísticas de carga docente y vacantes, pero carece de facultad para modificar unilateralmente la planta territorial. Los registros iniciales son incompletos y los actores involucrados defienden interpretaciones diferentes. La institución necesita responder de modo oportuno, con actuaciones sustentadas y comunicación que preserve la confianza comunitaria.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-31",
      "title": "Innovación sin comparación justa",
      "text": "Una nueva metodología muestra mejores notas en un grupo que ya tenía promedio inicial superior y menor inasistencia. Los grupos pertenecen a jornadas distintas y una de ellas cuenta con mejores condiciones de conectividad. La propuesta de expansión se presentará al Consejo Académico con los resultados disponibles, que no incluyen una comparación del avance inicial. Los docentes tienen experiencias diferentes con la propuesta y aún no acuerdan criterios comunes de seguimiento. La rectoría busca que la innovación responda a una necesidad formativa concreta y no dependa únicamente del entusiasmo inicial.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-32",
      "title": "Reclamación sin respuesta",
      "text": "Una familia radica apelación de resultados; la institución conserva el escrito sin explicar criterios ni ofrecer respuesta. El término para entregar boletines se aproxima y varios docentes discrepan sobre el procedimiento de revisión. La petición incluye una rúbrica y un trabajo calificado que podrían contrastarse con los acuerdos institucionales publicados. El Consejo Académico pidió revisar los documentos institucionales y los registros concretos de desempeño. El calendario de publicación de resultados exige actuar con oportunidad sin reemplazar el juicio pedagógico por una medida disciplinaria.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-33",
      "title": "Plan que no llega a aulas",
      "text": "El PMI menciona mejorar ciencias, pero los planes de área carecen de actividades, responsables y evidencias de seguimiento. Una visita de seguimiento encontró que las actas citan el objetivo institucional, pero los docentes lo interpretan de modos distintos. La rectoría quiere evitar un nuevo formato administrativo y necesita demostrar que las decisiones modifican la enseñanza. La comunidad solicita una decisión antes de la siguiente revisión del plan institucional. El equipo directivo cuenta con antecedentes de años anteriores, pero todavía no ha acordado cómo distinguir actividades ejecutadas de efectos obtenidos.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-34",
      "title": "Cátedra de paz memorística",
      "text": "El equipo propone evaluar convivencia y paz mediante repetición de definiciones, ignorando prácticas de resolución de conflictos. Los cuestionarios permiten recordar definiciones de convivencia, pero las observaciones de aula muestran dificultades para deliberar. El equipo quiere disponer de evidencias aplicadas sin dejar de enseñar conceptos indispensables. La comunidad expresa interés en sostener la iniciativa más allá de una jornada anual. Los docentes piden orientaciones que respeten el currículo, mientras rectoría evalúa cómo comprometer recursos y realizar seguimiento.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-35",
      "title": "Talento excepcional y apoyos",
      "text": "Una estudiante con capacidades excepcionales termina rápido y deja de participar; se propone repetir contenidos para mantenerla ocupada. La estudiante produce respuestas avanzadas y ha manifestado interés en desafíos científicos. El profesorado dispone de materiales adicionales, pero busca una ruta de enriquecimiento sin asignarle funciones administrativas ni eliminar su convivencia con pares. Las familias expresan preocupación por el acceso efectivo a las actividades ordinarias del establecimiento. El equipo docente dispone de información pedagógica parcial y debe decidir cómo iniciar apoyos sin convertir trámites en barreras de participación.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-36",
      "title": "Representación de egresados",
      "text": "Dos organizaciones de egresados piden ocupar simultáneamente un mismo asiento del Consejo Directivo y cuestionan el procedimiento previo. Los grupos no discuten el número total de representantes, pero difieren sobre quién está facultado para escoger al delegado. Una elección anterior quedó registrada en acta y ahora se cuestiona si las organizaciones recibieron la misma información de convocatoria. En la sesión preparatoria surgieron desacuerdos sobre el alcance de las decisiones adoptadas por cada órgano. Los representantes solicitaron conocer el procedimiento aplicable antes de asumir compromisos que afectarían a toda la comunidad.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-37",
      "title": "Evaluación de desempeño improvisada",
      "text": "Un rector pretende evaluar a un docente con una sola observación sorpresiva, sin contrastar compromisos ni evidencias. El docente recibió comentarios previos positivos y el nuevo evaluador no dispone del conjunto de compromisos pactados. Un desacuerdo pedagógico reciente podría sesgar la observación, por lo que se requiere una ruta reconocible y fundada. El establecimiento afronta restricciones de tiempo y disponibilidad de personal. La rectoría necesita justificar cómo mantendrá la atención a estudiantes mientras revisa competencias, obligaciones y eventuales ajustes organizativos.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-38",
      "title": "Metas sin línea de base",
      "text": "Un plan institucional promete disminuir ausencias veinte puntos, aunque nunca se definió el indicador ni el período de comparación. El coordinador considera que basta medir ausencias diarias, mientras el comité de calidad propone usar días-estudiante programados. Se espera rendir cuentas trimestralmente y comparar sedes con matrículas y calendarios diferentes. Las sedes recopilaron información mediante instrumentos distintos y el equipo de calidad advierte que los resultados pueden no ser comparables. La dirección necesita sustentar prioridades sin convertir el proceso en un trámite documental.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-39",
      "title": "Evaluación oral rígida",
      "text": "Una estudiante que emplea comunicación aumentativa domina los contenidos, pero su docente exige respuestas orales rápidas para calificar. En actividades escritas y mediante apoyos comunicativos la estudiante resuelve problemas pertinentes al grado. La familia ha presentado recomendaciones de accesibilidad y solicita que la valoración no confunda velocidad oral con dominio curricular. Las familias expresan preocupación por el acceso efectivo a las actividades ordinarias del establecimiento. El equipo docente dispone de información pedagógica parcial y debe decidir cómo iniciar apoyos sin convertir trámites en barreras de participación.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S2-40",
      "title": "Argumento de presupuesto sin datos",
      "text": "En un informe se afirma: 'Los talleres mejoraron la convivencia porque el número de reuniones pasó de cuatro a doce'. No se muestran incidentes, participación ni seguimiento. El reporte se redactó para respaldar una solicitud de ampliación de talleres. La institución reconoce que existen registros de reuniones, pero no ha definido indicadores sobre el problema cuya mejora atribuye al programa. La afirmación se difundió como una conclusión institucional, aunque los participantes recibieron distintas versiones sobre sus fuentes. La rectoría propone distinguir entre datos observados, explicaciones posibles y afirmaciones que necesitan comprobación adicional.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-01",
      "title": "Sobrante de proyecto restringido",
      "text": "Un recurso asignado para laboratorio queda parcialmente sin ejecutar y se propone destinarlo a un acto institucional. Las condiciones del aporte fueron registradas en un convenio con finalidad pedagógica definida. La asociación de padres ofrece organizar el evento, pero la decisión podría cambiar la destinación original del recurso. Hay presión para ejecutar recursos antes del cierre del período y evitar que persista una necesidad escolar. La dirección debe ponderar oportunidad, legalidad y sostenibilidad con documentos presupuestales disponibles.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-02",
      "title": "Listado de salud en nube pública",
      "text": "Un contratista propone cargar diagnósticos y contactos de estudiantes en una hoja accesible por enlace público. Los datos serían utilizados por personal docente y practicantes externos, con permisos idénticos para todas las personas que poseen el enlace. La propuesta enfatiza rapidez, aunque no documenta medidas de seguridad ni limitación de finalidades. Los datos disponibles provienen de sistemas con permisos y propósitos diferentes. Una revisión inicial advierte que mejorar la rapidez del proceso podría incrementar riesgos de acceso, registro o interpretación de información sensible.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-03",
      "title": "Tasa de retiro por cohorte",
      "text": "Un plan registra 480 matriculados iniciales, 24 retiros efectivos y 12 traslados certificados; un informe confunde las dos novedades. El consejo de calidad necesita usar un indicador estable durante todo el año. Un asesor propone sumar cualquier cambio de matrícula como abandono y otro pide respetar la categoría definida para cada evento. El informe será utilizado para comparar períodos o sedes y sus responsables piden explicitar los denominadores empleados. Es necesario distinguir porcentajes, cambios absolutos y resultados relativos antes de presentar conclusiones a la comunidad.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-04",
      "title": "Silencio del acta",
      "text": "Un acta dice que el equipo revisó un problema de transporte, pero no registra acuerdos ni responsables; después se afirma que ya fue resuelto. El asunto aparece listado dentro de varios problemas considerados prioritarios. Ningún acta registra responsables ni decisiones posteriores, pese a lo cual el reporte final lo presenta como cierre exitoso. La afirmación se difundió como una conclusión institucional, aunque los participantes recibieron distintas versiones sobre sus fuentes. La rectoría propone distinguir entre datos observados, explicaciones posibles y afirmaciones que necesitan comprobación adicional.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-05",
      "title": "Falsa disyuntiva de inclusión",
      "text": "Una circular sostiene: 'O se asignan los recursos exclusivamente a estudiantes con discapacidad o se mantiene la calidad para los demás'. La propuesta fue presentada en una discusión sobre distribución de recursos limitados. Algunos integrantes aceptan la disyuntiva, aunque existen apoyos con efectos compartidos y opciones graduales de inversión. El documento será utilizado para orientar futuras acciones y contiene afirmaciones sobre resultados educativos. El equipo debe precisar qué conclusiones están sostenidas y qué información permitiría someter las demás a contraste.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-06",
      "title": "Robótica y brecha digital",
      "text": "Solo dos grupos con conectividad participan en robótica; el proyecto institucional pretende extender conclusiones a cuatro sedes. La administración propone adquirir nuevas licencias para extender la experiencia y teme perder descuentos del proveedor. Sin embargo, el pilotaje tuvo condiciones de acceso desiguales y falta documentar cómo aprendieron quienes participaron fuera de línea. La iniciativa cuenta con respaldo de algunos equipos de área y reservas de quienes esperan evidencias de aprendizaje. El presupuesto admite ajustes limitados y la decisión deberá explicar qué cambio didáctico se busca observar.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-07",
      "title": "Convocatorias inaccesibles",
      "text": "La escuela convoca a familias rurales solo de forma presencial a las diez de la mañana, con asistencia mínima. Las familias trabajan en horarios irregulares y algunas comparten dispositivos móviles con otros miembros del hogar. Las sesiones previstas tienen contenido pertinente, pero la convocatoria actual excluye a quienes viven más lejos. La participación ha sido desigual entre sectores de la comunidad y algunas familias señalan dificultades de comunicación. La rectoría necesita una respuesta que reconozca los intereses concurrentes y la competencia de los órganos escolares.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-08",
      "title": "Corte eléctrico recurrente",
      "text": "Una sede sufre cortes diarios que afectan conservación de alimentos y sesiones de informática. La sede cuenta con un equipo de refrigeración que registra variaciones de temperatura y materiales educativos que pueden reutilizarse sin electricidad. La dirección necesita priorizar seguridad alimentaria y continuidad de las actividades. Un informe inicial registra señales de deterioro, pero no existe consenso sobre la gravedad ni sobre las responsabilidades de cada actor. Las clases continúan y la rectoría debe tomar una decisión proporcional a la información disponible.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-09",
      "title": "Conflicto por cambio de residencia",
      "text": "Una estudiante cambia de barrio y la coordinación sugiere cancelación automática del cupo por vivir fuera del sector. La estudiante conserva vínculos en la sede y su familia desea continuidad durante el período. La coordinación invoca una zona geográfica administrativa, aunque no ha identificado el acto que obligaría a cancelar esa matrícula. El equipo docente conoce parte de los hechos, aunque carece de toda la información familiar. La propuesta será examinada por quienes tienen a cargo protección, matrícula y acompañamiento pedagógico.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-10",
      "title": "Puente peatonal inestable",
      "text": "El acceso a una sede presenta deterioro reportado y estudiantes cruzan diariamente; se discute si la obra compete al colegio. Varias familias conocen un camino alterno más largo, pero desconocen si está habilitado y quién debe responder por su mantenimiento. La llegada a clases depende del cruce y se requiere una solución temporal segura. Un informe inicial registra señales de deterioro, pero no existe consenso sobre la gravedad ni sobre las responsabilidades de cada actor. Las clases continúan y la rectoría debe tomar una decisión proporcional a la información disponible.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-11",
      "title": "Lengua extranjera sin articulación",
      "text": "En básica secundaria, cada grado usa un libro distinto sin progresión de competencias y el cambio de docente rompe continuidad. La dificultad apareció al revisar el paso de séptimo a octavo y comparar tareas de evaluación. Los estudiantes repiten temas básicos, pero no evidencian avance gradual en expresión y comprensión. El proyecto se ha desarrollado de forma distinta entre cursos y sedes, sin criterios compartidos sobre su contribución al aprendizaje. La dirección debe coordinar las responsabilidades curriculares y demostrar continuidad de las acciones.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-12",
      "title": "Reunión de rendición excluyente",
      "text": "La rendición de cuentas se anuncia únicamente en internet, aunque gran parte de las familias no tiene conectividad. La institución tiene sedes con condiciones de acceso a internet muy diferentes y la convocatoria se difundió con poca anticipación. El equipo administrativo considera que publicar el informe en línea satisface por sí mismo la rendición. Una propuesta externa ofrece beneficios importantes, aunque sus condiciones no han sido discutidas por todos los actores afectados. Los docentes esperan continuidad curricular y las organizaciones comunitarias solicitan claridad sobre compromisos.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-13",
      "title": "Uniforme y expresión cultural",
      "text": "El manual exige un accesorio uniforme incompatible con prácticas culturales de un grupo estudiantil y hay propuestas de excluirlo. La modificación del uniforme se aprobó años atrás sin identificar posibles impactos diferenciados. El consejo recibió peticiones y necesita argumentar si la exigencia persigue una finalidad legítima y puede alcanzarse por medios menos restrictivos. El caso circuló informalmente entre integrantes de la comunidad, lo que incrementó las preocupaciones por confidencialidad. La dirección necesita distinguir las actuaciones escolares de aquellas que corresponden a otras autoridades y servicios.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-14",
      "title": "Autodiagnóstico complaciente",
      "text": "En la autoevaluación institucional cada gestión obtuvo la calificación máxima, pese a ausencias, infraestructura deteriorada y conflictos persistentes. El equipo teme que reconocer dificultades genere observaciones negativas en la evaluación externa y prefiere destacar sus fortalezas. Varias fuentes registran problemas reiterados que no aparecen en las calificaciones y requieren explicación antes de formular metas. Una parte del profesorado propone mantener las metas anunciadas para conservar la motivación. Otros piden precisar las unidades de medida y los grupos de referencia antes de interpretar cualquier variación.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-15",
      "title": "Atención por salud prolongada",
      "text": "Una alumna recibe tratamiento médico continuo y presenta interrupciones de aprendizaje; se pretende exigir asistencia presencial idéntica. La escuela recibe indicaciones generales sobre tiempos de cuidado y solicita mantener contacto académico sin interferir con atención médica. El calendario de evaluaciones ordinarias está pensado para asistencia continua. Las personas involucradas tienen necesidades inmediatas y las instancias externas aún no han definido tiempos de respuesta. La rectoría debe determinar qué puede hacer el establecimiento mientras coordina servicios y mantiene continuidad educativa.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-16",
      "title": "Aprendizaje basado en proyectos sin rúbrica",
      "text": "Una propuesta interdisciplinaria construye huertas escolares, pero sus actividades no se relacionan con resultados previstos en los planes de área. Los estudiantes disfrutan el trabajo de campo, aunque sus informes no permiten identificar qué conocimientos científicos desarrollaron. Cada área dispuso actividades diferentes y aún no existe acuerdo sobre la evaluación conjunta del proyecto. La iniciativa cuenta con respaldo de algunos equipos de área y reservas de quienes esperan evidencias de aprendizaje. El presupuesto admite ajustes limitados y la decisión deberá explicar qué cambio didáctico se busca observar.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-17",
      "title": "Promedios de sedes",
      "text": "En la sede A, 40 de 50 estudiantes alcanzan logro; en la sede B, 18 de 30 lo alcanzan; un informe promedia porcentajes sin ponderar. Las dos sedes utilizaron el mismo instrumento, pero difieren en número de evaluados. La coordinación plantea una tasa consolidada y una meta de mejoramiento específica para la sede con menor resultado. La información procede de registros administrativos ordinarios y se divulgará en una reunión institucional. Los participantes deben poder comprobar los resultados sin mezclar poblaciones ni interpretaciones de indicadores.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-18",
      "title": "Informe trimestral omitido",
      "text": "El FSE registra egresos, pero el Consejo Directivo no recibe análisis de ejecución ni flujo de caja del trimestre. El contador dispone de balances y comprobantes, aunque el informe no ha sido presentado en el espacio colegiado previsto. Se aproxima una decisión sobre nuevos compromisos y varios miembros del Consejo solicitan conocer el flujo disponible. La propuesta cuenta con una justificación operativa, pero existen dudas sobre el procedimiento exigible y las competencias para ordenar el gasto. La comunidad espera resultados y solicita trazabilidad de las decisiones presupuestales.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-19",
      "title": "PIAR copiado",
      "text": "En tres grados se distribuye un mismo PIAR con metas y ajustes idénticos para estudiantes con necesidades diversas. Los documentos se copiaron de un modelo institucional y contienen un listado idéntico de actividades para estudiantes con barreras distintas. Las familias señalan que las metas acordadas no se observan en las clases ni en los informes de avance. Los apoyos actuales presentan diferencias entre sedes y jornadas que pueden afectar la continuidad educativa. La rectoría requiere una decisión articulada con docentes, familias y responsables administrativos sin sustituir valoraciones especializadas.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-20",
      "title": "Agua contaminada",
      "text": "Un resultado técnico sugiere contaminación del agua usada para consumo, mientras la cafetería pide seguir operando. La alerta provino de una muestra tomada en un punto usado diariamente por estudiantes y personal de cocina. No se conoce aún el alcance de la afectación ni la fecha de normalización del suministro. El cronograma académico resulta vulnerable a nuevas interrupciones y los responsables operativos solicitan instrucciones claras. Las familias reclaman información oportuna acerca de las condiciones de seguridad y de las alternativas disponibles.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-21",
      "title": "Matrícula con duplicados",
      "text": "Una exportación del sistema presenta estudiantes con dos registros activos que inflan la matrícula por sede. La diferencia entre registros podría provenir de traslados, cambios de sede o actualizaciones incompletas. El reporte será utilizado para decisiones presupuestales y debe sostenerse en población efectiva, no en filas duplicadas. Los datos disponibles provienen de sistemas con permisos y propósitos diferentes. Una revisión inicial advierte que mejorar la rapidez del proceso podría incrementar riesgos de acceso, registro o interpretación de información sensible.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-22",
      "title": "Educación sexual sin enfoque de derechos",
      "text": "Una propuesta reduce educación sexual a advertencias biológicas y excluye deliberadamente dimensiones afectivas y de derechos. Los estudiantes formulan preguntas sobre relaciones y autocuidado que las actividades disponibles no contestan. Los docentes proponen actualizar objetivos con enfoques pertinentes a edad, convivencia y responsabilidades compartidas. La comunidad expresa interés en sostener la iniciativa más allá de una jornada anual. Los docentes piden orientaciones que respeten el currículo, mientras rectoría evalúa cómo comprometer recursos y realizar seguimiento.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-23",
      "title": "Asignación docente fuera de perfil",
      "text": "Se propone que quien enseña lenguaje asuma temporalmente laboratorios especializados de química sin valoración de seguridad ni idoneidad. La necesidad surgió con la ausencia temporal de un profesional y afecta prácticas con potenciales riesgos. El equipo teme perder horas, pero no ha revisado alternativas de cobertura o limitaciones de idoneidad. Las versiones de los participantes no coinciden y la medida anunciada produciría efectos antes de que exista una explicación documentada. El equipo directivo debe distinguir entre apoyo pedagógico, organización del servicio y procedimientos aplicables.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-24",
      "title": "Proyecto de convenio local",
      "text": "Una empresa ofrece financiar una biblioteca a cambio de dirigir las actividades del gobierno escolar y elegir representantes estudiantiles. El ofrecimiento se presenta a un mes de las elecciones de representantes y varios docentes apoyan aceptarlo por la precariedad de recursos. La empresa solicita acceso regular a las reuniones para verificar que su aporte tenga resultados visibles. La propuesta fue discutida de manera informal, sin que exista consenso sobre el momento en que produce efectos institucionales. La rectoría recibió solicitudes contradictorias de docentes y familias que requieren una respuesta motivada.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-25",
      "title": "Mensaje público tras accidente",
      "text": "Un accidente escolar causa rumores; la institución carece de información completa y familiares piden explicaciones. Los comentarios se difunden por grupos comunitarios y algunas versiones contienen datos personales de la persona afectada. Un comunicado precipitado podría agravar el daño, aunque la ausencia de información oficial aumenta la incertidumbre. Una parte de la comunidad interpreta la actuación como una señal de liderazgo y otra considera que podría comprometer garantías. La rectoría debe explicar qué criterios utilizará y qué participación corresponde a cada responsable.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-26",
      "title": "Informe final sin retroalimentación",
      "text": "El boletín de período presenta cifras globales por materia y carece de orientaciones comprensibles para fortalecer aprendizajes. Los acudientes manifiestan que una misma cifra se interpreta de manera distinta según el docente y el área. La institución dispone de rúbricas, registros de apoyo y reuniones de seguimiento que aún no se reflejan en el boletín. La propuesta provocó diferencias entre docentes que atienden el mismo grado. Las familias solicitan que se expliquen los criterios aplicables y que se respete la participación de los órganos responsables de orientar la evaluación.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-27",
      "title": "Ausencia reportada de modo informal",
      "text": "Un coordinador recibe audios sobre ausencias repetidas, pero nunca coteja horarios ni reporta novedades por los canales oficiales. Las comunicaciones se han transmitido entre turnos sin fecha ni confirmación de los hechos. La sede necesita garantizar continuidad de clases y la autoridad territorial requiere reportes por un conducto preciso. El cambio podría alterar la distribución de labores entre sedes y las condiciones de trabajo de varios equipos. Las coordinaciones solicitan criterios conocidos y un procedimiento que diferencie decisiones propias de rectoría de atribuciones externas.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-28",
      "title": "Cámara y almacenamiento indefinido",
      "text": "La institución instala cámaras en pasillos y anuncia conservación perpetua de grabaciones sin política clara. La medida fue introducida después de incidentes menores y la comunidad desconoce quién revisa las imágenes. El almacenamiento sería contratado por un proveedor externo y no existe protocolo para atender solicitudes de acceso. El equipo tecnológico propone una solución operativa inmediata y las coordinaciones formulan reparos sobre su alcance. La dirección debe conservar el servicio educativo mientras define controles proporcionados a la información involucrada.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-29",
      "title": "Registro civil pendiente",
      "text": "Un estudiante desplazado solicita continuar sus clases, pero los documentos de identificación aún están en trámite y la sede propone rechazarlo. La familia describe un traslado reciente y desconoce los tiempos de los trámites administrativos. El establecimiento cuenta con plazas disponibles, pero teme inconsistencias entre registro de matrícula y documentos presentados. Las personas involucradas tienen necesidades inmediatas y las instancias externas aún no han definido tiempos de respuesta. La rectoría debe determinar qué puede hacer el establecimiento mientras coordina servicios y mantiene continuidad educativa.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-30",
      "title": "Innovación resistida",
      "text": "Dos equipos docentes enfrentados bloquean una propuesta metodológica antes de examinar datos de aprendizaje. La propuesta cuenta con evidencia parcial, pero los equipos rechazan revisar resultados del otro grupo. La rectoría dispone de un período corto para diseñar un piloto y necesita contener una disputa que ya afecta reuniones de área. Los registros iniciales son incompletos y los actores involucrados defienden interpretaciones diferentes. La institución necesita responder de modo oportuno, con actuaciones sustentadas y comunicación que preserve la confianza comunitaria.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-31",
      "title": "Ajustes fuera del PMI",
      "text": "Los PIAR describen necesidades recurrentes de señalización accesible, pero el PMI y el presupuesto escolar no las consideran. La necesidad aparece en varios planes individuales durante dos períodos consecutivos y los cambios requeridos benefician a más estudiantes. Sin embargo, el presupuesto priorizó dotación general sin revisar los espacios donde se concentra la barrera. La institución conoce experiencias de otros grupos, pero sus necesidades no son idénticas. Algunos adultos proponen reglas uniformes y otros solicitan medidas diferenciadas que conserven las exigencias curriculares pertinentes.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-32",
      "title": "Recuperación meramente formal",
      "text": "La institución programa una sola prueba final idéntica para todos los estudiantes que presentaron dificultades heterogéneas. El examen único incluye contenidos que varios estudiantes ya dominan y deja fuera competencias en las que otros necesitan apoyo. Dos áreas reclaman una solución rápida y el equipo directivo discute cómo conservar exigencia sin homogeneizar necesidades. La propuesta provocó diferencias entre docentes que atienden el mismo grado. Las familias solicitan que se expliquen los criterios aplicables y que se respete la participación de los órganos responsables de orientar la evaluación.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-33",
      "title": "Presión por mejorar ranking",
      "text": "Una directiva sugiere excluir de pruebas internas a estudiantes con menor desempeño para publicar una media elevada. La directiva argumenta que mejorar el promedio estimulará nuevas inversiones y que la evaluación no es obligatoria para todos. El equipo de calidad alerta sobre alteraciones del denominador y perjuicios para estudiantes excluidos. Una parte de la comunidad interpreta la actuación como una señal de liderazgo y otra considera que podría comprometer garantías. La rectoría debe explicar qué criterios utilizará y qué participación corresponde a cada responsable.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-34",
      "title": "Ausentismo con distinto período",
      "text": "En abril hubo 2000 días-estudiante programados y 140 ausencias; en mayo 1800 programados y 108 ausencias. La matrícula fluctuó y el número de días programados cambió entre abril y mayo. Se solicita una lectura que distinga cambios absolutos y variaciones en proporciones, evitando conclusiones basadas únicamente en conteos. El informe será utilizado para comparar períodos o sedes y sus responsables piden explicitar los denominadores empleados. Es necesario distinguir porcentajes, cambios absolutos y resultados relativos antes de presentar conclusiones a la comunidad.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-35",
      "title": "Educación artística residual",
      "text": "El consejo propone usar todas las horas de arte para preparar pruebas externas sin modificar documentos curriculares. La medida pretende responder a una caída de resultados de matemáticas. Docentes de artística señalan que sustituir su área puede incumplir la planeación y disminuir oportunidades formativas de parte de la población. El proyecto se ha desarrollado de forma distinta entre cursos y sedes, sin criterios compartidos sobre su contribución al aprendizaje. La dirección debe coordinar las responsabilidades curriculares y demostrar continuidad de las acciones.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-36",
      "title": "Informe con cifras incompatibles",
      "text": "El informe del PMI anuncia mejora del 30 %, pero una tabla muestra un aumento de cuatro a cinco estudiantes con logro entre veinte evaluados. El informe fue preparado para un encuentro con autoridades territoriales y podría utilizarse para solicitar recursos adicionales. Los datos originales siguen disponibles, aunque el porcentaje publicado se replicó en presentaciones y actas recientes. Una parte del profesorado propone mantener las metas anunciadas para conservar la motivación. Otros piden precisar las unidades de medida y los grupos de referencia antes de interpretar cualquier variación.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-37",
      "title": "Conflicto de interés en el Consejo",
      "text": "Un consejero propone contratar una firma de su propiedad y participa en la deliberación sobre el proveedor. La firma pertenece a un integrante elegido por representación familiar, quien asegura que su experiencia permitiría ahorrar recursos públicos. Existe una propuesta competidora con especificaciones diferentes y la votación está anunciada para una sesión extraordinaria. El asunto se presentó como una solución inmediata a una necesidad reconocida, aunque algunos participantes expresaron reservas sobre la forma de decidir. Hay interés en preservar la continuidad del servicio y la confianza en los órganos colegiados.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-38",
      "title": "Conflicto de horarios",
      "text": "La reorganización de jornada incrementa tiempos muertos de estudiantes y favorece únicamente preferencias de docentes antiguos. Los horarios nuevos se divulgaban por mensajes informales y algunos grupos acumulan períodos sin docente. Los jefes de área piden transparencia en los criterios para decidir sin convertir las preferencias personales en fundamento exclusivo. Las versiones de los participantes no coinciden y la medida anunciada produciría efectos antes de que exista una explicación documentada. El equipo directivo debe distinguir entre apoyo pedagógico, organización del servicio y procedimientos aplicables.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-39",
      "title": "Alianza universidad sin rol definido",
      "text": "Un programa universitario propone prácticas en orientación escolar sin acuerdos de supervisión ni privacidad. La propuesta incluye acompañamiento de casos sensibles y acceso a estudiantes menores de edad. La institución ya desarrolló prácticas similares, pero esta vez no se han delimitado supervisores ni reglas de tratamiento documental. Una propuesta externa ofrece beneficios importantes, aunque sus condiciones no han sido discutidas por todos los actores afectados. Los docentes esperan continuidad curricular y las organizaciones comunitarias solicitan claridad sobre compromisos.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S3-40",
      "title": "Confidencialidad del orientador",
      "text": "Una familia pide acceso a las notas completas del orientador sobre otro estudiante involucrado en una controversia. La solicitud llegó después de una reunión sobre convivencia y mezcla datos de actuaciones institucionales con anotaciones clínicas y familiares. La dirección debe responder sin ocultar los trámites que sí pueden comunicarse a los interesados. El caso circuló informalmente entre integrantes de la comunidad, lo que incrementó las preocupaciones por confidencialidad. La dirección necesita distinguir las actuaciones escolares de aquellas que corresponden a otras autoridades y servicios.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-01",
      "title": "Dos sedes y una prioridad",
      "text": "La sede rural registra bajos niveles de permanencia y la urbana exhibe resultados de pruebas en descenso; solo existe presupuesto inicial para una intervención. Las dos intervenciones tienen costos comparables, pero tiempos de efecto distintos y poblaciones de tamaño desigual. Los líderes de sede piden una regla de priorización conocida antes de la decisión y señalan que ciertos daños podrían agravarse si no se actúa. La comunidad solicita una decisión antes de la siguiente revisión del plan institucional. El equipo directivo cuenta con antecedentes de años anteriores, pero todavía no ha acordado cómo distinguir actividades ejecutadas de efectos obtenidos.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-02",
      "title": "Promoción anticipada confundida",
      "text": "El consejo académico propone promoción anticipada automática para todo estudiante con notas altas durante el primer mes. Dos estudiantes muestran resultados sobresalientes, mientras otros desean promoción por razones de edad y expectativa familiar. La propuesta actual no distingue estas situaciones ni documenta la competencia de los órganos involucrados. Los resultados disponibles son heterogéneos y corresponden a estudiantes con trayectorias distintas. El equipo directivo debe resolver una reclamación sin generar precedentes incompatibles con los criterios de promoción previamente comunicados.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-03",
      "title": "Salud mental y estigmas",
      "text": "Un taller externo propone etiquetar estudiantes como 'de alto riesgo psicológico' en carteles por curso para orientar apoyos. El taller se presentó como prevención y habría sido dirigido por una organización comunitaria. El orientador advierte que se divulgarían inferencias psicológicas sin evaluación profesional ni acuerdos de confidencialidad. Las personas involucradas tienen necesidades inmediatas y las instancias externas aún no han definido tiempos de respuesta. La rectoría debe determinar qué puede hacer el establecimiento mientras coordina servicios y mantiene continuidad educativa.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-04",
      "title": "Evento multitudinario",
      "text": "Se planea una feria con visitantes externos que exceden la capacidad del coliseo y aún no se definió salida de emergencia. El equipo organizador ya publicó invitaciones y contrató servicios, pero la supervisión identifica obstáculos en corredores y puertas. La asistencia potencial supera las estimaciones usadas al elaborar el plan de contingencia. La situación afecta de modo desigual a los grupos y exige coordinar actores internos y externos. Antes de divulgar nuevas medidas, la institución debe distinguir entre riesgos identificados, acciones preventivas y soluciones todavía pendientes.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-05",
      "title": "Anticipo sin soporte",
      "text": "Un contratista exige un anticipo que no aparece previsto en los documentos del proceso para suministrar dotación escolar. La propuesta comercial llegó cuando faltan pocos días para iniciar clases y la cotización tiene vigencia limitada. El personal financiero advierte que no hay cláusula de anticipo ni se han documentado las condiciones de ejecución. Hay presión para ejecutar recursos antes del cierre del período y evitar que persista una necesidad escolar. La dirección debe ponderar oportunidad, legalidad y sostenibilidad con documentos presupuestales disponibles.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-06",
      "title": "Incendio en laboratorio",
      "text": "Un pequeño incendio deja extintores agotados y materiales peligrosos; el plan institucional de emergencia no se actualiza desde hace años. El incidente se controló sin lesiones, pero puso en evidencia deficiencias de mantenimiento y formación preventiva. Un grupo propone retomar experimentos al día siguiente y otro cerrar indefinidamente el espacio. Un informe inicial registra señales de deterioro, pero no existe consenso sobre la gravedad ni sobre las responsabilidades de cada actor. Las clases continúan y la rectoría debe tomar una decisión proporcional a la información disponible.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-07",
      "title": "Inventario que no coincide",
      "text": "Hay veinte equipos pagados, pero solo diecisiete aparecen físicamente y se propone cerrar el expediente de adquisición. La diferencia apareció en una revisión física después de un traslado entre sedes. Existen actas de recibido y custodia, pero algunos seriales están incompletos y es necesario aclarar responsabilidades sin presumir apropiaciones. La necesidad fue presentada como urgente por los responsables de sede y el equipo administrativo propuso caminos diferentes. Los registros del fondo permiten reconstruir autorizaciones, disponibilidad y compromisos si se revisan de manera conjunta.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-08",
      "title": "Excursión sin accesibilidad",
      "text": "Una salida pedagógica incluye senderos inaccesibles para dos estudiantes usuarios de ayudas de movilidad. La excursión hace parte de un proyecto evaluado en ciencias y la institución ha reservado transporte y alimentación. La coordinación considera costoso modificar el recorrido, mientras el equipo docente propone alternativas para garantizar experiencias equivalentes. La institución conoce experiencias de otros grupos, pero sus necesidades no son idénticas. Algunos adultos proponen reglas uniformes y otros solicitan medidas diferenciadas que conserven las exigencias curriculares pertinentes.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-09",
      "title": "Participación aparente",
      "text": "La rectoría anuncia que docentes y familias decidirán prioridades, aunque el presupuesto ya está comprometido y no se explican límites. Algunas opciones efectivamente quedaron abiertas y podrían reconsiderarse, mientras otras dependen de compromisos financieros previos. Los participantes solicitan saber por qué ciertas propuestas no aparecen en el plan final. La decisión será conocida por docentes, estudiantes y autoridades de supervisión. Existe presión para mostrar resultados rápidos, pero el equipo directivo debate cómo comunicar incertidumbres y corregir posibles conflictos de atribuciones.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-10",
      "title": "Manual de convivencia inconsulto",
      "text": "Una comisión externa entrega un manual nuevo y propone que la rectoría lo haga obligatorio sin consulta a representantes. Las modificaciones proponen ampliar sanciones por uso de teléfonos y restringir el acceso a actividades culturales. La asociación de padres recibió el borrador cuando ya estaba listo para firmarse y pide conocer los criterios usados para incorporar las nuevas reglas. La propuesta fue discutida de manera informal, sin que exista consenso sobre el momento en que produce efectos institucionales. La rectoría recibió solicitudes contradictorias de docentes y familias que requieren una respuesta motivada.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-11",
      "title": "Crecimiento relativo y puntos",
      "text": "La aprobación en un grado pasa de 60 % a 72 % entre dos períodos con criterios comparables; se anuncia aumento del 20 % 'en puntos'. Los dos períodos se evaluaron mediante criterios equiparables y la meta del siguiente ciclo está definida en 80 %. El informe confunde variación absoluta de tasas con crecimiento relativo sobre la base. La tabla alimentará decisiones sobre distribución de apoyos institucionales y debe mantener las unidades originales. Los equipos solicitan que cada cálculo pueda reconstruirse a partir de las cifras de la premisa.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-12",
      "title": "Explicación selectiva de resultados",
      "text": "Una coordinadora afirma: 'Como tres docentes innovadores obtuvieron mejores promedios, su método supera todas las demás prácticas'. Los docentes mencionados recibieron apoyo adicional y trabajaron con grupos de características diferentes. La coordinación no comparó estrategias alternativas ni examinó casos de bajo desempeño. El texto se discutirá en un espacio de participación en el que algunas personas respaldan su recomendación por experiencia directa. La revisión exige valorar la fuerza de la inferencia sin descartar automáticamente los registros aportados.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-13",
      "title": "Favores por matrícula",
      "text": "Un intermediario ofrece gestionar cupos a cambio de aportes destinados supuestamente al mantenimiento de aulas. La comunidad afronta alta demanda y la oferta de cupos resulta limitada. Varias familias señalan que recibieron mensajes contradictorios sobre donaciones supuestamente voluntarias y criterios de prioridad. La decisión será conocida por docentes, estudiantes y autoridades de supervisión. Existe presión para mostrar resultados rápidos, pero el equipo directivo debate cómo comunicar incertidumbres y corregir posibles conflictos de atribuciones.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-14",
      "title": "Organización barrial opina sobre PEI",
      "text": "Una organización comunitaria presenta evidencia de riesgo ambiental cercano y pide ser escuchada en la planeación. La organización ha documentado cambios en un afluente cercano y ofrece información que podría alimentar proyectos de ciencias. Algunos docentes desconfían de los líderes externos y piden precisar qué pueden decidir los órganos escolares. El encuentro inicial permitió identificar necesidades, pero no produjo un consenso sobre responsabilidades ni formas de seguimiento. La institución debe evitar que la participación se reduzca a divulgar decisiones ya adoptadas.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-15",
      "title": "Reincidencia y medida restaurativa",
      "text": "Tras reiteradas burlas por acento regional, el comité sugiere una charla general sin acompañamiento a quien sufrió el hecho. La persona afectada reporta temor de volver al aula y la situación ya se había tratado de forma informal. El grupo reconoce bromas reiteradas, pero no se documentaron medidas de protección ni seguimiento posterior. Los testimonios disponibles presentan diferencias y aún deben contrastarse con información obtenida sin presiones. Varias personas solicitan una decisión inmediata y otras advierten sobre la posibilidad de exponer nuevamente a quienes resultaron afectados.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-16",
      "title": "Trabajo infantil y ausencias",
      "text": "Una estudiante falta los jueves para realizar labores económicas familiares y se propone simplemente rebajar las notas por inasistencia. La situación de ausentismo persiste varias semanas y la estudiante conserva interés en continuar. Los docentes observan descenso de desempeño y no saben si el problema debe abordarse exclusivamente como falta académica. El equipo docente conoce parte de los hechos, aunque carece de toda la información familiar. La propuesta será examinada por quienes tienen a cargo protección, matrícula y acompañamiento pedagógico.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-17",
      "title": "Reporte tardío de autolesión",
      "text": "Una docente informa riesgo de autolesión y pide esperar al próximo consejo académico porque el estudiante no quiere molestias. La alerta coincide con un fin de semana y algunos profesionales no se encuentran en la sede. El equipo directivo dispone de contactos de emergencia y debe diferenciar confidencialidad de inacción ante una amenaza que podría agravarse. El equipo de convivencia tiene actividades preventivas programadas, pero existe una situación concreta que requiere tratamiento específico. Las familias reclaman información pertinente y garantías para todas las personas involucradas.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-18",
      "title": "Traslado presupuestal urgente",
      "text": "Una partida de mantenimiento está agotada, pero existe saldo para material didáctico; rectoría propone trasladarlo sin acuerdo. La comunidad exige corregir filtraciones antes de nuevas lluvias y teme que la sesión del Consejo demore la intervención. Existen proyecciones de gasto y debe aclararse si las partidas disponibles pueden trasladarse conforme a las reglas. La propuesta cuenta con una justificación operativa, pero existen dudas sobre el procedimiento exigible y las competencias para ordenar el gasto. La comunidad espera resultados y solicita trazabilidad de las decisiones presupuestales.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-19",
      "title": "Pérdida atribuida sin investigación",
      "text": "Tras extraviarse materiales, la rectoría culpa al auxiliar con menor antigüedad por ser responsable informal de bodega. El auxiliar señala que otras personas tuvieron acceso al espacio y no existe una cadena de custodia completa. El rector debe distinguir la necesidad de recuperar bienes del deber de establecer hechos mediante actuaciones imparciales. La decisión será conocida por docentes, estudiantes y autoridades de supervisión. Existe presión para mostrar resultados rápidos, pero el equipo directivo debate cómo comunicar incertidumbres y corregir posibles conflictos de atribuciones.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-20",
      "title": "Competencias confundidas",
      "text": "El Consejo Académico aprobó directamente la compra de equipos e indicó al rector que ejecute el gasto con fondos del colegio. El equipo académico fundamenta su solicitud en diagnósticos de aula y asegura que cualquier trámite adicional retrasará el material de laboratorio. El presupuesto tiene partidas específicas y la secretaría administrativa solicita instrucciones para saber quién aprueba su modificación. En la sesión preparatoria surgieron desacuerdos sobre el alcance de las decisiones adoptadas por cada órgano. Los representantes solicitaron conocer el procedimiento aplicable antes de asumir compromisos que afectarían a toda la comunidad.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-21",
      "title": "Votación sin quórum",
      "text": "La presidencia convocó al Consejo Directivo para decidir una modificación de calendario, pero asistió una minoría de sus integrantes y se levantó un acta como si hubiese decisión colegiada. La modificación afectaría simultáneamente dos jornadas y las familias ya recibieron un cronograma preliminar. La secretaría del Consejo advierte que algunos consejeros nunca fueron notificados y solicita que se aclare qué decisiones pueden considerarse válidas. En la sesión preparatoria surgieron desacuerdos sobre el alcance de las decisiones adoptadas por cada órgano. Los representantes solicitaron conocer el procedimiento aplicable antes de asumir compromisos que afectarían a toda la comunidad.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-22",
      "title": "Formación ciudadana ceremonial",
      "text": "El proyecto de democracia se limita a elecciones estudiantiles y no aborda deliberación ni control social escolar. El proyecto registró participación masiva en la última elección de personero. No obstante, los cursos reportan dificultad para argumentar desacuerdos y dar seguimiento a propuestas que recibieron votos. Varios actores proponen incorporar actividades novedosas, pero los planes de área no señalan desempeños ni evidencias comunes. El Consejo Académico solicita precisar la conexión entre la propuesta y las funciones escolares.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-23",
      "title": "Educación ambiental episódica",
      "text": "El colegio celebra un día ambiental con afiches, pero el PRAE carece de objetivos curriculares, responsables y evaluación. Las jornadas ambientales tienen gran convocatoria y una presencia constante en redes sociales. Sin embargo, los estudiantes no identifican vínculos entre los eventos, los aprendizajes de distintas áreas y el problema local elegido. El proyecto se ha desarrollado de forma distinta entre cursos y sedes, sin criterios compartidos sobre su contribución al aprendizaje. La dirección debe coordinar las responsabilidades curriculares y demostrar continuidad de las acciones.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-24",
      "title": "Presupuesto por prioridades",
      "text": "El fondo dispone de 45 millones y se proponen seguridad por 18, accesibilidad por 12, bibliotecas por 10 y señalización por 7. Las intervenciones se consideran necesarias, pero no todas tienen la misma urgencia ni pueden comprometerse sin fuente financiera. El equipo quiere reconocer la diferencia aritmética antes de evaluar alternativas de priorización. La tabla alimentará decisiones sobre distribución de apoyos institucionales y debe mantener las unidades originales. Los equipos solicitan que cada cálculo pueda reconstruirse a partir de las cifras de la premisa.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-25",
      "title": "Plan lector de biblioteca cerrada",
      "text": "La escuela recibe libros nuevos, pero la biblioteca permanece cerrada durante la jornada y no hay actividades curriculares asociadas. La biblioteca fue inaugurada públicamente y el inventario aparece completo, pero docentes y estudiantes no logran acceder a las colecciones en horarios de clase. El informe de gestión se centró en la entrega y no en usos formativos. Las actividades recibieron comentarios favorables, aunque las observaciones de aula muestran efectos desiguales. Antes de ampliar el proyecto, el equipo académico debe precisar qué resultados serían atribuibles a la intervención.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-26",
      "title": "IA para clasificar estudiantes",
      "text": "Una aplicación de IA etiqueta alumnado como propenso a desertar usando variables familiares sin evaluación de sesgos ni supervisión. La herramienta presenta puntuaciones numéricas y promete una predicción de alta precisión, pero no se conocen sus datos de entrenamiento. Algunas familias cuestionan las etiquetas y piden que ninguna decisión escolar dependa exclusivamente del algoritmo. El equipo tecnológico propone una solución operativa inmediata y las coordinaciones formulan reparos sobre su alcance. La dirección debe conservar el servicio educativo mientras define controles proporcionados a la información involucrada.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-27",
      "title": "Prácticas pedagógicas de universidad",
      "text": "La rectoría recibe una propuesta de investigación escolar con encuestas a menores y recogida de datos sensibles sin protocolo claro. Las encuestas incluyen preguntas sobre situaciones personales que podrían afectar privacidad y relaciones escolares. La universidad tiene interés académico legítimo, pero no ha precisado responsabilidades por el cuidado de información. Varios actores proponen incorporar actividades novedosas, pero los planes de área no señalan desempeños ni evidencias comunes. El Consejo Académico solicita precisar la conexión entre la propuesta y las funciones escolares.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-28",
      "title": "Promoción sin soporte",
      "text": "Al cierre del año, un comité propone promover a un grupo completo por presión de familias, aunque no revisó criterios del SIEE ni procesos de apoyo. El grupo presenta trayectorias heterogéneas y algunos estudiantes ya participaron en actividades de apoyo acordadas. El Consejo Académico solicita que la decisión deje constancia de los fundamentos aplicados a cada persona y de las rutas de reclamación. La propuesta provocó diferencias entre docentes que atienden el mismo grado. Las familias solicitan que se expliquen los criterios aplicables y que se respete la participación de los órganos responsables de orientar la evaluación.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-29",
      "title": "Seguimiento sin responsables",
      "text": "Tras aprobar el plan anual, siete acciones quedan asignadas de manera genérica a la comunidad educativa. Cada responsable interpreta el verbo implementar de forma diferente y los cortes de seguimiento producen reportes incomparables. La comunidad educativa reconoce avances informales, pero no logra establecer quién debe corregir las demoras detectadas. Las sedes recopilaron información mediante instrumentos distintos y el equipo de calidad advierte que los resultados pueden no ser comparables. La dirección necesita sustentar prioridades sin convertir el proceso en un trámite documental.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-30",
      "title": "Matrícula y certificación pendiente",
      "text": "Una niña con discapacidad solicita ingreso sin certificación médica concluida; secretaría sugiere posponer el cupo tres meses. La familia solicita iniciar cuanto antes las clases y presenta información de apoyos utilizados previamente, pero el expediente clínico está incompleto. La sede tiene docentes dispuestos a orientar adaptaciones iniciales y necesita definir el procedimiento de acceso. Las familias expresan preocupación por el acceso efectivo a las actividades ordinarias del establecimiento. El equipo docente dispone de información pedagógica parcial y debe decidir cómo iniciar apoyos sin convertir trámites en barreras de participación.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-31",
      "title": "Aula con desprendimientos",
      "text": "Docentes notifican desprendimiento de parte del techo, pero no hay diagnóstico técnico definitivo. Los desprendimientos ocurren cerca de puestos ocupados en dos turnos y la sede carece de otro salón de tamaño equivalente. El rector recibe presiones opuestas para continuar actividades o suspenderlas por completo. El cronograma académico resulta vulnerable a nuevas interrupciones y los responsables operativos solicitan instrucciones claras. Las familias reclaman información oportuna acerca de las condiciones de seguridad y de las alternativas disponibles.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-32",
      "title": "Padres exigen ranking público",
      "text": "Un grupo de familias solicita publicar listados nominales de estudiantes con bajo desempeño para exigir resultados. Los representantes sostienen que el listado estimularía acompañamiento familiar, mientras otros advierten el riesgo de exposición pública. Existen canales individuales de entrega de resultados y un informe institucional agregado. La participación ha sido desigual entre sectores de la comunidad y algunas familias señalan dificultades de comunicación. La rectoría necesita una respuesta que reconozca los intereses concurrentes y la competencia de los órganos escolares.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-33",
      "title": "Permiso y continuidad",
      "text": "Dos docentes solicitan permisos coincidentes en una sede unidocente y rectoría no ha previsto continuidad del servicio. La sede tiene una jornada con grupos que no pueden quedar sin acompañamiento y las peticiones tienen causas y tiempos distintos. La rectoría debe examinar obligaciones del servicio junto con las reglas que protegen el derecho a solicitar permiso. El cambio podría alterar la distribución de labores entre sedes y las condiciones de trabajo de varios equipos. Las coordinaciones solicitan criterios conocidos y un procedimiento que diferencie decisiones propias de rectoría de atribuciones externas.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-34",
      "title": "Costo unitario de un piloto",
      "text": "Una estrategia costó 9 millones y benefició a 150 estudiantes; otra costó 12 millones y benefició a 240, con aprendizajes comparables. El criterio de costo unitario servirá para decidir una expansión, aunque la rectoría reconoce que la calidad y la equidad deben examinarse junto con el gasto. La comparación usa población efectivamente beneficiada. La información procede de registros administrativos ordinarios y se divulgará en una reunión institucional. Los participantes deben poder comprobar los resultados sin mezclar poblaciones ni interpretaciones de indicadores.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-35",
      "title": "Causalidad en deserción",
      "text": "Un reporte concluye: 'La deserción descendió el año del cambio de uniforme; por tanto, el uniforme causó el descenso'. El cambio de uniforme coincidió con programas de transporte y acompañamiento, cuyo alcance no aparece en el informe. El texto no presenta comparaciones que permitan separar efectos de varias intervenciones simultáneas. El documento será utilizado para orientar futuras acciones y contiene afirmaciones sobre resultados educativos. El equipo debe precisar qué conclusiones están sostenidas y qué información permitiría someter las demás a contraste.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-36",
      "title": "Informe de satisfacción",
      "text": "Una encuesta voluntaria obtuvo 93 % de satisfacción entre 30 familias, aunque la institución tiene 800 acudientes convocados. Los resultados de la encuesta fueron ampliamente difundidos y se presentaron como aval institucional. No se conoce la participación por sede y una proporción elevada de acudientes no respondió la convocatoria. La afirmación se difundió como una conclusión institucional, aunque los participantes recibieron distintas versiones sobre sus fuentes. La rectoría propone distinguir entre datos observados, explicaciones posibles y afirmaciones que necesitan comprobación adicional.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-37",
      "title": "Reuniones sin acuerdos",
      "text": "Los equipos de área dedican horas a revisar informes, pero no documentan responsables ni cambios en prácticas de aula. Las actas muestran propuestas repetidas sin evidencia de ejecución y algunos docentes reconocen que nunca recibieron seguimiento. Se debate si el problema es falta de reuniones o ausencia de decisiones que transformen prácticas. El establecimiento afronta restricciones de tiempo y disponibilidad de personal. La rectoría necesita justificar cómo mantendrá la atención a estudiantes mientras revisa competencias, obligaciones y eventuales ajustes organizativos.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-38",
      "title": "Comercio vecino y publicidad",
      "text": "Una cadena comercial ofrece útiles a cambio de usar fotografías y nombres de estudiantes en campañas. La empresa plantea una difusión inmediata y afirma que la entrega de útiles es un beneficio suficiente. Varias familias no conocen la campaña, sus canales digitales ni el tiempo durante el cual las imágenes permanecerían disponibles. La participación ha sido desigual entre sectores de la comunidad y algunas familias señalan dificultades de comunicación. La rectoría necesita una respuesta que reconozca los intereses concurrentes y la competencia de los órganos escolares.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-39",
      "title": "Resultados de laboratorio sin seguridad",
      "text": "Una estrategia de experimentación aumenta el entusiasmo, pero incorpora reactivos sin protocolos y pretende ampliar su uso. La iniciativa tiene respaldo de familias interesadas en ciencias, pero la infraestructura presenta limitaciones de ventilación y almacenamiento. La coordinación pretende decidir antes del próximo período sin sacrificar resultados experimentales ni integridad física. Las actividades recibieron comentarios favorables, aunque las observaciones de aula muestran efectos desiguales. Antes de ampliar el proyecto, el equipo académico debe precisar qué resultados serían atribuibles a la intervención.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    },
    {
      "id": "S4-40",
      "title": "Contraseña compartida",
      "text": "Varios funcionarios utilizan la misma cuenta administrativa para modificar matrículas y las auditorías no identifican autores. La cuenta compartida se usa desde varios computadores y se han modificado datos importantes sin identificación de responsables. Un incidente reciente exige reconstruir quién efectuó los cambios y con qué autorización. Los datos disponibles provienen de sistemas con permisos y propósitos diferentes. Una revisión inicial advierte que mejorar la rapidez del proceso podría incrementar riesgos de acceso, registro o interpretación de información sensible.",
      "competency": "Gestión integral (sin clasificación en el documento)"
    }
  ],
  "questions": [
    {
      "id": 1,
      "situationId": "01",
      "competency": "GESTIÓN DIRECTIVA",
      "text": "¿Qué decisión inicial ofrece la mejor secuencia de direccionamiento institucional?",
      "options": [
        "Encargar a la consultora un documento base, socializarlo en una jornada docente y solicitar su aprobación tras incorporar observaciones.",
        "Conducir un diagnóstico participativo sustentado en datos, acordar prioridades y metas medibles y tramitar los ajustes del PEI mediante los órganos competentes.",
        "Autorizar a cada sede un PEI operativo autónomo y evaluar a final de año cuál de ellos produce mejores indicadores."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: Vincula evidencia, participación, coherencia intersedes y gobierno escolar antes de formalizar cambios.",
      "distractors": "Por qué no A: La asistencia técnica puede ayudar, pero no sustituye la construcción institucional ni resuelve por sí misma la falta de articulación. Por qué no C: Fragmentar el PEI debilita el proyecto común y posterga las obligaciones de dirección.",
      "legalBasis": "Ley 115 de 1994, arts. 73, 142-145; Resolución MEN 003842 de 2022, funciones 1, 2, 5 y 11."
    },
    {
      "id": 2,
      "situationId": "01",
      "competency": "GESTIÓN DIRECTIVA",
      "text": "¿Cuál sería el indicador más útil para evaluar la intervención en sexto?",
      "options": [
        "Comparar solo el promedio global de notas de sexto entre dos períodos, sin discriminar sedes ni situaciones de permanencia.",
        "Comparar por sede y cohorte la progresión del aprendizaje, la repitencia y la permanencia, con una línea de base y metas acordadas.",
        "Medir al cierre del trimestre la satisfacción de los docentes con el nuevo plan institucional y complementar con actas de reunión."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: Integra resultados académicos y trayectoria escolar con desagregación útil para corregir desigualdades.",
      "distractors": "Por qué no A: El promedio agregado oculta brechas y excluye estudiantes que abandonan. Por qué no C: La percepción de implementación es un indicador de proceso, no sustituye resultados estudiantiles.",
      "legalBasis": "Ley 115 de 1994, arts. 73, 142-145; Resolución MEN 003842 de 2022, funciones 1, 2, 5 y 11."
    },
    {
      "id": 3,
      "situationId": "01",
      "competency": "GESTIÓN DIRECTIVA",
      "text": "Ante la objeción de autonomía absoluta de las áreas, el rector debería:",
      "options": [
        "Reconocer la autonomía pedagógica dentro de los referentes curriculares, del PEI y de los acuerdos institucionales de evaluación y seguimiento.",
        "Permitir metodologías por docente mientras todos reporten las mismas calificaciones y mantengan la jornada establecida.",
        "Imponer un único guion de clase por asignatura sin discusión curricular para garantizar uniformidad de las sedes."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: La autonomía exige coherencia curricular y rendición pedagógica, pero no uniformidad mecánica.",
      "distractors": "Por qué no B: Unificar reportes no garantiza currículo común, pertinencia ni calidad de decisiones. Por qué no C: La imposición uniforme desplaza el juicio profesional y el gobierno académico.",
      "legalBasis": "Ley 115 de 1994, arts. 73, 142-145; Resolución MEN 003842 de 2022, funciones 1, 2, 5 y 11."
    },
    {
      "id": 4,
      "situationId": "01",
      "competency": "GESTIÓN DIRECTIVA",
      "text": "¿Qué papel debe tener el Consejo Académico en este proceso?",
      "options": [
        "Ratificar las decisiones del rector sobre recursos y aprobar por mayoría las inversiones asociadas al currículo.",
        "Estudiar y proponer ajustes curriculares y del plan de estudios y articular su análisis con las decisiones institucionales correspondientes.",
        "Sustituir al Consejo Directivo en la aprobación integral del PEI porque se trata principalmente de asuntos pedagógicos."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: Su función técnica es central en currículo y plan de estudios sin absorber competencias de otros órganos.",
      "distractors": "Por qué no A: La aprobación presupuestal y las decisiones del fondo corresponden a instancias diferenciadas. Por qué no C: Confunde la función académica con la del Consejo Directivo.",
      "legalBasis": "Ley 115 de 1994, arts. 73, 142-145; Resolución MEN 003842 de 2022, funciones 1, 2, 5 y 11."
    },
    {
      "id": 5,
      "situationId": "02",
      "competency": "GESTIÓN DIRECTIVA",
      "text": "¿Cómo debería responder ante la condición presupuestal?",
      "options": [
        "Separar los asuntos presupuestales de la modificación curricular, solicitar sustento técnico al Consejo Académico y seguir el trámite institucional correspondiente.",
        "Negarse a cualquier deliberación curricular del Consejo Directivo por tratarse de un asunto exclusivamente docente.",
        "Aceptar el cambio por un período piloto, siempre que las familias suscriban un compromiso de apoyo académico."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: Evita el intercambio impropio de competencias y permite una decisión motivada.",
      "distractors": "Por qué no B: El gobierno escolar implica interacción entre órganos; excluir la deliberación es excesivo. Por qué no C: Un piloto no elimina la necesidad de tramitar un cambio curricular con fundamento.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Decreto 1075 de 2015, gobierno escolar."
    },
    {
      "id": 6,
      "situationId": "02",
      "competency": "GESTIÓN DIRECTIVA",
      "text": "La decisión mejor fundamentada sobre las horas optativas exige:",
      "options": [
        "Priorizar la mejora inmediata del indicador de pruebas externas, dado que constituye el resultado público más visible.",
        "Conservar las horas sin análisis porque toda modificación solicitada por familias comprometería la autonomía escolar.",
        "Examinar coherencia con PEI, marco curricular, necesidades de aprendizaje y concepto académico, con participación y registro de la decisión."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Protege formación integral y trazabilidad de decisiones con evidencia.",
      "distractors": "Por qué no A: Un indicador no define por sí solo la totalidad del currículo. Por qué no B: La permanencia por inercia tampoco constituye ejercicio responsable de autonomía.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Decreto 1075 de 2015, gobierno escolar."
    },
    {
      "id": 7,
      "situationId": "02",
      "competency": "GESTIÓN DIRECTIVA",
      "text": "¿Qué error de gobierno escolar sería más grave?",
      "options": [
        "Presentar como decisión unilateral del rector una modificación sustantiva que requiere el trámite y la intervención de órganos colegiados.",
        "Publicar una síntesis de las razones pedagógicas de la decisión, preservando la documentación formal.",
        "Pedir al Consejo Académico una propuesta con alternativas y evidencia que luego pueda debatirse."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: La autoridad rectoral no elimina procedimientos ni competencias colegiadas.",
      "distractors": "Por qué no B: La comunicación transparente de decisiones motivadas es apropiada. Por qué no C: Esta actuación fortalece el análisis técnico y no es un error.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Decreto 1075 de 2015, gobierno escolar."
    },
    {
      "id": 8,
      "situationId": "02",
      "competency": "GESTIÓN DIRECTIVA",
      "text": "Si la disputa aumenta, la mejor estrategia de mediación sería:",
      "options": [
        "Delegar la resolución final a una encuesta abierta entre todas las familias, con independencia de la regulación escolar.",
        "Solicitar una votación inmediata para reducir la confrontación, sin modificar el orden del día ni revisar soportes.",
        "Establecer criterios compartidos de decisión, escuchar las posiciones y cerrar con acuerdos procedimentales y plazos verificables."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Diferencia la escucha democrática de la sustitución de competencias normadas.",
      "distractors": "Por qué no A: La consulta aporta insumos, pero no reemplaza las competencias legalmente asignadas. Por qué no B: Votar sin información suficiente puede formalizar una decisión deficiente.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Decreto 1075 de 2015, gobierno escolar."
    },
    {
      "id": 9,
      "situationId": "03",
      "competency": "GESTIÓN DIRECTIVA",
      "text": "¿Qué ajuste al plan resulta prioritario?",
      "options": [
        "Concentrar las actividades en una semana institucional e incrementar la asistencia de los docentes a los talleres.",
        "Establecer como meta adquirir un número fijo de libros por estudiante y dar por cumplido el plan cuando se entreguen.",
        "Incorporar diagnóstico por habilidades, metas observables, secuencia de intervención, responsables y verificación periódica del progreso de estudiantes."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Convierte actividades en una estrategia de mejora evaluable, vinculada al problema detectado.",
      "distractors": "Por qué no A: La participación en talleres no garantiza aprendizaje de los estudiantes. Por qué no B: Las compras son medios y no evidencian mejoramiento de comprensión.",
      "legalBasis": "Ley 115 de 1994, art. 80; Decreto 1290 de 2009; Resolución MEN 003842 de 2022."
    },
    {
      "id": 10,
      "situationId": "03",
      "competency": "GESTIÓN DIRECTIVA",
      "text": "La propuesta de la fundación debería valorarse principalmente por:",
      "options": [
        "La cantidad de libros disponibles y la posibilidad de visibilizar a la institución mediante la campaña publicitaria.",
        "Su pertinencia pedagógica, protección de datos de estudiantes y condiciones transparentes de aceptación y uso institucional.",
        "La gratuidad de la entrega, que exime al colegio de revisar contenidos y tratamiento de imágenes."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: Combina oportunidad del recurso con protección de derechos y necesidad educativa.",
      "distractors": "Por qué no A: El volumen y la visibilidad pueden ser secundarios, pero no sustituyen pertinencia. Por qué no C: La gratuidad no elimina obligaciones de protección de datos ni revisión académica.",
      "legalBasis": "Ley 115 de 1994, art. 80; Decreto 1290 de 2009; Resolución MEN 003842 de 2022."
    },
    {
      "id": 11,
      "situationId": "03",
      "competency": "GESTIÓN DIRECTIVA",
      "text": "¿Qué evidencia permite juzgar mejor el progreso del proyecto?",
      "options": [
        "Utilizar exclusivamente el resultado institucional promedio de una prueba externa al año siguiente.",
        "Contabilizar préstamo de libros y registrar opiniones positivas de estudiantes sobre actividades de lectura.",
        "Comparar desempeños en tareas equivalentes de inferencia antes y después de la intervención, desagregados y complementados con seguimiento formativo."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Mide la habilidad intervenida con instrumentos comparables y seguimiento cercano.",
      "distractors": "Por qué no A: Un agregado externo tardío dificulta atribución y ajustes oportunos. Por qué no B: El uso de recursos y la satisfacción no miden por sí solos la competencia lectora.",
      "legalBasis": "Ley 115 de 1994, art. 80; Decreto 1290 de 2009; Resolución MEN 003842 de 2022."
    },
    {
      "id": 12,
      "situationId": "03",
      "competency": "GESTIÓN DIRECTIVA",
      "text": "Ante docentes que cuestionan la pertinencia de los textos, el rector debe:",
      "options": [
        "Conservar todos los textos donados y exigir que se utilicen por igualdad de oportunidades entre áreas.",
        "Descartar la donación y sustituir la formación docente por trabajo autónomo de cada departamento.",
        "Articular al equipo académico para seleccionar materiales con criterios curriculares y evidencia de las necesidades lectoras."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Integra diagnóstico, currículo y trabajo colaborativo para aprovechar los recursos pertinentes.",
      "distractors": "Por qué no A: La uniformidad de uso no equivale a pertinencia pedagógica. Por qué no B: Desechar apoyo sin valoración técnica ni coordinación es una respuesta incompleta.",
      "legalBasis": "Ley 115 de 1994, art. 80; Decreto 1290 de 2009; Resolución MEN 003842 de 2022."
    },
    {
      "id": 13,
      "situationId": "04",
      "competency": "GESTIÓN DIRECTIVA",
      "text": "La prioridad inmediata del rector es:",
      "options": [
        "Adoptar medidas preventivas proporcionales al riesgo identificado, proteger a estudiantes y solicitar valoración técnica y apoyo competentes.",
        "Suspender toda la sede por tiempo indefinido hasta que exista presupuesto para obra mayor, sin alternativas pedagógicas.",
        "Mantener todas las clases porque todavía no existe un informe técnico final que pruebe la magnitud del riesgo."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: Combina precaución, proporcionalidad y continuidad posible del servicio.",
      "distractors": "Por qué no B: Una suspensión total sin análisis puede afectar innecesariamente la educación. Por qué no C: La ausencia de informe definitivo no justifica ignorar un peligro conocido.",
      "legalBasis": "Ley 115 de 1994, arts. 144-145; Decreto 1075 de 2015; Resolución MEN 003842 de 2022, funciones 3, 5 y 12."
    },
    {
      "id": 14,
      "situationId": "04",
      "competency": "GESTIÓN DIRECTIVA",
      "text": "Respecto de un traslado de recursos, corresponde:",
      "options": [
        "Ordenar el traslado inmediato por circular rectoral y ratificarlo ante el Consejo Directivo al finalizar el período.",
        "Solicitar a la asociación de padres que ejecute directamente los fondos institucionales mientras se formaliza el cambio.",
        "Verificar la disponibilidad y destinación permitida y tramitar el ajuste presupuestal mediante el Consejo Directivo según la regulación del fondo."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: El rector ordena gasto dentro de reglas presupuestales, sin sustituir las aprobaciones colegiadas requeridas.",
      "distractors": "Por qué no A: La urgencia no autoriza ignorar la competencia presupuestal correspondiente. Por qué no B: Los fondos públicos no pueden administrarse informalmente por un tercero.",
      "legalBasis": "Ley 115 de 1994, arts. 144-145; Decreto 1075 de 2015; Resolución MEN 003842 de 2022, funciones 3, 5 y 12."
    },
    {
      "id": 15,
      "situationId": "04",
      "competency": "GESTIÓN DIRECTIVA",
      "text": "Una decisión adecuada sobre continuidad educativa sería:",
      "options": [
        "Diseñar una reubicación temporal con seguimiento de condiciones de seguridad y aprendizajes mientras se resuelve la situación técnica.",
        "Dejar la decisión de ingresar o no al salón afectado a la voluntad individual de cada familia.",
        "Trasladar indefinidamente a toda la matrícula a trabajo en casa sin acompañamiento ni seguimiento."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: Garantiza continuidad con medidas operativas y supervisión del riesgo.",
      "distractors": "Por qué no B: La garantía de seguridad no se transfiere a decisiones individuales descoordinadas. Por qué no C: El trabajo en casa sin diseño educativo no asegura acceso ni permanencia.",
      "legalBasis": "Ley 115 de 1994, arts. 144-145; Decreto 1075 de 2015; Resolución MEN 003842 de 2022, funciones 3, 5 y 12."
    },
    {
      "id": 16,
      "situationId": "04",
      "competency": "GESTIÓN DIRECTIVA",
      "text": "¿Qué información debe comunicarse a la comunidad?",
      "options": [
        "El riesgo conocido, las medidas provisionales, las rutas de atención y los tiempos de actualización, evitando afirmaciones sin soporte.",
        "Que las obras serán iniciadas en una fecha cierta antes de contar con avales o asignaciones oficiales.",
        "Que la institución es completamente segura porque las áreas no afectadas operan normalmente."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: La comunicación responsable diferencia hechos, medidas y aspectos aún inciertos.",
      "distractors": "Por qué no B: Prometer plazos no confirmados afecta credibilidad y gestión. Por qué no C: Generaliza una conclusión que el informe no permite.",
      "legalBasis": "Ley 115 de 1994, arts. 144-145; Decreto 1075 de 2015; Resolución MEN 003842 de 2022, funciones 3, 5 y 12."
    },
    {
      "id": 17,
      "situationId": "05",
      "competency": "GESTIÓN DIRECTIVA",
      "text": "¿Cuál es la primera actuación institucionalmente más sólida?",
      "options": [
        "Solicitar al coordinador que declare el incumplimiento y remita directamente una sanción al docente.",
        "Contrastar registros de jornada, planeación y evidencias de atención estudiantil, escuchar al docente y organizar medidas inmediatas de recuperación académica.",
        "Dar por subsanadas las clases con base en la afirmación del docente y esperar los resultados del período."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: Reúne evidencia, debido proceso y restablecimiento pedagógico de la continuidad.",
      "distractors": "Por qué no A: Un informe de coordinación no sustituye el procedimiento ni la autoridad competente. Por qué no C: La declaración aislada es insuficiente ante evidencias de estudiantes sin atención.",
      "legalBasis": "Resolución MEN 003842 de 2022, funciones 9, 14, 15, 17 y 18; Decreto Ley 1278 de 2002."
    },
    {
      "id": 18,
      "situationId": "05",
      "competency": "GESTIÓN DIRECTIVA",
      "text": "En cuanto a presuntas irregularidades del personal, el rector debe:",
      "options": [
        "Publicar en la página institucional los nombres de los docentes señalados y las faltas presuntas.",
        "Documentar objetivamente los hechos y remitir por los canales y autoridades competentes, sin anticipar sanciones.",
        "Imponer una suspensión preventiva inmediata con base en las quejas, para evitar reincidencia."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: Cumple deberes de dirección y reporte respetando garantías y reserva.",
      "distractors": "Por qué no A: La divulgación puede afectar derechos y no mejora la investigación. Por qué no C: Una sanción sin competencia y procedimiento vulnera garantías.",
      "legalBasis": "Resolución MEN 003842 de 2022, funciones 9, 14, 15, 17 y 18; Decreto Ley 1278 de 2002."
    },
    {
      "id": 19,
      "situationId": "05",
      "competency": "GESTIÓN DIRECTIVA",
      "text": "Para evaluar recuperación de aprendizajes, el mejor enfoque es:",
      "options": [
        "Incrementar la nota final de las clases afectadas a fin de evitar repitencia asociada al incidente.",
        "Identificar estudiantes y aprendizajes afectados, acordar apoyos diferenciados y comprobar evidencias de progreso.",
        "Solicitar que todos los docentes aumenten una evaluación escrita para compensar las horas no trabajadas."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: Prioriza el derecho efectivo al aprendizaje, no ajustes cosméticos de calificación.",
      "distractors": "Por qué no A: Inflar calificaciones oculta el déficit pedagógico. Por qué no C: Más evaluación sin enseñanza puede agravar brechas.",
      "legalBasis": "Resolución MEN 003842 de 2022, funciones 9, 14, 15, 17 y 18; Decreto Ley 1278 de 2002."
    },
    {
      "id": 20,
      "situationId": "05",
      "competency": "GESTIÓN DIRECTIVA",
      "text": "La comunicación con las familias debe:",
      "options": [
        "Afirmar que no hubo interrupción porque se compartieron guías digitales a algunos cursos.",
        "Suspender toda respuesta hasta que concluya un eventual proceso disciplinario.",
        "Reconocer las interrupciones verificadas, explicar apoyos y canales de seguimiento, sin prejuzgar responsabilidades individuales."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Rinde cuentas y atiende la continuidad sin prejuzgamiento.",
      "distractors": "Por qué no A: Confunde envío parcial de material con prestación plena del servicio. Por qué no B: La atención pedagógica y comunicación no dependen del cierre disciplinario.",
      "legalBasis": "Resolución MEN 003842 de 2022, funciones 9, 14, 15, 17 y 18; Decreto Ley 1278 de 2002."
    },
    {
      "id": 21,
      "situationId": "06",
      "competency": "GESTIÓN DIRECTIVA",
      "text": "La respuesta pedagógica más consistente es:",
      "options": [
        "Organizar acogida, valoración de aprendizajes y apoyos flexibles dentro del proyecto institucional, con revisión participativa de barreras.",
        "Mantener las estrategias habituales hasta la siguiente actualización formal del PEI, para evitar cambios a mitad de año.",
        "Crear grupos permanentes por procedencia, aun cuando estudiantes demuestren competencias similares a las de sus compañeros."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: La respuesta combina acceso, valoración e integración sin segregación innecesaria.",
      "distractors": "Por qué no B: El PEI orienta, pero no justifica retrasar apoyos urgentes. Por qué no C: La procedencia no es criterio suficiente para agrupar permanentemente.",
      "legalBasis": "Ley 115 de 1994, arts. 73 y 77; Resolución MEN 003842 de 2022, funciones 1, 11 y 19."
    },
    {
      "id": 22,
      "situationId": "06",
      "competency": "GESTIÓN DIRECTIVA",
      "text": "¿Cómo incorporar la situación al PEI?",
      "options": [
        "Delegar la redacción completa a un aliado externo para aplicarla como circular rectoral.",
        "A partir de diagnóstico territorial y aportes de comunidad, proponer ajustes curriculares, de convivencia y de acompañamiento para trámite institucional.",
        "Agregar un anexo estadístico con número de nuevos estudiantes, sin revisar prácticas ni metas."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: La actualización del PEI requiere apropiación y transformación de prácticas.",
      "distractors": "Por qué no A: La autoría externa no sustituye deliberación y procedimientos internos. Por qué no C: Describir matrícula no equivale a responder pedagógicamente.",
      "legalBasis": "Ley 115 de 1994, arts. 73 y 77; Resolución MEN 003842 de 2022, funciones 1, 11 y 19."
    },
    {
      "id": 23,
      "situationId": "06",
      "competency": "GESTIÓN DIRECTIVA",
      "text": "¿Cuál sería un indicador relevante de inclusión y permanencia?",
      "options": [
        "Seguimiento por cohortes a asistencia, progreso académico y participación de los estudiantes recién incorporados.",
        "Proporción de familias nuevas que asisten a un acto de bienvenida, sin explorar necesidades de apoyo.",
        "Número total de estudiantes matriculados al cierre, sin distinguir ingresos, salidas ni trayectorias."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: Cruza acceso, continuidad y aprendizaje en la población objetivo.",
      "distractors": "Por qué no B: La asistencia al evento es un dato de proceso, insuficiente por sí solo. Por qué no C: La matrícula neta oculta movilidad y deserción.",
      "legalBasis": "Ley 115 de 1994, arts. 73 y 77; Resolución MEN 003842 de 2022, funciones 1, 11 y 19."
    },
    {
      "id": 24,
      "situationId": "06",
      "competency": "GESTIÓN DIRECTIVA",
      "text": "Frente a la limitación de personal, corresponde:",
      "options": [
        "Condicionar nuevas matrículas a la ampliación de planta que solicite el establecimiento.",
        "Pedir a las familias cubrir de manera particular las necesidades de apoyo escolar que surjan.",
        "Priorizar apoyos posibles, documentar barreras y gestionar ante la entidad territorial los recursos y acompañamientos necesarios."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Distingue obligaciones institucionales y competencias territoriales sin restringir el acceso.",
      "distractors": "Por qué no A: La insuficiencia de planta no autoriza excluir estudiantes. Por qué no B: Transferir obligaciones institucionales a familias agrava desigualdades.",
      "legalBasis": "Ley 115 de 1994, arts. 73 y 77; Resolución MEN 003842 de 2022, funciones 1, 11 y 19."
    },
    {
      "id": 25,
      "situationId": "07",
      "competency": "GESTIÓN ACADÉMICA",
      "text": "¿Cuál procedimiento corresponde?",
      "options": [
        "Promover a la estudiante por resolución rectoral tras verificar el promedio superior, sin intervención de órganos escolares.",
        "Aplicar criterios del SIEE, obtener valoración del Consejo Académico y, con consentimiento familiar, elevar recomendación al Consejo Directivo en el primer período.",
        "Esperar al último período para definir promoción anticipada porque así se completaría la evidencia de todas las áreas."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: Respeta momento temporal, evaluación integral y secuencia de órganos prevista en la norma.",
      "distractors": "Por qué no A: La decisión no se agota en promedio ni corresponde unilateralmente al rector. Por qué no C: La promoción anticipada regulada se valora durante el primer período.",
      "legalBasis": "Decreto 1290 de 2009, art. 7; Decreto 1075 de 2015, SIEE."
    },
    {
      "id": 26,
      "situationId": "07",
      "competency": "GESTIÓN ACADÉMICA",
      "text": "La evidencia académica más pertinente sería:",
      "options": [
        "Un conjunto de desempeños cognitivos, personales y sociales frente a competencias del grado, conforme al SIEE.",
        "El promedio de pruebas externas de la estudiante y la calificación numérica más reciente de matemáticas.",
        "La opinión mayoritaria del curso y el compromiso de la familia de asumir tutorías particulares."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: La norma exige desempeño superior y valoración amplia, no un dato aislado.",
      "distractors": "Por qué no B: Una muestra parcial no representa integralmente las competencias requeridas. Por qué no C: La opinión de pares y la capacidad de financiar apoyos no sustituyen criterios académicos.",
      "legalBasis": "Decreto 1290 de 2009, art. 7; Decreto 1075 de 2015, SIEE."
    },
    {
      "id": 27,
      "situationId": "07",
      "competency": "GESTIÓN ACADÉMICA",
      "text": "Si el Consejo Académico recomienda y el Consejo Directivo decide positivamente, el rector debe:",
      "options": [
        "Volver a someter el caso a votación general del profesorado para ratificar el tránsito.",
        "Comunicar verbalmente la decisión y aplazar todo registro hasta que se confirme buen rendimiento en el nuevo grado.",
        "Asegurar registro del acta y actualización del registro escolar y planificar acompañamiento de transición."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: La decisión positiva debe quedar documentada y acompañarse pedagógicamente.",
      "distractors": "Por qué no A: La votación general no forma parte del procedimiento decisorio previsto. Por qué no B: La informalidad del registro desconoce la trazabilidad exigida.",
      "legalBasis": "Decreto 1290 de 2009, art. 7; Decreto 1075 de 2015, SIEE."
    },
    {
      "id": 28,
      "situationId": "07",
      "competency": "GESTIÓN ACADÉMICA",
      "text": "¿Qué razonamiento es más sólido frente a la objeción de posibles vacíos?",
      "options": [
        "Considerar los riesgos de adaptación dentro de la valoración integral y prever apoyos, sin convertirlos en una prohibición genérica.",
        "Conceder promoción únicamente si la estudiante acepta exámenes de todas las asignaturas cada mes.",
        "Concluir que toda promoción anticipada genera vacíos y, por prudencia, negar aun con evidencia superior."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: La prudencia exige valoración y apoyo individual, no vetos automáticos.",
      "distractors": "Por qué no B: La condición adicional puede no estar prevista ni guardar proporcionalidad con el caso. Por qué no C: Generaliza un riesgo sin contrastar las evidencias específicas.",
      "legalBasis": "Decreto 1290 de 2009, art. 7; Decreto 1075 de 2015, SIEE."
    },
    {
      "id": 29,
      "situationId": "08",
      "competency": "GESTIÓN ACADÉMICA",
      "text": "¿Cuál medida atiende mejor el problema inmediato?",
      "options": [
        "Anular todas las evaluaciones de matemáticas de forma general, sin analizar procedimientos ni evidencias.",
        "Autorizar que cada docente aplique sus propios criterios de recuperación, siempre que los informe al cierre del año.",
        "Verificar aplicación del SIEE vigente, tramitar reclamaciones y asegurar apoyos y comunicación clara de criterios previamente establecidos."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Garantiza reglas conocidas, debido procedimiento pedagógico y apoyos.",
      "distractors": "Por qué no A: La anulación general desconoce casos válidos y carece de análisis proporcional. Por qué no B: Criterios retrospectivos o fragmentados vulneran coherencia institucional.",
      "legalBasis": "Decreto 1290 de 2009, arts. 3, 4, 6, 8 y 11; Decreto 1075 de 2015."
    },
    {
      "id": 30,
      "situationId": "08",
      "competency": "GESTIÓN ACADÉMICA",
      "text": "Para modificar el SIEE en adelante, lo más correcto es:",
      "options": [
        "Adelantar revisión participativa y los trámites de aprobación y divulgación establecidos, sin aplicar retroactivamente reglas perjudiciales.",
        "Esperar exclusivamente a que la Secretaría de Educación dicte el porcentaje mínimo de aprobación por asignatura.",
        "Permitir que el rector cambie por circular los porcentajes de calificación aplicables al período terminado."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: La autonomía institucional opera mediante procedimientos y publicidad de criterios.",
      "distractors": "Por qué no B: La entidad territorial no reemplaza toda decisión institucional del SIEE. Por qué no C: Modificar reglas después de evaluar afecta seguridad y debido proceso.",
      "legalBasis": "Decreto 1290 de 2009, arts. 3, 4, 6, 8 y 11; Decreto 1075 de 2015."
    },
    {
      "id": 31,
      "situationId": "08",
      "competency": "GESTIÓN ACADÉMICA",
      "text": "¿Qué indicador detectaría mejor si las estrategias de apoyo funcionan?",
      "options": [
        "Porcentaje de estudiantes que supera dificultades específicas verificadas mediante tareas comparables y seguimiento de progreso.",
        "Cantidad de reuniones con familias y de guías enviadas durante el período.",
        "Porcentaje de estudiantes promovidos, sin analizar cambios en aprendizajes o apoyos efectivamente prestados."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: Comprueba recuperación de competencias, no solo resultado administrativo.",
      "distractors": "Por qué no B: Las actividades son medios y no resultados pedagógicos suficientes. Por qué no C: La promoción puede aumentar sin aprendizaje sustantivo.",
      "legalBasis": "Decreto 1290 de 2009, arts. 3, 4, 6, 8 y 11; Decreto 1075 de 2015."
    },
    {
      "id": 32,
      "situationId": "08",
      "competency": "GESTIÓN ACADÉMICA",
      "text": "Frente a una reclamación documentada, el rector debe:",
      "options": [
        "Negar la petición porque la evaluación pertenece a la autonomía absoluta de cada docente.",
        "Remitir toda reclamación a la Secretaría sin intervención institucional, incluso cuando el SIEE prevé instancias internas.",
        "Garantizar respuesta según el procedimiento institucional, revisar evidencias y explicar la decisión motivadamente."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: La autonomía evaluativa está regulada por el SIEE y admite revisión institucional.",
      "distractors": "Por qué no A: La autonomía no excluye reclamación ni criterios institucionales. Por qué no B: La remisión automática evade responsabilidades propias del establecimiento.",
      "legalBasis": "Decreto 1290 de 2009, arts. 3, 4, 6, 8 y 11; Decreto 1075 de 2015."
    },
    {
      "id": 33,
      "situationId": "09",
      "competency": "GESTIÓN ACADÉMICA",
      "text": "¿Qué decisión responde mejor a la normativa de inclusión?",
      "options": [
        "Mantener todas las actividades sin adaptación y asignar aprobación por asistencia para evitar discriminación.",
        "Realizar valoración pedagógica, diseñar e implementar ajustes razonables y PIAR articulado al aula, con participación familiar y seguimiento.",
        "Aceptar la matrícula, pero esperar el diagnóstico clínico actualizado para iniciar cualquier ajuste del currículo y la evaluación."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: Los apoyos surgen de barreras y valoración pedagógica, sin reemplazar el aprendizaje por presencia.",
      "distractors": "Por qué no A: La asistencia sin metas ni evaluación de progreso es inclusión solo nominal. Por qué no C: Condicionar apoyos a un certificado retarda el derecho a aprender.",
      "legalBasis": "Decreto 1421 de 2017, arts. incorporados al Decreto 1075 de 2015 sobre DUA, PIAR y no discriminación."
    },
    {
      "id": 34,
      "situationId": "09",
      "competency": "GESTIÓN ACADÉMICA",
      "text": "¿Cómo se relacionan DUA y PIAR?",
      "options": [
        "El DUA orienta transformaciones accesibles para todo el grupo y el PIAR complementa con apoyos individuales requeridos.",
        "El PIAR sustituye todas las prácticas de aula y permite retirar a la estudiante del currículo institucional.",
        "El DUA elimina la necesidad de valorar y documentar ajustes individuales en estudiantes que los requieran."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: Ambos enfoques se complementan: acceso general y apoyos particulares.",
      "distractors": "Por qué no B: El PIAR no equivale a un currículo aislado ni excluyente. Por qué no C: Un diseño universal puede coexistir con barreras particulares no resueltas.",
      "legalBasis": "Decreto 1421 de 2017, arts. incorporados al Decreto 1075 de 2015 sobre DUA, PIAR y no discriminación."
    },
    {
      "id": 35,
      "situationId": "09",
      "competency": "GESTIÓN ACADÉMICA",
      "text": "La promoción de la estudiante debe decidirse:",
      "options": [
        "Con el mismo examen sin ajustes de todo el grupo porque modificar la evaluación sería una ventaja indebida.",
        "Con el SIEE y la valoración de avances, teniendo en cuenta ajustes curriculares, trayectoria y apoyos previstos.",
        "Automáticamente por el hecho de contar con un PIAR diligenciado al inicio del año escolar."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: Se requieren criterios de evaluación pertinentes, no igualdad entendida como uniformidad.",
      "distractors": "Por qué no A: Exigir idéntico formato desconoce ajustes razonables. Por qué no C: El documento PIAR no sustituye la evidencia de aprendizaje.",
      "legalBasis": "Decreto 1421 de 2017, arts. incorporados al Decreto 1075 de 2015 sobre DUA, PIAR y no discriminación."
    },
    {
      "id": 36,
      "situationId": "09",
      "competency": "GESTIÓN ACADÉMICA",
      "text": "¿Qué debe hacer el rector ante necesidades de recursos superiores a la capacidad escolar?",
      "options": [
        "Negar continuidad hasta recibir docente de apoyo de dedicación exclusiva.",
        "Recomendar traslado inmediato a una institución segregada por considerar insuficiente la dotación.",
        "Incorporar ajustes al PMI, desplegar apoyos disponibles y gestionar articulación con la entidad territorial."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: La rectoría gestiona barreras y recursos sin suspender derechos.",
      "distractors": "Por qué no A: La falta de un recurso particular no habilita negar educación. Por qué no B: La segregación automática contradice el enfoque inclusivo.",
      "legalBasis": "Decreto 1421 de 2017, arts. incorporados al Decreto 1075 de 2015 sobre DUA, PIAR y no discriminación."
    },
    {
      "id": 37,
      "situationId": "10",
      "competency": "GESTIÓN ACADÉMICA",
      "text": "¿Cuál es la interpretación más rigurosa?",
      "options": [
        "Desestimar todo resultado externo porque las variaciones de cobertura impiden cualquier interpretación.",
        "Reportar la mejora observada con reserva por cambios de cobertura, analizar distribución y trayectorias antes de atribuir éxito a una estrategia.",
        "Concluir que el plan de calidad elevó el aprendizaje de toda la cohorte porque el promedio aumentó tres puntos."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: La variación de cobertura puede sesgar comparación y requiere triangulación.",
      "distractors": "Por qué no A: Los datos aún son útiles si se interpretan con sus limitaciones. Por qué no C: El promedio no permite inferir impacto en quienes dejaron de participar.",
      "legalBasis": "Decreto 1290 de 2009; Ley 115 de 1994, art. 80; Resolución MEN 003842 de 2022."
    },
    {
      "id": 38,
      "situationId": "10",
      "competency": "GESTIÓN ACADÉMICA",
      "text": "Para mejorar la comparabilidad entre cohortes, conviene:",
      "options": [
        "Desagregar por condiciones relevantes y contrastar cobertura, dispersión, permanencia y desempeños internos.",
        "Comparar únicamente a quienes obtuvieron resultados superiores, excluyendo los desempeños bajos.",
        "Ajustar manualmente el puntaje de la cohorte más pequeña hasta igualar el número de estudiantes."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: Explicita composición y evita sesgos de selección.",
      "distractors": "Por qué no B: Excluir puntajes bajos distorsiona el desempeño institucional. Por qué no C: Cambiar resultados sin base técnica falsea el análisis.",
      "legalBasis": "Decreto 1290 de 2009; Ley 115 de 1994, art. 80; Resolución MEN 003842 de 2022."
    },
    {
      "id": 39,
      "situationId": "10",
      "competency": "GESTIÓN ACADÉMICA",
      "text": "¿Qué decisión de mejoramiento sería prioritaria?",
      "options": [
        "Intensificar la preparación de los mejores estudiantes para sostener el promedio institucional.",
        "Reducir la presentación de estudiantes con riesgo de bajo resultado para conservar el indicador agregado.",
        "Indagar causas de la reducción de participantes y diseñar apoyos de permanencia y aprendizaje con evaluación de resultados."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Mejora calidad con equidad, cobertura y aprendizaje.",
      "distractors": "Por qué no A: Concentrarse en quienes ya destacan puede ampliar brechas. Por qué no B: Excluir estudiantes para mejorar cifras vulnera el propósito educativo.",
      "legalBasis": "Decreto 1290 de 2009; Ley 115 de 1994, art. 80; Resolución MEN 003842 de 2022."
    },
    {
      "id": 40,
      "situationId": "10",
      "competency": "GESTIÓN ACADÉMICA",
      "text": "Un informe confiable a la comunidad debe incluir:",
      "options": [
        "Resultados, cobertura, límites de comparabilidad y compromisos verificables de mejora.",
        "Una conclusión de fracaso general porque algunos estudiantes no presentaron la prueba.",
        "Una gráfica del promedio ascendente y un mensaje de éxito sin información de participación."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: Balancea información favorable y advertencias, con responsabilidad institucional.",
      "distractors": "Por qué no B: Una sola limitación no justifica negar cualquier resultado positivo. Por qué no C: Omitir cobertura induce una lectura excesivamente optimista.",
      "legalBasis": "Decreto 1290 de 2009; Ley 115 de 1994, art. 80; Resolución MEN 003842 de 2022."
    },
    {
      "id": 41,
      "situationId": "11",
      "competency": "GESTIÓN ACADÉMICA",
      "text": "La decisión inicial más sólida es:",
      "options": [
        "Prohibir cualquier herramienta digital hasta demostrar que supera a la enseñanza tradicional en todas las áreas.",
        "Definir un piloto acotado con objetivos pedagógicos, alternativas de acceso, protección de datos, consentimiento aplicable y evaluación comparativa.",
        "Adoptar la plataforma para todos los cursos con base en la promesa comercial y evaluar satisfacción al finalizar."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: Gestiona innovación como hipótesis pedagógica sometida a evidencias y derechos.",
      "distractors": "Por qué no A: La prohibición absoluta desconoce la posibilidad de pilotajes responsables. Por qué no C: Una promesa comercial no prueba impacto ni cubre riesgos.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de pedagogía, didáctica e innovación; Decreto 1290 de 2009."
    },
    {
      "id": 42,
      "situationId": "11",
      "competency": "GESTIÓN ACADÉMICA",
      "text": "¿Qué criterio permitiría evaluar valor educativo real?",
      "options": [
        "Número de licencias activas y aceptación de la empresa entre directivos.",
        "Cantidad de ingresos diarios y tiempo promedio de conexión como único indicador.",
        "Cambios en aprendizajes relevantes, equidad de participación, carga docente y evidencia de uso frente a metas definidas."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Combina efectividad, equidad y viabilidad de implementación.",
      "distractors": "Por qué no A: Las licencias son insumos administrativos, no resultados educativos. Por qué no B: Uso intensivo no necesariamente produce aprendizaje.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de pedagogía, didáctica e innovación; Decreto 1290 de 2009."
    },
    {
      "id": 43,
      "situationId": "11",
      "competency": "GESTIÓN ACADÉMICA",
      "text": "¿Cómo resolver la brecha de conectividad en el piloto?",
      "options": [
        "Ofrecer vías equivalentes de participación y monitorear si el acceso modifica los resultados obtenidos.",
        "Permitir que quienes carecen de acceso pierdan actividades para incentivar la adquisición de dispositivos.",
        "Aplicar la plataforma solamente a estudiantes conectados y extrapolar resultados a toda la matrícula."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: El diseño de evaluación debe impedir exclusiones y sesgo por acceso.",
      "distractors": "Por qué no B: Penalizar por recursos económicos vulnera equidad. Por qué no C: Una muestra privilegiada limita generalización.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de pedagogía, didáctica e innovación; Decreto 1290 de 2009."
    },
    {
      "id": 44,
      "situationId": "11",
      "competency": "GESTIÓN ACADÉMICA",
      "text": "La relación de la innovación con el PEI debe:",
      "options": [
        "Subordinar el PEI a las especificaciones del proveedor mientras dure la licencia.",
        "Ser explicitada en los propósitos de aprendizaje y revisada colegiadamente antes de institucionalizarla.",
        "Considerarse innecesaria porque la tecnología es solo un soporte operativo sin efecto curricular."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: Toda transformación metodológica relevante requiere coherencia institucional.",
      "distractors": "Por qué no A: Un proveedor no define fines educativos institucionales. Por qué no C: La herramienta puede afectar evaluación, didáctica y participación.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de pedagogía, didáctica e innovación; Decreto 1290 de 2009."
    },
    {
      "id": 45,
      "situationId": "12",
      "competency": "GESTIÓN ACADÉMICA",
      "text": "¿Cuál debería ser la prioridad académica y administrativa?",
      "options": [
        "Suprimir permanentemente las horas artísticas por decisión de coordinación y luego formalizar el cambio curricular.",
        "Gestionar provisión ante la autoridad competente y una reorganización transitoria motivada que proteja el plan de estudios y la continuidad.",
        "Trasladar los grupos a actividades libres sin planeación hasta que se produzca el nombramiento."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: Combina medidas institucionales temporales y gestión de planta ante quien corresponde.",
      "distractors": "Por qué no A: El carácter urgente no autoriza modificar de hecho el plan de estudios permanente. Por qué no C: La espera pasiva produce pérdida evitable de aprendizaje.",
      "legalBasis": "Resolución MEN 003842 de 2022, funciones 8 y 9; Ley 115 de 1994; Decreto 1075 de 2015."
    },
    {
      "id": 46,
      "situationId": "12",
      "competency": "GESTIÓN ACADÉMICA",
      "text": "¿Cómo valorar la propuesta de reducir arte?",
      "options": [
        "Aceptarla porque ciencias obtiene mejores ponderaciones en las pruebas externas y por ello debe prevalecer siempre.",
        "Rechazarla sin revisar las cargas disponibles porque cualquier cambio de horario equivale a reformar el PEI.",
        "Analizar alternativas con el equipo académico y riesgos formativos antes de aplicar medidas proporcionales y temporales."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: La priorización necesita justificación y protección de formación integral.",
      "distractors": "Por qué no A: Los resultados externos no anulan otras áreas obligatorias. Por qué no B: La reorganización provisional no es necesariamente una reforma curricular.",
      "legalBasis": "Resolución MEN 003842 de 2022, funciones 8 y 9; Ley 115 de 1994; Decreto 1075 de 2015."
    },
    {
      "id": 47,
      "situationId": "12",
      "competency": "GESTIÓN ACADÉMICA",
      "text": "¿Qué seguimiento al plan transitorio resulta útil?",
      "options": [
        "Comparar solo la puntualidad de ingreso al establecimiento durante las cuatro semanas.",
        "Medir únicamente la cantidad de docentes que aceptó el nuevo horario.",
        "Registrar horas efectivas, competencias atendidas, estudiantes afectados y medidas de recuperación por área."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Relaciona continuidad efectiva con cobertura curricular y apoyos.",
      "distractors": "Por qué no A: La puntualidad es relevante pero no mide aprendizajes ni horas cubiertas. Por qué no B: La aceptación docente no prueba atención educativa.",
      "legalBasis": "Resolución MEN 003842 de 2022, funciones 8 y 9; Ley 115 de 1994; Decreto 1075 de 2015."
    },
    {
      "id": 48,
      "situationId": "12",
      "competency": "GESTIÓN ACADÉMICA",
      "text": "Si la entidad territorial tarda en proveer vacantes, el rector debe:",
      "options": [
        "Escalar la necesidad con evidencia de afectación y actualizar medidas institucionales dentro de su competencia.",
        "Mantener inalterado el plan transitorio aun si aumenta la pérdida de clases, para evitar cambios administrativos.",
        "Nombrar provisionalmente docentes externos con recursos del Fondo de Servicios Educativos sin trámite legal."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: Sostiene gestión responsable y límites competenciales.",
      "distractors": "Por qué no B: Las medidas deben revisarse según su eficacia y el riesgo. Por qué no C: El fondo no puede utilizarse para sustituir nombramientos de planta ordinaria.",
      "legalBasis": "Resolución MEN 003842 de 2022, funciones 8 y 9; Ley 115 de 1994; Decreto 1075 de 2015."
    },
    {
      "id": 49,
      "situationId": "13",
      "competency": "GESTIÓN ADMINISTRATIVA",
      "text": "¿Qué actuación concilia urgencia y legalidad?",
      "options": [
        "Abrir una colecta obligatoria entre familias y comprar directamente por fuera del FSE para evitar procedimientos.",
        "Pagar un anticipo al proveedor con recursos existentes y tramitar después la adición presupuestal porque la urgencia es pedagógica.",
        "Asegurar continuidad provisional y adelantar las decisiones presupuestales y contractuales exigibles, con trazabilidad y aprobación del órgano competente cuando proceda."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: La urgencia exige celeridad dentro de la legalidad, no ejecución sin soporte.",
      "distractors": "Por qué no A: Una contribución obligatoria externa sustituye irregularmente deberes y puede afectar derechos. Por qué no B: La necesidad no habilita comprometer apropiaciones sin el procedimiento pertinente.",
      "legalBasis": "Decreto 4791 de 2008, arts. 3-5 y normas sobre FSE incorporadas en Decreto 1075 de 2015; Resolución MEN 003842 de 2022."
    },
    {
      "id": 50,
      "situationId": "13",
      "competency": "GESTIÓN ADMINISTRATIVA",
      "text": "En la gestión del presupuesto del FSE corresponde distinguir:",
      "options": [
        "El rector ordena el gasto dentro de sus atribuciones y el Consejo Directivo ejerce funciones de aprobación y seguimiento presupuestal.",
        "El rector aprueba unilateralmente el presupuesto anual y el Consejo Directivo solo recibe un informe sin facultad de ajuste.",
        "El Consejo Académico autoriza las compras y el coordinador efectúa los pagos por representar el componente pedagógico."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: Identifica la distribución normativa de responsabilidades sin confundir ejecución y aprobación.",
      "distractors": "Por qué no B: Desconoce la competencia presupuestal del Consejo Directivo. Por qué no C: Los órganos académicos no sustituyen los procedimientos financieros del FSE.",
      "legalBasis": "Decreto 4791 de 2008, arts. 3-5 y normas sobre FSE incorporadas en Decreto 1075 de 2015; Resolución MEN 003842 de 2022."
    },
    {
      "id": 51,
      "situationId": "13",
      "competency": "GESTIÓN ADMINISTRATIVA",
      "text": "Una condición de transparencia particularmente importante es:",
      "options": [
        "Confiar en la reputación del proveedor y conservar un comprobante de pago como soporte integral.",
        "Documentar necesidad, estudios y decisiones pertinentes, ejecución y rendición de cuentas de los recursos públicos.",
        "Publicar únicamente una fotografía de los equipos adquiridos y la cantidad de beneficiarios."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: La trazabilidad cubre el ciclo del recurso y facilita control.",
      "distractors": "Por qué no A: La reputación comercial no sustituye soportes técnicos y administrativos. Por qué no C: La evidencia de entrega no equivale a cuenta contractual y presupuestal.",
      "legalBasis": "Decreto 4791 de 2008, arts. 3-5 y normas sobre FSE incorporadas en Decreto 1075 de 2015; Resolución MEN 003842 de 2022."
    },
    {
      "id": 52,
      "situationId": "13",
      "competency": "GESTIÓN ADMINISTRATIVA",
      "text": "Sobre las clases de laboratorio afectadas, el rector debe:",
      "options": [
        "Suspender indefinidamente toda actividad de ciencias hasta completar la compra de equipos nuevos.",
        "Acordar alternativas pedagógicas seguras y verificar recuperación de experiencias de aprendizaje mientras se repara la infraestructura.",
        "Asignar la calificación máxima al curso para compensar la suspensión accidental del laboratorio."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: Protege seguridad y aprendizaje mediante soluciones temporales verificables.",
      "distractors": "Por qué no A: La suspensión completa puede ser innecesaria si existen alternativas pertinentes. Por qué no C: La nota no reemplaza el desarrollo de competencias prácticas.",
      "legalBasis": "Decreto 4791 de 2008, arts. 3-5 y normas sobre FSE incorporadas en Decreto 1075 de 2015; Resolución MEN 003842 de 2022."
    },
    {
      "id": 53,
      "situationId": "14",
      "competency": "GESTIÓN ADMINISTRATIVA",
      "text": "La conducta más apropiada del rector es:",
      "options": [
        "Aceptar la oferta por economía porque el valor cabe en el presupuesto y el parentesco no prueba un sobreprecio.",
        "Solicitar al integrante cuestionado que escoja dos proveedores alternativos y adjudicar al de menor valor sin soportes técnicos.",
        "Documentar la necesidad, verificar conflictos de interés e impedimentos aplicables y adelantar selección y contratación conforme al régimen pertinente."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: La decisión exige gestión preventiva de conflictos y trazabilidad técnica.",
      "distractors": "Por qué no A: El precio por sí solo no controla riesgos de integridad y pertinencia. Por qué no B: Delegar selección a un posible interesado no corrige el problema ni asegura comparación.",
      "legalBasis": "Decreto 4791 de 2008; Ley 715 de 2001, arts. 11-14; principios de transparencia y planeación contractual."
    },
    {
      "id": 54,
      "situationId": "14",
      "competency": "GESTIÓN ADMINISTRATIVA",
      "text": "¿Qué criterio debe prevalecer en la comparación de ofertas?",
      "options": [
        "La rapidez de entrega, dado que cualquier solución temprana genera ahorro académico.",
        "Cumplimiento de especificaciones, costo total, calidad y reglas de contratación aplicables, documentados antes de decidir.",
        "La recomendación informal de miembros del Consejo Directivo, que conocen las necesidades del colegio."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: Una selección pertinente requiere criterios objetivos y definidos.",
      "distractors": "Por qué no A: La rapidez importa, pero no reemplaza calidad y legalidad. Por qué no C: La opinión informal no sustituye criterios técnicos ni procedimiento.",
      "legalBasis": "Decreto 4791 de 2008; Ley 715 de 2001, arts. 11-14; principios de transparencia y planeación contractual."
    },
    {
      "id": 55,
      "situationId": "14",
      "competency": "GESTIÓN ADMINISTRATIVA",
      "text": "Frente al posible conflicto de interés, lo prudente es:",
      "options": [
        "Activar los mecanismos de declaración y tratamiento previstos, evitando participación indebida en decisiones comprometidas.",
        "Mantener reserva absoluta incluso frente a las instancias responsables para proteger la imagen institucional.",
        "Cancelar automáticamente toda contratación posible con empresas del mismo sector, aun sin relación comprobada."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: Gestionar el riesgo con mecanismos establecidos y proporcionalidad.",
      "distractors": "Por qué no B: Ocultar un conflicto impide el control institucional. Por qué no C: Una prohibición sectorial total carece de correspondencia con el problema concreto.",
      "legalBasis": "Decreto 4791 de 2008; Ley 715 de 2001, arts. 11-14; principios de transparencia y planeación contractual."
    },
    {
      "id": 56,
      "situationId": "14",
      "competency": "GESTIÓN ADMINISTRATIVA",
      "text": "¿Cómo rendir cuentas de la decisión?",
      "options": [
        "Explicar criterios, procedimiento, costo y resultados de supervisión, con protección de la información que legalmente corresponda reservar.",
        "Publicar datos personales de todos los oferentes y evaluadores como garantía ilimitada de transparencia.",
        "Informar únicamente el nombre de la empresa y el costo final, sin soporte de comparación."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: La publicidad debe ser suficiente y respetar límites de protección de datos.",
      "distractors": "Por qué no B: Transparencia no implica divulgar indiscriminadamente información personal. Por qué no C: Dos datos aislados no permiten comprender la justificación.",
      "legalBasis": "Decreto 4791 de 2008; Ley 715 de 2001, arts. 11-14; principios de transparencia y planeación contractual."
    },
    {
      "id": 57,
      "situationId": "15",
      "competency": "GESTIÓN ADMINISTRATIVA",
      "text": "¿Cuál enfoque de evaluación es más defensible?",
      "options": [
        "Calificar favorablemente para evitar controversias y dejar que el siguiente rector resuelva los problemas.",
        "Asignar una valoración baja por presión de familias y documentar después el conjunto de incidentes.",
        "Aplicar el procedimiento y criterios vigentes, sustentar la valoración en evidencias y garantizar retroalimentación y oportunidades de mejora conforme al régimen."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: La evaluación debe ser objetiva, documentada y respetuosa de garantías.",
      "distractors": "Por qué no A: Evitar la evaluación incumple la responsabilidad de mejoramiento institucional. Por qué no B: La presión externa no sustituye instrumentos y evidencias.",
      "legalBasis": "Decreto Ley 1278 de 2002; Decreto 1075 de 2015; Resolución MEN 003842 de 2022, funciones 14 y 15."
    },
    {
      "id": 58,
      "situationId": "15",
      "competency": "GESTIÓN ADMINISTRATIVA",
      "text": "¿Qué función cumplen las observaciones de clase?",
      "options": [
        "Aportar evidencias situadas para analizar práctica pedagógica y formular retroalimentación específica, no emitir juicios automáticos por una visita.",
        "Demostrar por sí solas la incapacidad profesional permanente del docente ante cualquier dificultad observada.",
        "Sustituir por completo las demás fuentes de información y la aplicación de criterios establecidos."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: Una observación aporta datos contextualizados y requiere contraste.",
      "distractors": "Por qué no B: Una sesión aislada no justifica conclusiones generales. Por qué no C: La triangulación y el procedimiento no se agotan en una visita.",
      "legalBasis": "Decreto Ley 1278 de 2002; Decreto 1075 de 2015; Resolución MEN 003842 de 2022, funciones 14 y 15."
    },
    {
      "id": 59,
      "situationId": "15",
      "competency": "GESTIÓN ADMINISTRATIVA",
      "text": "Si el docente controvierte la valoración, corresponde:",
      "options": [
        "Responder que toda calificación rectoral es discrecional y, por ello, no admite observaciones.",
        "Informar los canales y términos del régimen aplicable y garantizar acceso a las evidencias que procedan.",
        "Reabrir indefinidamente la valoración sin aplicar plazos ni procedimientos para preservar el clima laboral."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: El ejercicio de la autoridad evaluadora está sujeto a reglas y recursos.",
      "distractors": "Por qué no A: La discrecionalidad no elimina garantías de contradicción. Por qué no C: La ausencia de plazos debilita seguridad jurídica e imparcialidad.",
      "legalBasis": "Decreto Ley 1278 de 2002; Decreto 1075 de 2015; Resolución MEN 003842 de 2022, funciones 14 y 15."
    },
    {
      "id": 60,
      "situationId": "15",
      "competency": "GESTIÓN ADMINISTRATIVA",
      "text": "¿Qué medida acompaña mejor una evaluación orientada a mejorar?",
      "options": [
        "Diseñar compromisos concretos de planeación y evaluación, con apoyo y verificación según indicadores observables.",
        "Exigir al docente asistir a toda oferta formativa externa, sin identificar necesidades ni resultados esperados.",
        "Reemplazar la retroalimentación por una circular general sobre excelencia dirigida a toda la planta."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: Vincula hallazgos individuales con apoyos y metas verificables.",
      "distractors": "Por qué no B: La asistencia inespecífica puede no resolver problemas detectados. Por qué no C: Los mensajes generales no reemplazan intervención focalizada.",
      "legalBasis": "Decreto Ley 1278 de 2002; Decreto 1075 de 2015; Resolución MEN 003842 de 2022, funciones 14 y 15."
    },
    {
      "id": 61,
      "situationId": "16",
      "competency": "GESTIÓN ADMINISTRATIVA",
      "text": "¿Cuál respuesta corresponde a una rectoría inclusiva?",
      "options": [
        "Adoptar ajustes inmediatos factibles para acceso y participación, acordar soluciones pedagógicas y gestionar obras y apoyos con la autoridad competente.",
        "Concentrar al estudiante indefinidamente en un aula aislada para evitar cualquier desplazamiento.",
        "Informar que no habrá ajustes hasta recibir la obra mayor aprobada por la entidad territorial."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: No subordina el derecho a participar a la culminación de infraestructura.",
      "distractors": "Por qué no B: El aislamiento permanente genera nuevas barreras de participación. Por qué no C: Posponer todos los ajustes desconoce alternativas disponibles.",
      "legalBasis": "Decreto 1421 de 2017; Decreto 4791 de 2008; Ley 1098 de 2006."
    },
    {
      "id": 62,
      "situationId": "16",
      "competency": "GESTIÓN ADMINISTRATIVA",
      "text": "En la priorización de recursos es preferible:",
      "options": [
        "Comprar primero equipos no solicitados porque el presupuesto original preveía dotación, aunque persistan barreras críticas.",
        "Valorar el riesgo, la eliminación de barreras y el beneficio educativo de cada alternativa, respetando destinación y autorización del gasto.",
        "Asignar el recurso íntegro a la obra más visible para exhibir una mejora institucional."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: Un criterio funcional y legal supera la apariencia o inercia presupuestal.",
      "distractors": "Por qué no A: Una compra inconexa puede no resolver la barrera existente. Por qué no C: La visibilidad no es criterio suficiente de prioridad.",
      "legalBasis": "Decreto 1421 de 2017; Decreto 4791 de 2008; Ley 1098 de 2006."
    },
    {
      "id": 63,
      "situationId": "16",
      "competency": "GESTIÓN ADMINISTRATIVA",
      "text": "La participación de la familia debe:",
      "options": [
        "Definir de forma exclusiva las inversiones y eximir al rector de la gestión posterior.",
        "Reducirse a recibir una comunicación de la decisión final porque la accesibilidad es solo materia técnica.",
        "Informar la valoración de barreras y apoyos, respetando las competencias institucionales y los acuerdos documentados."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: La corresponsabilidad incluye escucha sin transferencia impropia de atribuciones.",
      "distractors": "Por qué no A: La familia no asume competencias presupuestales del establecimiento. Por qué no B: La participación es relevante en la pertinencia y seguimiento de los ajustes.",
      "legalBasis": "Decreto 1421 de 2017; Decreto 4791 de 2008; Ley 1098 de 2006."
    },
    {
      "id": 64,
      "situationId": "16",
      "competency": "GESTIÓN ADMINISTRATIVA",
      "text": "¿Cuál es la mejor evidencia de mejora?",
      "options": [
        "Comprobar acceso seguro a espacios, participación efectiva y aprendizajes, junto con ejecución física de ajustes.",
        "Registrar únicamente fotografías del nuevo acceso y las facturas de materiales.",
        "Contabilizar la asistencia del estudiante sin observar participación ni posibilidades de movilidad."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: Mide eliminación real de barreras y trayectoria educativa.",
      "distractors": "Por qué no B: La obra entregada no demuestra por sí sola accesibilidad funcional. Por qué no C: Presencia física no equivale a participación significativa.",
      "legalBasis": "Decreto 1421 de 2017; Decreto 4791 de 2008; Ley 1098 de 2006."
    },
    {
      "id": 65,
      "situationId": "17",
      "competency": "GESTIÓN ADMINISTRATIVA",
      "text": "¿Qué respuesta es más adecuada a la solicitud?",
      "options": [
        "Entregar información estadística pertinente y, cuando corresponda, anonimizada o agregada, evitando revelar datos personales sensibles de menores.",
        "Negar toda información, incluso indicadores agregados, porque involucra población estudiantil.",
        "Publicar la base íntegra por ser información producida por una institución pública."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: La transparencia coexiste con la protección reforzada de datos de menores.",
      "distractors": "Por qué no B: El deber de reserva no prohíbe estadísticas adecuadamente tratadas. Por qué no C: La condición pública de la entidad no convierte todo dato personal en abierto.",
      "legalBasis": "Ley 1581 de 2012; Ley 1098 de 2006; Decreto 1965 de 2013, art. 35."
    },
    {
      "id": 66,
      "situationId": "17",
      "competency": "GESTIÓN ADMINISTRATIVA",
      "text": "¿Cuál riesgo es mayor al divulgar descripciones individuales?",
      "options": [
        "La posibilidad de que la Secretaría solicite indicadores adicionales después de la publicación.",
        "La pérdida de precisión estadística que se produciría al publicar los casos de manera agregada.",
        "La reidentificación y revictimización de estudiantes aun cuando se eliminen sus nombres pero permanezcan detalles suficientes."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Los identificadores indirectos pueden revelar identidades y hechos sensibles.",
      "distractors": "Por qué no A: La solicitud de nuevos indicadores no es el riesgo principal. Por qué no B: La agregación puede preservar utilidad sin exponer intimidad.",
      "legalBasis": "Ley 1581 de 2012; Ley 1098 de 2006; Decreto 1965 de 2013, art. 35."
    },
    {
      "id": 67,
      "situationId": "17",
      "competency": "GESTIÓN ADMINISTRATIVA",
      "text": "Para fortalecer la calidad del reporte, conviene:",
      "options": [
        "Eliminar del reporte todos los casos con información incompleta y no informar esa exclusión.",
        "Sumar todas las fichas sin verificar si un mismo estudiante figura varias veces en un período.",
        "Definir indicadores consistentes, verificar duplicidades y criterios de clasificación, y registrar limitaciones antes de difundir cifras."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: La calidad de datos requiere reglas de conteo transparentes.",
      "distractors": "Por qué no A: Las exclusiones silenciosas producen sesgos. Por qué no B: La suma de registros puede sobrestimar estudiantes o eventos.",
      "legalBasis": "Ley 1581 de 2012; Ley 1098 de 2006; Decreto 1965 de 2013, art. 35."
    },
    {
      "id": 68,
      "situationId": "17",
      "competency": "GESTIÓN ADMINISTRATIVA",
      "text": "¿Qué decisión institucional es más preventiva a futuro?",
      "options": [
        "Concentrar todos los archivos en una carpeta digital compartida con toda la planta docente.",
        "Prohibir cualquier registro de convivencia para evitar riesgos de filtración.",
        "Adoptar protocolos de acceso, minimización, custodia y reporte de datos para fines legítimos y responsables definidos."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: La protección de datos depende de gobernanza, no de difusión irrestricta o ausencia de registros.",
      "distractors": "Por qué no A: El acceso generalizado incrementa exposición innecesaria. Por qué no B: Registrar y seguir casos es una obligación institucional bajo protección adecuada.",
      "legalBasis": "Ley 1581 de 2012; Ley 1098 de 2006; Decreto 1965 de 2013, art. 35."
    },
    {
      "id": 69,
      "situationId": "18",
      "competency": "GESTIÓN COMUNITARIA",
      "text": "La respuesta inicial más adecuada del rector es:",
      "options": [
        "Convocar una conciliación pública entre estudiante afectada y presuntos agresores antes de tomar medidas de protección.",
        "Garantizar protección, documentar y clasificar la situación, activar el protocolo aplicable y articular atención y seguimiento con reserva.",
        "Aplicar expulsión inmediata a todo el grupo señalado para demostrar una política de tolerancia cero."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: La ruta exige clasificación, proporcionalidad, protección y seguimiento.",
      "distractors": "Por qué no A: La exposición pública puede revictimizar y no sustituye medidas iniciales. Por qué no C: Una expulsión colectiva sin debido proceso es desproporcionada.",
      "legalBasis": "Ley 1620 de 2013, arts. 29-31; Decreto 1965 de 2013, arts. 35 y 40-44; Ley 1098 de 2006."
    },
    {
      "id": 70,
      "situationId": "18",
      "competency": "GESTIÓN COMUNITARIA",
      "text": "La característica que distingue un conflicto aislado de presunto acoso escolar es:",
      "options": [
        "La conducta repetida y sistemática de intimidación, junto con sus condiciones de poder y afectación, evaluadas con evidencias.",
        "La publicación de cualquier mensaje desagradable, que por sí misma obliga a calificarlo como delito.",
        "La existencia de una queja de un adulto, incluso si los hechos son un desacuerdo único sin hostigamiento."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: La tipificación requiere analizar naturaleza, repetición y contexto de las conductas.",
      "distractors": "Por qué no B: No toda conducta digital ofensiva configura delito ni se clasifica igual. Por qué no C: Una queja no determina automáticamente la categoría del caso.",
      "legalBasis": "Ley 1620 de 2013, arts. 29-31; Decreto 1965 de 2013, arts. 35 y 40-44; Ley 1098 de 2006."
    },
    {
      "id": 71,
      "situationId": "18",
      "competency": "GESTIÓN COMUNITARIA",
      "text": "Respecto del acuerdo restaurativo propuesto, corresponde:",
      "options": [
        "Descartarlo para todos los casos de convivencia, incluso cuando procedan medidas pedagógicas restaurativas.",
        "Valorar su pertinencia solo después de garantizar seguridad, voluntariedad, no revictimización y condiciones del protocolo.",
        "Realizarlo frente a todo el curso porque la publicidad inhibe que los hechos se repitan."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: La reparación puede ser útil, pero no debe forzar exposición ni desplazar protección.",
      "distractors": "Por qué no A: Una prohibición absoluta desconoce alternativas formativas cuando son apropiadas. Por qué no C: La publicidad lesiona reserva y puede intensificar asimetrías.",
      "legalBasis": "Ley 1620 de 2013, arts. 29-31; Decreto 1965 de 2013, arts. 35 y 40-44; Ley 1098 de 2006."
    },
    {
      "id": 72,
      "situationId": "18",
      "competency": "GESTIÓN COMUNITARIA",
      "text": "¿Cuál seguimiento aporta evidencia de eficacia?",
      "options": [
        "Verificar cese del hostigamiento, bienestar de la estudiante, cumplimiento de compromisos y ausencia de represalias.",
        "Medir únicamente el número de sanciones aplicadas a los señalados.",
        "Contabilizar las firmas de un acta y declarar terminado el caso a la semana siguiente."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: El seguimiento examina protección real, no solo actos administrativos.",
      "distractors": "Por qué no B: Las sanciones no aseguran recuperación ni ausencia de nuevas agresiones. Por qué no C: Una firma no prueba que el riesgo haya desaparecido.",
      "legalBasis": "Ley 1620 de 2013, arts. 29-31; Decreto 1965 de 2013, arts. 35 y 40-44; Ley 1098 de 2006."
    },
    {
      "id": 73,
      "situationId": "19",
      "competency": "GESTIÓN COMUNITARIA",
      "text": "La actuación prioritaria debe ser:",
      "options": [
        "Entrevistar repetidamente a la adolescente y confrontarla con el señalado antes de reportar, para precisar contradicciones.",
        "Proteger a la estudiante, activar de inmediato la ruta y las autoridades competentes según la gravedad, evitar revictimización y preservar información.",
        "Esperar a que la familia presente una denuncia escrita y entonces activar el protocolo institucional."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: La institución no sustituye la investigación penal y debe actuar ante el riesgo.",
      "distractors": "Por qué no A: La confrontación y repetición innecesaria pueden revictimizar y exceden competencias. Por qué no C: La protección no puede condicionarse a una denuncia familiar formal.",
      "legalBasis": "Ley 1620 de 2013; Decreto 1965 de 2013, situaciones tipo III y protocolos; Ley 1098 de 2006, arts. 43-44."
    },
    {
      "id": 74,
      "situationId": "19",
      "competency": "GESTIÓN COMUNITARIA",
      "text": "¿Cuál es el alcance correcto del deber de reserva?",
      "options": [
        "Informar en asamblea a toda la comunidad para prevenir rumores y promover denuncias.",
        "Limitar el conocimiento a quienes requieren intervenir para proteger y reportar, sin ocultar el caso a las autoridades competentes.",
        "Mantener secreto absoluto porque la estudiante pidió que nadie conozca los hechos."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: La confidencialidad protege intimidad, pero no impide reportes obligatorios.",
      "distractors": "Por qué no A: La difusión general expone a la estudiante y compromete garantías. Por qué no C: El secreto absoluto puede dejar a la víctima sin protección.",
      "legalBasis": "Ley 1620 de 2013; Decreto 1965 de 2013, situaciones tipo III y protocolos; Ley 1098 de 2006, arts. 43-44."
    },
    {
      "id": 75,
      "situationId": "19",
      "competency": "GESTIÓN COMUNITARIA",
      "text": "Sobre el adulto señalado, el rector debe:",
      "options": [
        "Mantener todas sus actividades intactas hasta que exista sentencia judicial, aunque persista riesgo prevenible.",
        "Declararlo culpable públicamente y expedir una sanción definitiva al margen del régimen que lo vincule.",
        "Activar medidas de prevención de contacto dentro de sus competencias y coordinar con la entidad y autoridades pertinentes sin prejuzgar."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Combina prevención y garantías, con atribuciones institucionales limitadas.",
      "distractors": "Por qué no A: La protección requiere respuesta proporcional antes de una sentencia. Por qué no B: La culpabilidad y sanción exigen procedimientos y competencias.",
      "legalBasis": "Ley 1620 de 2013; Decreto 1965 de 2013, situaciones tipo III y protocolos; Ley 1098 de 2006, arts. 43-44."
    },
    {
      "id": 76,
      "situationId": "19",
      "competency": "GESTIÓN COMUNITARIA",
      "text": "¿Qué pregunta ayuda a escoger la ruta frente al caso?",
      "options": [
        "Si el evento afectó la imagen institucional en redes sociales durante la semana.",
        "Si la mayoría del curso considera creíble a la adolescente después de conocer su identidad.",
        "Si los hechos narrados podrían corresponder a una conducta presuntamente delictiva y requieren atención externa inmediata."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: La posible naturaleza penal determina medidas y remisiones del protocolo.",
      "distractors": "Por qué no A: La reputación institucional no reemplaza protección de derechos. Por qué no B: La credibilidad no se decide por votación de pares.",
      "legalBasis": "Ley 1620 de 2013; Decreto 1965 de 2013, situaciones tipo III y protocolos; Ley 1098 de 2006, arts. 43-44."
    },
    {
      "id": 77,
      "situationId": "20",
      "competency": "GESTIÓN COMUNITARIA",
      "text": "La estrategia más pertinente es:",
      "options": [
        "Publicar las listas nominales porque la presión social probablemente eleve la asistencia.",
        "Programar reuniones obligatorias en un único horario y atribuir la inasistencia a desinterés parental.",
        "Diseñar acciones focalizadas con diagnóstico de causas, coordinación territorial, canales flexibles con familias y protección de información estudiantil."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Responde a determinantes concretos y fomenta corresponsabilidad sin estigma.",
      "distractors": "Por qué no A: La exposición de datos puede vulnerar derechos y agravar barreras. Por qué no B: Una medida uniforme desconoce restricciones sociales y laborales.",
      "legalBasis": "Ley 115 de 1994, gobierno escolar; Decreto 1075 de 2015; Ley 1620 de 2013."
    },
    {
      "id": 78,
      "situationId": "20",
      "competency": "GESTIÓN COMUNITARIA",
      "text": "¿Qué participación de padres es más coherente con el gobierno escolar?",
      "options": [
        "Conceder a la asociación de padres autoridad para modificar unilateralmente las jornadas escolares.",
        "Recoger propuestas mediante sus representantes y espacios previstos, documentando acuerdos y responsabilidades compatibles con las normas.",
        "Excluir a familias de la planeación porque el rector conserva la dirección institucional."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: La participación no sustituye la autoridad reglada, pero mejora decisiones.",
      "distractors": "Por qué no A: Una organización familiar no puede redefinir competencias por sí sola. Por qué no C: La conducción directiva requiere interlocución comunitaria.",
      "legalBasis": "Ley 115 de 1994, gobierno escolar; Decreto 1075 de 2015; Ley 1620 de 2013."
    },
    {
      "id": 79,
      "situationId": "20",
      "competency": "GESTIÓN COMUNITARIA",
      "text": "¿Cómo medir éxito del plan sin sesgo?",
      "options": [
        "Medir solo el número de mensajes enviados por la asociación de padres.",
        "Comparar tasas de asistencia y permanencia por grupos y períodos, distinguiendo cambios de matrícula y causas de ausencia.",
        "Publicar la tasa general final sin contrastar la población de partida ni diferencias territoriales."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: Requiere indicadores de resultado con desagregación y consistencia de denominadores.",
      "distractors": "Por qué no A: La actividad comunicativa no demuestra asistencia efectiva. Por qué no C: La tasa agregada puede ocultar variaciones por matrícula o barreras.",
      "legalBasis": "Ley 115 de 1994, gobierno escolar; Decreto 1075 de 2015; Ley 1620 de 2013."
    },
    {
      "id": 80,
      "situationId": "20",
      "competency": "GESTIÓN COMUNITARIA",
      "text": "Ante las limitaciones de horario de docentes y familias, conviene:",
      "options": [
        "Concertar mecanismos variados y viables de comunicación, sin imponer cargas ilegítimas ni excluir a quienes trabajan.",
        "Suspender la participación familiar hasta que puedan asistir al horario único establecido.",
        "Exigir disponibilidad presencial semanal de todas las familias bajo amenaza de afectar notas."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: La flexibilidad es compatible con organización del servicio y corresponsabilidad.",
      "distractors": "Por qué no B: El horario único puede bloquear participación relevante. Por qué no C: Las calificaciones no deben utilizarse como sanción a familias.",
      "legalBasis": "Ley 115 de 1994, gobierno escolar; Decreto 1075 de 2015; Ley 1620 de 2013."
    },
    {
      "id": 81,
      "situationId": "21",
      "competency": "GESTIÓN COMUNITARIA",
      "text": "¿Cuál intervención inicial es más apropiada?",
      "options": [
        "Archivar el caso si el docente afirma que carecía de intención de ofender, sin escuchar al estudiante.",
        "Proteger al estudiante, escuchar versiones con reserva, documentar hechos y activar las medidas pedagógicas o rutas pertinentes según su valoración.",
        "Publicar la denuncia con nombres y solicitar que la comunidad decida si el docente actuó con discriminación."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: Atiende impacto, garantías y valoración objetiva de la conducta.",
      "distractors": "Por qué no A: La ausencia alegada de intención no elimina la necesidad de examinar efectos. Por qué no C: La votación pública carece de procedimiento y expone a las partes.",
      "legalBasis": "Ley 1098 de 2006, arts. 43-44; Ley 1620 de 2013; Resolución MEN 003842 de 2022."
    },
    {
      "id": 82,
      "situationId": "21",
      "competency": "GESTIÓN COMUNITARIA",
      "text": "¿Qué decisión pedagógica puede prevenir nuevas situaciones?",
      "options": [
        "Separar por procedencia a los estudiantes durante ejercicios de lectura.",
        "Promover prácticas de evaluación y retroalimentación respetuosas de la diversidad lingüística, con seguimiento de aula.",
        "Prohibir toda corrección oral para evitar que estudiantes se sientan expuestos."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: La protección de la dignidad es compatible con retroalimentación formativa.",
      "distractors": "Por qué no A: La segregación por procedencia refuerza estereotipos. Por qué no C: Eliminar toda corrección perjudica el aprendizaje.",
      "legalBasis": "Ley 1098 de 2006, arts. 43-44; Ley 1620 de 2013; Resolución MEN 003842 de 2022."
    },
    {
      "id": 83,
      "situationId": "21",
      "competency": "GESTIÓN COMUNITARIA",
      "text": "Si hay evidencias de una conducta que requiere trámite adicional, el rector debe:",
      "options": [
        "Emitir una sanción de destitución por comunicado rectoral sin aplicar régimen ni procedimiento.",
        "Condicionar el estudio del caso a que el estudiante acepte disculpas públicas.",
        "Usar los canales institucionales y autoridades competentes, diferenciando apoyo pedagógico de eventuales responsabilidades."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: La gestión directiva no confunde reparación, investigación y sanción.",
      "distractors": "Por qué no A: La sanción exige competencia y debido proceso. Por qué no B: La aceptación de disculpas no puede condicionar deberes de atención.",
      "legalBasis": "Ley 1098 de 2006, arts. 43-44; Ley 1620 de 2013; Resolución MEN 003842 de 2022."
    },
    {
      "id": 84,
      "situationId": "22",
      "competency": "GESTIÓN COMUNITARIA",
      "text": "¿Qué estrategia integra mejor la respuesta institucional?",
      "options": [
        "Focalizar riesgo con datos, acompañamiento escolar y acuerdos formales con actores territoriales, evaluando permanencia y aprendizaje.",
        "Encargar a la ONG toda la responsabilidad de buscar estudiantes mientras la institución mantiene intactas sus prácticas.",
        "Solicitar a cada familia que garantice asistencia sin revisar factores escolares o territoriales."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: La prevención de deserción requiere corresponsabilidad y medidas escolares propias.",
      "distractors": "Por qué no B: La ONG es apoyo, no reemplazo de funciones institucionales. Por qué no C: La obligación familiar no agota las barreras estructurales observadas.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión comunitaria; Ley 115 de 1994; Decreto 1075 de 2015."
    },
    {
      "id": 85,
      "situationId": "22",
      "competency": "GESTIÓN COMUNITARIA",
      "text": "La pertinencia curricular podría fortalecerse mediante:",
      "options": [
        "Concentrar a estudiantes en riesgo exclusivamente en actividades recreativas ajenas a su trayectoria académica.",
        "Reemplazar las áreas con menor asistencia por talleres libres sin objetivos curriculares.",
        "Proyectos de aprendizaje contextualizados y participación estudiantil, con conservación de competencias y propósitos del plan de estudios."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: La flexibilidad contextual preserva derecho a aprendizajes de calidad.",
      "distractors": "Por qué no A: Las actividades de bienestar necesitan articulación educativa. Por qué no B: La sustitución improvisada reduce el contenido formativo.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión comunitaria; Ley 115 de 1994; Decreto 1075 de 2015."
    },
    {
      "id": 86,
      "situationId": "22",
      "competency": "GESTIÓN COMUNITARIA",
      "text": "Un acuerdo efectivo con aliados debería definir:",
      "options": [
        "Responsables, recursos, alcance, protección de estudiantes e indicadores de seguimiento antes de anunciar resultados.",
        "Una fotografía del lanzamiento y una intención genérica de cooperar, sin metas ni obligaciones identificables.",
        "La transferencia completa de datos personales de estudiantes a todas las entidades invitadas."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: La cooperación seria requiere trazabilidad y manejo legítimo de información.",
      "distractors": "Por qué no B: La publicidad del compromiso no equivale a ejecución. Por qué no C: Compartir datos debe obedecer finalidades y autorizaciones pertinentes.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión comunitaria; Ley 115 de 1994; Decreto 1075 de 2015."
    },
    {
      "id": 87,
      "situationId": "23",
      "competency": "COMPETENCIAS BLANDAS",
      "text": "¿Cuál respuesta muestra mejor criterio directivo?",
      "options": [
        "Permitir toda exhibición solicitada porque podría facilitar apoyos materiales futuros para el colegio.",
        "Excluir de por vida a todas las autoridades locales de actividades institucionales.",
        "Agradecer la cooperación institucional y delimitar una participación compatible con neutralidad, finalidad educativa y reglas aplicables."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Protege la función educativa sin romper vínculos legítimos.",
      "distractors": "Por qué no A: Un beneficio eventual no justifica uso indebido del escenario escolar. Por qué no B: La exclusión absoluta impide relaciones interinstitucionales válidas.",
      "legalBasis": "Resolución MEN 003842 de 2022, liderazgo, ética y comunicación; Ley 115 de 1994."
    },
    {
      "id": 88,
      "situationId": "23",
      "competency": "COMPETENCIAS BLANDAS",
      "text": "En una conversación difícil, conviene:",
      "options": [
        "Exponer criterios institucionales y ofrecer alternativas objetivas, registrando los acuerdos y sin personalizar el desacuerdo.",
        "Aceptar verbalmente la campaña y después incumplir para evitar confrontación inicial.",
        "Acusar públicamente a la autoridad de tener intenciones indebidas sin escuchar su propuesta."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: La comunicación ética combina límites, claridad y trato respetuoso.",
      "distractors": "Por qué no B: Prometer algo que no se cumplirá reduce confianza institucional. Por qué no C: La imputación de intenciones sin evidencia escala el conflicto.",
      "legalBasis": "Resolución MEN 003842 de 2022, liderazgo, ética y comunicación; Ley 115 de 1994."
    },
    {
      "id": 89,
      "situationId": "23",
      "competency": "COMPETENCIAS BLANDAS",
      "text": "¿Qué principio orienta mejor la decisión ante promesas de apoyo?",
      "options": [
        "La reciprocidad obliga a ceder espacios formativos a quien facilite recursos.",
        "La finalidad pública de la educación y la imparcialidad prevalecen sobre ventajas materiales contingentes.",
        "La conveniencia política debe decidirse por encuesta informal entre docentes."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: Los apoyos no alteran el marco de responsabilidades y neutralidad.",
      "distractors": "Por qué no A: La contraprestación personal por recursos compromete integridad. Por qué no C: Una encuesta no sustituye deberes institucionales.",
      "legalBasis": "Resolución MEN 003842 de 2022, liderazgo, ética y comunicación; Ley 115 de 1994."
    },
    {
      "id": 90,
      "situationId": "24",
      "competency": "COMPETENCIAS BLANDAS",
      "text": "¿Qué intervención representa liderazgo más sólido?",
      "options": [
        "Permitir que cada coordinador dicte instrucciones distintas a sus áreas sin articulación institucional.",
        "Dar la razón al coordinador con mayor antigüedad para cerrar con rapidez la controversia.",
        "Establecer criterios comunes orientados al aprendizaje, escuchar evidencias, asignar responsabilidades y pilotar un protocolo de acompañamiento."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Transforma conflicto personal en decisión técnica compartida.",
      "distractors": "Por qué no A: La autonomía descoordinada perpetúa contradicciones. Por qué no B: La antigüedad no determina pertinencia de una propuesta.",
      "legalBasis": "Resolución MEN 003842 de 2022, liderazgo, trabajo en equipo, negociación y mediación."
    },
    {
      "id": 91,
      "situationId": "24",
      "competency": "COMPETENCIAS BLANDAS",
      "text": "¿Cómo resolver la tensión entre estandarización y flexibilidad?",
      "options": [
        "Definir mínimos comunes de calidad y espacios de adaptación por área, con seguimiento y revisión de efectos.",
        "Renunciar a todo estándar porque la diversidad de prácticas impide comparar avances.",
        "Aplicar una plantilla idéntica de clase, desempeño y evaluación a todas las asignaturas."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: Combina consistencia institucional y juicio pedagógico contextual.",
      "distractors": "Por qué no B: Sin acuerdos mínimos se dificulta el seguimiento. Por qué no C: La uniformidad rígida desconoce diferencias disciplinares.",
      "legalBasis": "Resolución MEN 003842 de 2022, liderazgo, trabajo en equipo, negociación y mediación."
    },
    {
      "id": 92,
      "situationId": "24",
      "competency": "COMPETENCIAS BLANDAS",
      "text": "La señal de una mediación efectiva será:",
      "options": [
        "Que disminuyan instrucciones contradictorias y aparezcan acuerdos observables y seguimiento a su aplicación.",
        "Que todos manifiesten conformidad inmediata con el rector sin revisar prácticas posteriores.",
        "Que uno de los coordinadores guarde silencio en las reuniones aunque mantenga instrucciones diferentes."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: La eficacia se evidencia en conductas y resultados sostenidos.",
      "distractors": "Por qué no B: La satisfacción declarada no prueba implementación. Por qué no C: La ausencia aparente de discusión puede encubrir el conflicto.",
      "legalBasis": "Resolución MEN 003842 de 2022, liderazgo, trabajo en equipo, negociación y mediación."
    },
    {
      "id": 93,
      "situationId": "25",
      "competency": "COMPETENCIAS BLANDAS",
      "text": "¿Cuál es la respuesta institucional más adecuada?",
      "options": [
        "Esperar una petición de aclaración porque corregir voluntariamente puede afectar la imagen institucional.",
        "Verificar el alcance, corregir formalmente la información ante quien corresponda y documentar acciones preventivas.",
        "Divulgar cifras nuevas sin revisar bases para demostrar diligencia inmediata."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: La integridad requiere precisión y corrección oportuna, no ocultamiento ni precipitación.",
      "distractors": "Por qué no A: El temor reputacional no justifica dejar un error conocido. Por qué no C: Corregir sin validar puede producir nuevas inconsistencias.",
      "legalBasis": "Resolución MEN 003842 de 2022, ética, compromiso institucional y orientación al logro."
    },
    {
      "id": 94,
      "situationId": "25",
      "competency": "COMPETENCIAS BLANDAS",
      "text": "¿Qué práctica reduce reincidencia?",
      "options": [
        "Crear verificación cruzada de fuentes y responsable de control antes de remitir indicadores institucionales.",
        "Hacer que una sola persona prepare y apruebe todos los informes sin auditoría interna.",
        "Disminuir el número de indicadores para evitar cualquier error, incluso si son necesarios."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: Un control proporcionado mejora fiabilidad y responsabilidad.",
      "distractors": "Por qué no B: Ausencia de segunda revisión concentra riesgo. Por qué no C: Eliminar información necesaria no equivale a control de calidad.",
      "legalBasis": "Resolución MEN 003842 de 2022, ética, compromiso institucional y orientación al logro."
    },
    {
      "id": 95,
      "situationId": "25",
      "competency": "COMPETENCIAS BLANDAS",
      "text": "¿Cómo comunicar al equipo la rectificación?",
      "options": [
        "Guardar silencio interno porque la aclaración se envió exclusivamente a la Secretaría.",
        "Señalar en reunión general a quien digitó el reporte como único responsable, antes del análisis.",
        "Explicar el dato errado, la corrección y el nuevo control sin buscar culpables antes de conocer las causas."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Favorece aprendizaje organizacional y responsabilidad sin atribución precipitada.",
      "distractors": "Por qué no A: El equipo necesita comprender controles y mejoras. Por qué no B: La culpabilización temprana desalienta reporte de errores.",
      "legalBasis": "Resolución MEN 003842 de 2022, ética, compromiso institucional y orientación al logro."
    },
    {
      "id": 96,
      "situationId": "26",
      "competency": "COMPETENCIAS BLANDAS",
      "text": "¿Qué respuesta equilibra precaución y evidencia?",
      "options": [
        "Anunciar que existe intoxicación masiva comprobada antes de contar con valoración sanitaria.",
        "Aplicar medidas preventivas proporcionadas, verificar trazabilidad y activar comunicación y autoridades pertinentes según el riesgo.",
        "Continuar sin ninguna verificación porque el operador sostiene que sus controles son adecuados."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: La incertidumbre exige gestión proporcional del riesgo y comprobación de hechos.",
      "distractors": "Por qué no A: La afirmación categórica sin soporte genera desinformación. Por qué no C: La declaración del operador no reemplaza revisión independiente.",
      "legalBasis": "Resolución MEN 003842 de 2022, planeación, liderazgo, ética e iniciativa."
    },
    {
      "id": 97,
      "situationId": "26",
      "competency": "COMPETENCIAS BLANDAS",
      "text": "¿Qué comunicación es más apropiada?",
      "options": [
        "Informar lo conocido, lo aún no establecido, las medidas de protección y la vía de actualización oficial.",
        "Publicar las fotografías sin contexto y pedir a familias decidir individualmente la inocuidad de alimentos.",
        "Negar cualquier comunicación hasta disponer de resultado definitivo de laboratorio."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: La comunicación de riesgo distingue certeza e incertidumbre.",
      "distractors": "Por qué no B: La difusión sin verificación puede incrementar rumores. Por qué no C: La reserva absoluta impide orientar a la comunidad durante la atención.",
      "legalBasis": "Resolución MEN 003842 de 2022, planeación, liderazgo, ética e iniciativa."
    },
    {
      "id": 98,
      "situationId": "26",
      "competency": "COMPETENCIAS BLANDAS",
      "text": "¿Qué evidencia permitiría decidir mejor el siguiente paso?",
      "options": [
        "Cantidad de familias que tienen confianza en la reputación del operador.",
        "Registros de lote, cadena de suministro, síntomas reportados y valoración competente en salud pública.",
        "Número de reacciones a la publicación inicial en redes sociales."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: Los datos pertinentes permiten evaluar causalidad y medidas sanitarias.",
      "distractors": "Por qué no A: La reputación no sustituye evidencia técnica. Por qué no C: La viralidad no mide inocuidad.",
      "legalBasis": "Resolución MEN 003842 de 2022, planeación, liderazgo, ética e iniciativa."
    },
    {
      "id": 99,
      "situationId": "27",
      "competency": "LECTURA CRÍTICA",
      "text": "¿Qué afirmación es válida a partir del fragmento?",
      "options": [
        "El crecimiento de matrícula demuestra por sí mismo que ninguna familia abandonó la institución en el segundo año.",
        "La estrategia redujo significativamente el ausentismo porque más estudiantes permanecieron fuera del grupo de riesgo en términos absolutos.",
        "La matrícula creció, pero la proporción con inasistencia alta aumentó ligeramente, de modo que no se demuestra mejoría en ese indicador."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: La comparación de proporciones impide confundir mayor tamaño de matrícula con mejora de asistencia.",
      "distractors": "Por qué no A: La matrícula al cierre no informa por sí sola sobre traslados o deserción. Por qué no B: El aumento absoluto de estudiantes sin alta inasistencia no implica descenso porcentual del problema.",
      "legalBasis": "Análisis de texto aportado en el caso; Resolución MEN 003842 de 2022, lectura crítica."
    },
    {
      "id": 100,
      "situationId": "27",
      "competency": "LECTURA CRÍTICA",
      "text": "¿Cuál es el principal problema de la conclusión del informe?",
      "options": [
        "Atribuye éxito y recomienda expansión sin evidencias suficientes de eficacia ni control de cambios de composición.",
        "Utiliza proporciones para comparar poblaciones de distinto tamaño, lo que siempre es matemáticamente incorrecto.",
        "Presenta un valor porcentual aproximado en lugar de todos los decimales posibles."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: El defecto es inferencial: pasar de crecimiento de matrícula a efectividad no demostrada.",
      "distractors": "Por qué no B: Las proporciones son apropiadas para comparar tamaños diferentes si se interpretan bien. Por qué no C: El redondeo razonable no determina la validez causal.",
      "legalBasis": "Análisis de texto aportado en el caso; Resolución MEN 003842 de 2022, lectura crítica."
    },
    {
      "id": 101,
      "situationId": "27",
      "competency": "LECTURA CRÍTICA",
      "text": "¿Cuál dato adicional fortalecería más la evaluación?",
      "options": [
        "Trayectorias individuales de asistencia y permanencia por sede, con causas de ausencia y exposición a la estrategia.",
        "Número de afiches impresos para la campaña de asistencia durante el segundo año.",
        "Una encuesta breve que pregunte solo si las familias conocen el nombre de la estrategia."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: La información longitudinal y contextual permite evaluar cambios sustantivos.",
      "distractors": "Por qué no B: Los afiches son insumos de comunicación, no evidencia de asistencia. Por qué no C: El conocimiento de la campaña es insuficiente para medir efectos.",
      "legalBasis": "Análisis de texto aportado en el caso; Resolución MEN 003842 de 2022, lectura crítica."
    },
    {
      "id": 102,
      "situationId": "28",
      "competency": "LECTURA CRÍTICA",
      "text": "¿Cuál lectura recoge mejor el alcance de la excepción?",
      "options": [
        "Autoriza medidas provisionales cuando existe riesgo inminente, con documentación y revisión posterior.",
        "Permite omitir los procedimientos ordinarios de manera estable si el responsable menciona prevención.",
        "Exige completar todos los trámites ordinarios antes de actuar incluso ante riesgo inmediato."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: La excepción está condicionada por urgencia, temporalidad y control posterior.",
      "distractors": "Por qué no B: La referencia genérica a prevención no equivale a riesgo inminente. Por qué no C: El texto prevé expresamente actuación inmediata ante urgencias.",
      "legalBasis": "Comprensión inferencial de disposición hipotética; distinción entre alcance y excepción."
    },
    {
      "id": 103,
      "situationId": "28",
      "competency": "LECTURA CRÍTICA",
      "text": "El argumento de la coordinadora incurre principalmente en:",
      "options": [
        "Distinguir actuación ordinaria de extraordinaria a partir del contexto de riesgo.",
        "Extender una excepción específica a una regla general sin atender sus condiciones.",
        "Interpretar la palabra «podrán» como una obligación universal en vez de una autorización condicionada."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: Generaliza indebidamente desde un supuesto excepcional.",
      "distractors": "Por qué no A: Reconocer la distinción contextual sería una lectura correcta. Por qué no C: El error principal no es confundir facultad con deber sino ignorar límites.",
      "legalBasis": "Comprensión inferencial de disposición hipotética; distinción entre alcance y excepción."
    },
    {
      "id": 104,
      "situationId": "28",
      "competency": "LECTURA CRÍTICA",
      "text": "Si la situación ya no es urgente, una decisión coherente sería:",
      "options": [
        "Anular retroactivamente toda medida de protección tomada durante la urgencia.",
        "Revisar la medida provisional y tramitar lo que corresponda para mantener, adaptar o terminar sus efectos.",
        "Mantener indefinidamente las condiciones provisionales porque fueron razonables al inicio."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: La temporalidad obliga a revisar sin desconocer que la respuesta inicial pudo estar justificada.",
      "distractors": "Por qué no A: Actuar por urgencia no implica nulidad automática posterior. Por qué no C: La justificación inicial no basta para sostener indefinidamente una excepción.",
      "legalBasis": "Comprensión inferencial de disposición hipotética; distinción entre alcance y excepción."
    },
    {
      "id": 105,
      "situationId": "29",
      "competency": "LECTURA CRÍTICA",
      "text": "¿Cuál crítica al argumento está mejor sustentada?",
      "options": [
        "La diferencia entre 92 % y 78 % es de catorce puntos porcentuales y por eso el argumento causal es correcto.",
        "Las tutorías no pudieron tener ningún efecto porque los grupos no se formaron aleatoriamente.",
        "La diferencia observada no identifica por sí sola el efecto causal porque los grupos diferían antes de las tutorías."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Diferencia descriptiva y causalidad requieren controles de composición inicial.",
      "distractors": "Por qué no A: El cálculo de diferencia es correcto; la inferencia causal no queda sustentada. Por qué no B: La ausencia de aleatorización dificulta inferencia, pero no prueba efecto nulo.",
      "legalBasis": "Lectura crítica e inferencia causal; Resolución MEN 003842 de 2022."
    },
    {
      "id": 106,
      "situationId": "29",
      "competency": "LECTURA CRÍTICA",
      "text": "¿Qué evidencia ayudaría más a estimar el efecto del programa?",
      "options": [
        "Comparaciones de progreso desde línea de base entre grupos similares, con control de asistencia y desempeño inicial.",
        "Una encuesta que pregunte únicamente si los docentes consideran agradable el programa.",
        "El número de horas totales de tutoría, sin datos de aprendizaje previo o posterior."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: Controlar diferencias iniciales mejora la interpretación de cambios atribuibles.",
      "distractors": "Por qué no B: La aceptación docente aporta contexto, no identificación del efecto. Por qué no C: Horas invertidas no equivalen al impacto causal.",
      "legalBasis": "Lectura crítica e inferencia causal; Resolución MEN 003842 de 2022."
    },
    {
      "id": 107,
      "situationId": "29",
      "competency": "LECTURA CRÍTICA",
      "text": "¿Cuál conclusión resulta admisible con los datos actuales?",
      "options": [
        "Se observa una asociación positiva entre tutorías y aprobación, pero el efecto atribuible permanece incierto.",
        "La asociación carece de todo valor informativo porque no permite causalidad definitiva.",
        "El programa garantiza elevar catorce puntos porcentuales la aprobación en cualquier sede."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: Reconoce un patrón útil sin exagerar su fuerza causal.",
      "distractors": "Por qué no B: Una asociación bien descrita puede orientar futuras evaluaciones. Por qué no C: Generalizar un efecto fijo desconoce confusores y contexto.",
      "legalBasis": "Lectura crítica e inferencia causal; Resolución MEN 003842 de 2022."
    },
    {
      "id": 108,
      "situationId": "30",
      "competency": "LECTURA CRÍTICA",
      "text": "La interpretación más fiel es:",
      "options": [
        "El derecho a reclamar depende de que el estudiante repruebe la asignatura cuestionada.",
        "El derecho a expresar inconformidades está reconocido, pero se ejerce mediante evidencias, respeto y procedimientos.",
        "Cualquier señalamiento público se justifica por la libertad de expresión, incluso sin evidencia ni trato respetuoso."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: La tesis combina reconocimiento de un derecho y condiciones para su ejercicio.",
      "distractors": "Por qué no A: No condiciona el reclamo a una nota específica. Por qué no C: El texto explicita límites de respeto y soporte.",
      "legalBasis": "Comprensión argumentativa de texto hipotético; derechos educativos."
    },
    {
      "id": 109,
      "situationId": "30",
      "competency": "LECTURA CRÍTICA",
      "text": "¿Qué presuposición rechaza explícitamente el texto?",
      "options": [
        "Que abrir canales de crítica supone eliminar deberes de respeto y convivencia.",
        "Que los estudiantes pueden contar con canales institucionales de reclamación.",
        "Que los reclamos pueden apoyarse en evidencias relacionadas con decisiones evaluativas."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: La propuesta rechaza la idea de libertad desvinculada de responsabilidad.",
      "distractors": "Por qué no B: Esa tesis forma parte del contenido afirmado. Por qué no C: El recurso a evidencia es una exigencia expresa del texto.",
      "legalBasis": "Comprensión argumentativa de texto hipotético; derechos educativos."
    },
    {
      "id": 110,
      "situationId": "30",
      "competency": "LECTURA CRÍTICA",
      "text": "Una reformulación fiel para una circular sería:",
      "options": [
        "Solo serán recibidas inconformidades si el Consejo Directivo considera previamente que el docente actuó mal.",
        "Cualquier declaración contra docentes deberá circular públicamente para asegurar que no sea censurada.",
        "Se recibirán inconformidades sustentadas y respetuosas por las vías previstas, con garantía de atención sin represalias."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Mantiene sujeto, derecho, condiciones y garantía de no represalia.",
      "distractors": "Por qué no A: Añade una condición no presente y convierte el trámite en barrera. Por qué no B: Omite evidencia y respeto, además de exponer personas.",
      "legalBasis": "Comprensión argumentativa de texto hipotético; derechos educativos."
    },
    {
      "id": 111,
      "situationId": "31",
      "competency": "LECTURA CRÍTICA",
      "text": "¿Cuál inferencia es defendible?",
      "options": [
        "El club produce necesariamente el mismo resultado en 120 estudiantes porque 25 respuestas positivas constituyen evidencia suficiente.",
        "El club no aporta ningún beneficio a nadie, dado que faltó una medición previa.",
        "Entre quienes respondieron dentro del club se registra una percepción favorable, pero no puede generalizarse a toda la cohorte ni atribuir causalidad."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Distingue percepción de beneficiarios, representatividad e impacto causal.",
      "distractors": "Por qué no A: Una muestra voluntaria sin comparación no permite inferencia poblacional. Por qué no B: Las limitaciones no anulan el valor descriptivo de las respuestas.",
      "legalBasis": "Razonamiento inferencial, evidencia y lectura de informes educativos."
    },
    {
      "id": 112,
      "situationId": "31",
      "competency": "LECTURA CRÍTICA",
      "text": "La debilidad metodológica más importante para la generalización es:",
      "options": [
        "Que las respuestas se recogieron al finalizar una actividad de carácter oral.",
        "La autoselección y ausencia de datos de quienes no participaron, que impiden extrapolar resultados.",
        "Que 25 es una cifra impar, lo cual dificulta interpretar porcentajes."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: La selección de participantes introduce sesgos de motivación y desempeño.",
      "distractors": "Por qué no A: El momento de recolección importa, pero no es la principal razón de falta de representatividad. Por qué no C: La paridad del número no tiene relevancia inferencial.",
      "legalBasis": "Razonamiento inferencial, evidencia y lectura de informes educativos."
    },
    {
      "id": 113,
      "situationId": "31",
      "competency": "LECTURA CRÍTICA",
      "text": "¿Qué recomendación sigue mejor del texto?",
      "options": [
        "Convertir de inmediato el club en única estrategia porque el 83 % de participantes lo valora favorablemente.",
        "Eliminar el club por carecer de evidencia experimental concluyente en esa cohorte.",
        "Evaluar el club con mediciones y comparadores apropiados y ofrecer alternativas antes de decidir obligatoriedad institucional."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Transforma evidencia preliminar en aprendizaje institucional sin exagerar.",
      "distractors": "Por qué no A: La aceptación entre participantes no justifica exclusividad. Por qué no B: La incertidumbre invita a evaluar, no necesariamente a cancelar.",
      "legalBasis": "Razonamiento inferencial, evidencia y lectura de informes educativos."
    },
    {
      "id": 114,
      "situationId": "32",
      "competency": "RAZONAMIENTO CUANTITATIVO",
      "text": "¿Qué comparación entre sedes es correcta?",
      "options": [
        "Norte registra 12,50 % y Sur 7,50 %; la diferencia es de 5,00 puntos porcentuales.",
        "Norte registra 12,50 % y Sur 7,50 %; por ello la primera supera a la segunda en 5,00 %.",
        "Norte registra 7,50 % y Sur 12,50 %; la diferencia es de 5,00 puntos porcentuales."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: 30/240 = 0,125 y 12/160 = 0,075; la resta es de 5 puntos porcentuales.",
      "distractors": "Por qué no B: Confunde diferencia en puntos porcentuales con variación relativa, que no es del 5 %. Por qué no C: Invierte numeradores o sedes y, por tanto, altera las tasas.",
      "legalBasis": "Cálculo de tasas y comparación de denominadores; diagnóstico de permanencia."
    },
    {
      "id": 115,
      "situationId": "32",
      "competency": "RAZONAMIENTO CUANTITATIVO",
      "text": "¿Cuántos casos como mínimo deben dejar de superar el umbral para cumplir la meta del 9 %?",
      "options": [
        "Seis estudiantes, porque el máximo aceptable es 36 de 400 y actualmente son 42.",
        "Nueve estudiantes, porque la meta del 9 % implica que deben retirarse nueve del grupo de riesgo.",
        "Cuatro estudiantes, porque reducir de 10,50 % a 9 % equivale a disminuir cuatro casos."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: 0,09 x 400 = 36 y 42 - 36 = 6, manteniendo matrícula constante.",
      "distractors": "Por qué no B: Interpreta la tasa meta como número absoluto de estudiantes a reducir. Por qué no C: Cuatro casos dejarían 38/400 = 9,5 %, por encima de la meta.",
      "legalBasis": "Cálculo de tasas y comparación de denominadores; diagnóstico de permanencia."
    },
    {
      "id": 116,
      "situationId": "32",
      "competency": "RAZONAMIENTO CUANTITATIVO",
      "text": "¿Cuál sería la tasa consolidada actual?",
      "options": [
        "12,50 %, porque la sede con mayor matrícula determina la tasa de toda la institución.",
        "10,50 %, calculada como 42 de 400 estudiantes.",
        "10,00 %, obtenida al promediar sin ponderar las tasas de las dos sedes."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: 42/400 = 0,105; una tasa total requiere denominador conjunto.",
      "distractors": "Por qué no A: La tasa de la sede más grande no representa a la población completa. Por qué no C: El promedio simple 10 % ignora tamaños diferentes de sedes.",
      "legalBasis": "Cálculo de tasas y comparación de denominadores; diagnóstico de permanencia."
    },
    {
      "id": 117,
      "situationId": "33",
      "competency": "RAZONAMIENTO CUANTITATIVO",
      "text": "¿Qué cambio se observa en la tasa de logro?",
      "options": [
        "Aumentó cinco por ciento en términos relativos exactos, porque la diferencia entre porcentajes es cinco.",
        "Aumentó de 65 % a 70 %, es decir, cinco puntos porcentuales, aunque disminuyó el número absoluto de logros.",
        "Disminuyó de 70 % a 65 %, porque el número total de estudiantes con logro pasó de 130 a 126."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: 130/200 = 65 % y 126/180 = 70 %; la comparación correcta usa ambos denominadores.",
      "distractors": "Por qué no A: Cinco puntos porcentuales representan un incremento relativo de aproximadamente 7,69 % respecto de 65 %. Por qué no C: Comparar conteos sin población produce una conclusión errada sobre proporciones.",
      "legalBasis": "Tasas de logro, variaciones absolutas y metas por cohorte."
    },
    {
      "id": 118,
      "situationId": "33",
      "competency": "RAZONAMIENTO CUANTITATIVO",
      "text": "¿Cuántos estudiantes adicionales deben alcanzar la competencia respecto del segundo año para llegar a la meta, con 180 inscritos?",
      "options": [
        "Catorce estudiantes, para recuperar primero la cantidad absoluta del primer año.",
        "Cinco estudiantes, porque la distancia entre tasas es de cinco puntos porcentuales.",
        "Nueve estudiantes, para llegar a 135 de 180."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: 0,75 x 180 = 135 y 135 - 126 = 9.",
      "distractors": "Por qué no A: El número absoluto del primer año no define la meta sobre nueva matrícula. Por qué no B: Cinco puntos porcentuales de 180 representan nueve estudiantes, no cinco.",
      "legalBasis": "Tasas de logro, variaciones absolutas y metas por cohorte."
    },
    {
      "id": 119,
      "situationId": "33",
      "competency": "RAZONAMIENTO CUANTITATIVO",
      "text": "¿Qué afirmación es más rigurosa para un informe?",
      "options": [
        "El programa generó por sí solo una mejora de cinco puntos porcentuales porque ambos años aplicaron igual criterio.",
        "El programa perdió efectividad porque cuatro estudiantes menos alcanzaron el logro esperado.",
        "La proporción de logro aumentó, pero con los datos disponibles no se identifica si el programa produjo ese cambio."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Distingue variación descriptiva y atribución causal, incluso con medidas comparables.",
      "distractors": "Por qué no A: La equivalencia del criterio no controla otras diferencias entre cohortes. Por qué no B: Una reducción absoluta con menor matrícula no demuestra menor tasa de logro.",
      "legalBasis": "Tasas de logro, variaciones absolutas y metas por cohorte."
    },
    {
      "id": 120,
      "situationId": "34",
      "competency": "RAZONAMIENTO CUANTITATIVO",
      "text": "¿Cuánto quedaría sin comprometer al financiar las tres propuestas completas?",
      "options": [
        "Seis millones de pesos, porque el conjunto de solicitudes representa 42 millones.",
        "Cuatro millones de pesos, equivalentes a 8,33 % del presupuesto total.",
        "Cuatro millones de pesos, equivalentes exactamente al 10 % del presupuesto."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: 48 - (18 + 12 + 14) = 4; 4/48 equivale aproximadamente a 8,33 %.",
      "distractors": "Por qué no A: La suma real de las solicitudes es 44, no 42 millones. Por qué no C: El monto es correcto, pero el porcentaje confunde base de cálculo.",
      "legalBasis": "Operaciones presupuestales simuladas; Decreto 4791 de 2008 como marco de competencias, no autorización específica de gasto."
    },
    {
      "id": 121,
      "situationId": "34",
      "competency": "RAZONAMIENTO CUANTITATIVO",
      "text": "Para cumplir la reserva mínima, ¿cuánto debe disminuirse como mínimo el conjunto de asignaciones propuestas?",
      "options": [
        "Cuatro millones ochocientos mil pesos, porque debe retirarse la totalidad de la reserva adicional del proyecto.",
        "Ochocientos mil pesos, porque la reserva requerida es 4,8 millones y solo quedan 4 millones.",
        "Un millón ochocientos mil pesos, porque el 10 % se calcula sobre las solicitudes de 18 millones."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: 0,10 x 48 = 4,8; faltan 0,8 millones de reserva.",
      "distractors": "Por qué no A: Confunde reserva total requerida con ajuste adicional necesario. Por qué no C: Calcula el porcentaje sobre un rubro y no sobre el total indicado.",
      "legalBasis": "Operaciones presupuestales simuladas; Decreto 4791 de 2008 como marco de competencias, no autorización específica de gasto."
    },
    {
      "id": 122,
      "situationId": "34",
      "competency": "RAZONAMIENTO CUANTITATIVO",
      "text": "¿Qué paquete financiero satisface la reserva, antes de considerar autorizaciones legales?",
      "options": [
        "Financiar 18 de dotación, 12 de accesibilidad y 14 de reparación, y registrar 4 millones como reserva suficiente.",
        "Financiar 16 millones de dotación, 12 de accesibilidad y 14 de reparación, y dejar 6 millones disponibles.",
        "Financiar 18 de dotación, 12 de accesibilidad y 15 de reparación, y conservar 4,8 millones de reserva."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: 16 + 12 + 14 = 42 y 48 - 42 = 6, superior a 4,8.",
      "distractors": "Por qué no A: Con 44 comprometidos quedan solo 4, menos de la reserva. Por qué no C: 18 + 12 + 15 = 45, por lo que solo quedan 3 millones.",
      "legalBasis": "Operaciones presupuestales simuladas; Decreto 4791 de 2008 como marco de competencias, no autorización específica de gasto."
    },
    {
      "id": 123,
      "situationId": "35",
      "competency": "RAZONAMIENTO CUANTITATIVO",
      "text": "¿Cuál es la tasa de abandono según el denominador de seguimiento definido?",
      "options": [
        "6,00 %, porque 15 abandonos se calculan sobre los 250 iniciales.",
        "14,00 %, porque los 20 traslados y 15 abandonos constituyen por igual deserción.",
        "6,52 %, obtenida de 15 abandonos sobre 230 estudiantes."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: 15/230 x 100 es aproximadamente 6,52 % según definición explícita.",
      "distractors": "Por qué no A: Es una tasa con matrícula inicial, válida para otro indicador, no el solicitado. Por qué no B: Los traslados con continuidad no deben clasificarse automáticamente como abandono.",
      "legalBasis": "Seguimiento a trayectorias, proporciones y movilidad estudiantil."
    },
    {
      "id": 124,
      "situationId": "35",
      "competency": "RAZONAMIENTO CUANTITATIVO",
      "text": "¿Cuál es la permanencia interna respecto de la matrícula inicial?",
      "options": [
        "93,48 %, porque 215 de 230 permanecieron entre quienes no se trasladaron.",
        "94,00 %, dado que solo 15 estudiantes abandonaron sin matrícula confirmada.",
        "86,00 %, pues 215 de los 250 iniciales permanecieron en ese colegio."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: 215/250 = 86 %; usa el denominador de matrícula inicial indicado.",
      "distractors": "Por qué no A: 93,48 % usa el denominador de cohorte sin traslados, no la matrícula inicial. Por qué no B: Confunde permanencia institucional con complemento de abandono sobre 250.",
      "legalBasis": "Seguimiento a trayectorias, proporciones y movilidad estudiantil."
    },
    {
      "id": 125,
      "situationId": "35",
      "competency": "RAZONAMIENTO CUANTITATIVO",
      "text": "¿Qué lectura evita confundir movilidad y abandono?",
      "options": [
        "Agrupar traslados y abandono bajo un único indicador de fracaso escolar.",
        "Reportar por separado permanencia interna, traslados confirmados y abandono, con sus denominadores.",
        "Excluir a todos los estudiantes móviles de cualquier indicador institucional sin registrarlos."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: Los fenómenos son distintos y requieren trazabilidad de trayectorias.",
      "distractors": "Por qué no A: Un traslado confirmado no implica desvinculación del sistema. Por qué no C: Omitir movilidad invisibiliza trayectorias y altera la rendición de cuentas.",
      "legalBasis": "Seguimiento a trayectorias, proporciones y movilidad estudiantil."
    },
    {
      "id": 126,
      "situationId": "36",
      "competency": "RAZONAMIENTO CUANTITATIVO",
      "text": "¿Cuál es el total ponderado del primer escenario?",
      "options": [
        "81,10 puntos, porque los 56 puntos de antecedentes equivalen a 12,60 en el total.",
        "82,50 puntos, producto de sumar 50,60; 8,80; 14,00 y 9,10.",
        "85,00 puntos, al sumar directamente los resultados sin aplicar los cuatro pesos."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: 92x0,55 + 88x0,10 + 56x0,25 + 91x0,10 = 82,50.",
      "distractors": "Por qué no A: 56x0,25 equivale a 14,00, no a 12,60. Por qué no C: La suma simple carece de sentido sin ponderación y no produce 85.",
      "legalBasis": "Tabla de ponderaciones para rector suministrada por el usuario: 55 %, 10 %, 25 %, 10 %."
    },
    {
      "id": 127,
      "situationId": "36",
      "competency": "RAZONAMIENTO CUANTITATIVO",
      "text": "En el segundo escenario, ¿qué puntaje mínimo principal permite alcanzar o superar 85,00?",
      "options": [
        "95,00 puntos, porque la contribución principal de 52,25 basta para llegar a 85.",
        "96,00 puntos, porque 52,80 de la prueba principal completan exactamente los 85 puntos.",
        "96,37 puntos si se expresa con dos decimales, porque 0,55x + 32 = 85."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Con psicotécnica 9, antecedentes 14 y entrevista 9 se aportan 32; x=53/0,55=96,3636..., por lo que 96,37 supera 85.",
      "distractors": "Por qué no A: Con 95 la suma sería 84,25. Por qué no B: Con 96 la suma sería 84,80.",
      "legalBasis": "Tabla de ponderaciones para rector suministrada por el usuario: 55 %, 10 %, 25 %, 10 %."
    },
    {
      "id": 128,
      "situationId": "36",
      "competency": "RAZONAMIENTO CUANTITATIVO",
      "text": "Si solo pudiese elevar cinco puntos una de las dos pruebas, ¿cuál mejora impactaría más la nota final?",
      "options": [
        "Ambas mejoras aportarían exactamente 0,50 puntos porque son cinco preguntas o puntos adicionales.",
        "Cinco puntos adicionales en psicotécnica: elevarían el total en 2,75 puntos por su naturaleza clasificatoria.",
        "Cinco puntos adicionales en Aptitudes y Competencias Básicas: elevarían el total en 2,75 puntos."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: El efecto depende de pesos: 5x0,55=2,75 frente a 5x0,10=0,50.",
      "distractors": "Por qué no A: El peso de la principal no es 10 % sino 55 %. Por qué no B: Cinco puntos en psicotécnica aportan 0,50 al total.",
      "legalBasis": "Tabla de ponderaciones para rector suministrada por el usuario: 55 %, 10 %, 25 %, 10 %."
    },
    {
      "id": 129,
      "situationId": "37",
      "competency": "INTEGRACIÓN DIRECTIVA",
      "text": "¿Cuál es la actuación inicial más adecuada?",
      "options": [
        "Mantener rutas sin modificaciones hasta que una autoridad confirme por escrito un daño ya producido.",
        "Verificar condiciones con instancias competentes, activar medidas preventivas proporcionales y coordinar comunicaciones y continuidad segura del servicio.",
        "Cerrar indefinidamente todas las sedes y declarar que existe emergencia general sin elementos suficientes."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: Gestiona riesgo con precaución, evidencia y proporcionalidad territorial.",
      "distractors": "Por qué no A: Esperar daño consumado expone innecesariamente a estudiantes. Por qué no C: La afectación potencial localizada no prueba riesgo igual en toda la institución.",
      "legalBasis": "Resolución MEN 003842 de 2022, funciones 6, 7, 18 y 23; Ley 1098 de 2006; enfoque de gestión de riesgos."
    },
    {
      "id": 130,
      "situationId": "37",
      "competency": "INTEGRACIÓN DIRECTIVA",
      "text": "¿Qué actualización institucional debe priorizarse una vez controlada la urgencia?",
      "options": [
        "Sustituir la planificación escolar por avisos informales de grupos de mensajería.",
        "Archivar el incidente porque la creciente disminuyó y no se produjeron víctimas.",
        "Revisar plan de riesgo con rutas, responsables, alertas y simulacros diferenciados por sede y comunidad."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: La prevención sistémica requiere planes revisados y operables.",
      "distractors": "Por qué no A: Los mensajes pueden apoyar, pero no sustituyen protocolos formales. Por qué no B: La ausencia de daño no elimina la vulnerabilidad identificada.",
      "legalBasis": "Resolución MEN 003842 de 2022, funciones 6, 7, 18 y 23; Ley 1098 de 2006; enfoque de gestión de riesgos."
    },
    {
      "id": 131,
      "situationId": "37",
      "competency": "INTEGRACIÓN DIRECTIVA",
      "text": "¿Qué debe orientar el plan de recuperación de clases si se suspendió una jornada?",
      "options": [
        "Declarar la jornada recuperada en los registros porque la suspensión obedeció a fuerza mayor.",
        "Priorizar aprendizajes y estudiantes afectados con alternativas seguras, registro y seguimiento de recuperación.",
        "Asignar el mismo trabajo autónomo extenso a todos los cursos sin verificar acceso ni necesidades."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: La continuidad se evalúa por atención y aprendizaje reales.",
      "distractors": "Por qué no A: La justificación de una suspensión no equivale a recuperar aprendizajes. Por qué no C: Una carga uniforme puede no ser viable para estudiantes afectados.",
      "legalBasis": "Resolución MEN 003842 de 2022, funciones 6, 7, 18 y 23; Ley 1098 de 2006; enfoque de gestión de riesgos."
    },
    {
      "id": 132,
      "situationId": "38",
      "competency": "INTEGRACIÓN DIRECTIVA",
      "text": "¿Qué criterio debería orientar la revisión de la nota?",
      "options": [
        "Otorgar aprobación automática para compensar el conflicto, sin valorar los aprendizajes del período.",
        "Conservar la reprobación como sanción pedagógica por salir del salón, sin revisar evidencias de competencias.",
        "Verificar evidencias del aprendizaje según SIEE, ajustes y apoyos aplicables, separando las decisiones de convivencia que tengan su propio trámite."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: La evaluación de competencias requiere criterios pedagógicos, no castigos encubiertos.",
      "distractors": "Por qué no A: Corregir un procedimiento no obliga a atribuir aprendizaje no demostrado. Por qué no B: La salida del aula no sustituye la valoración académica prevista.",
      "legalBasis": "Decreto 1290 de 2009; Ley 1620 de 2013; Ley 1098 de 2006; Resolución MEN 003842 de 2022."
    },
    {
      "id": 133,
      "situationId": "38",
      "competency": "INTEGRACIÓN DIRECTIVA",
      "text": "La actuación del rector frente a docente y familia sería:",
      "options": [
        "Declarar que toda revisión viola la autonomía docente y rechazar sin estudiar el reclamo.",
        "Garantizar trámite de reclamación y escucha de las partes, solicitar soportes y decidir o encauzar según competencias del SIEE.",
        "Ordenar una nota específica por teléfono al docente para cerrar el conflicto de inmediato."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: La dirección vela por reglas institucionales y garantías de revisión.",
      "distractors": "Por qué no A: La autonomía docente se ejerce dentro del SIEE y admite reclamaciones. Por qué no C: Una orden verbal sin procedimiento deslegitima evaluación.",
      "legalBasis": "Decreto 1290 de 2009; Ley 1620 de 2013; Ley 1098 de 2006; Resolución MEN 003842 de 2022."
    },
    {
      "id": 134,
      "situationId": "38",
      "competency": "INTEGRACIÓN DIRECTIVA",
      "text": "¿Qué mejora institucional prevendría casos semejantes?",
      "options": [
        "Precisar protocolos de articulación entre convivencia, apoyos y evaluación, con formación y revisión de prácticas.",
        "Dejar a cada área total libertad para definir sanciones académicas sin reglas comunes.",
        "Incorporar al SIEE la pérdida automática de una asignatura ante cualquier falta de convivencia."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: La coordinación entre sistemas protege coherencia y derechos.",
      "distractors": "Por qué no B: La ausencia de criterios unificados reproduce arbitrariedad. Por qué no C: La sanción automática confunde conducta y evidencia de aprendizaje.",
      "legalBasis": "Decreto 1290 de 2009; Ley 1620 de 2013; Ley 1098 de 2006; Resolución MEN 003842 de 2022."
    },
    {
      "id": 135,
      "situationId": "39",
      "competency": "INTEGRACIÓN DIRECTIVA",
      "text": "¿Qué conclusión comparativa sobre las tasas es correcta?",
      "options": [
        "La sede A mejoró 18 % y la B 6 %, porque esos son los aumentos absolutos de estudiantes con logro.",
        "La sede A mejoró 18 puntos porcentuales y la sede B 12, aunque ambas partieron de 60 %.",
        "Ambas sedes mejoraron 18 puntos porcentuales, pues el porcentaje inicial era idéntico."
      ],
      "correct": 1,
      "explanation": "Por qué es la mejor: A pasó de 60 a 78 % y B de 60 a 72 %, diferencias de 18 y 12 pp.",
      "distractors": "Por qué no A: Confunde número de personas con incremento porcentual. Por qué no C: Tener igual punto inicial no implica igual tasa posterior.",
      "legalBasis": "Decreto 1290 de 2009; Ley 115 de 1994, art. 80; Resolución MEN 003842 de 2022."
    },
    {
      "id": 136,
      "situationId": "39",
      "competency": "INTEGRACIÓN DIRECTIVA",
      "text": "¿Qué afirmación institucional es más prudente?",
      "options": [
        "Se observan avances en ambas sedes, sin poder atribuirlos exclusivamente al plan ante ausencia de comparación causal.",
        "No existe ninguna evidencia útil de progreso porque no se incorporó grupo de control.",
        "El plan explica por completo la mejora porque los instrumentos se mantuvieron constantes."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: Los cambios descriptivos son evaluables aun sin prueba causal concluyente.",
      "distractors": "Por qué no B: La carencia de grupo de control limita causalidad, no toda descripción. Por qué no C: Instrumentos equivalentes no eliminan otros factores temporales.",
      "legalBasis": "Decreto 1290 de 2009; Ley 115 de 1994, art. 80; Resolución MEN 003842 de 2022."
    },
    {
      "id": 137,
      "situationId": "39",
      "competency": "INTEGRACIÓN DIRECTIVA",
      "text": "Si el rector debe priorizar apoyos adicionales, conviene:",
      "options": [
        "Asignar automáticamente todo el recurso a la sede A por mostrar mayor incremento absoluto.",
        "Asignar todo a B por tener menos estudiantes, sin revisar desempeño final ni barreras.",
        "Complementar las tasas con análisis de estudiantes aún sin logro, barreras y necesidades de cada sede."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Una asignación responsable considera necesidades pendientes y contexto.",
      "distractors": "Por qué no A: La mejora pasada no determina por sí sola prioridad futura. Por qué no B: El tamaño menor de población no equivale a mayor necesidad.",
      "legalBasis": "Decreto 1290 de 2009; Ley 115 de 1994, art. 80; Resolución MEN 003842 de 2022."
    },
    {
      "id": 138,
      "situationId": "40",
      "competency": "INTEGRACIÓN DIRECTIVA",
      "text": "¿Cuál secuencia de gestión es más sólida?",
      "options": [
        "Cancelar la propuesta porque toda modificación de jornada escolar excede por definición cualquier iniciativa institucional.",
        "Firmar primero el convenio y exigir a la planta docente ampliar horarios mientras la Secretaría revisa posteriormente la viabilidad.",
        "Precisar necesidad y alcance, estudiar viabilidad pedagógica y operativa, deliberar con instancias competentes y gestionar autorizaciones externas cuando correspondan."
      ],
      "correct": 2,
      "explanation": "Por qué es la mejor: Integra planeación y delimitación de competencias antes de comprometer la operación.",
      "distractors": "Por qué no A: La institución puede formular propuestas, aunque requieran autorizaciones. Por qué no B: Un convenio no habilita extender obligaciones laborales o prestación sin trámite.",
      "legalBasis": "Resolución MEN 003842 de 2022, funciones del rector; Ley 115 de 1994; Decreto 1075 de 2015."
    },
    {
      "id": 139,
      "situationId": "40",
      "competency": "INTEGRACIÓN DIRECTIVA",
      "text": "¿Qué condición evita que la fundación determine indebidamente el proyecto?",
      "options": [
        "Definir propósitos, indicadores, protección de estudiantes y responsabilidades institucionales antes de aceptar condiciones del aliado.",
        "Delegar a la fundación la fijación del currículo y la evaluación porque aporta recursos propios.",
        "Permitir que el aliado seleccione estudiantes únicamente por su capacidad de pagar transporte adicional."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: La cooperación debe responder al PEI y al derecho a la educación.",
      "distractors": "Por qué no B: La financiación no desplaza responsabilidades curriculares institucionales. Por qué no C: Un filtro económico puede excluir injustificadamente a estudiantes.",
      "legalBasis": "Resolución MEN 003842 de 2022, funciones del rector; Ley 115 de 1994; Decreto 1075 de 2015."
    },
    {
      "id": 140,
      "situationId": "40",
      "competency": "INTEGRACIÓN DIRECTIVA",
      "text": "Para decidir continuidad del programa tras el piloto, la mejor evidencia sería:",
      "options": [
        "Aprendizajes, permanencia, participación, sostenibilidad operativa y cumplimiento de condiciones institucionales.",
        "Número de fotografías de actividades, asistencia a inauguración y menciones del proyecto en prensa.",
        "La declaración del financiador de que se ejecutó la totalidad de su aporte económico."
      ],
      "correct": 0,
      "explanation": "Por qué es la mejor: La continuidad debe fundarse en impacto educativo y viabilidad integral.",
      "distractors": "Por qué no B: La visibilidad no equivale a resultados de aprendizaje. Por qué no C: La ejecución financiera es necesaria para control, pero no demuestra eficacia pedagógica.",
      "legalBasis": "Resolución MEN 003842 de 2022, funciones del rector; Ley 115 de 1994; Decreto 1075 de 2015."
    },
    {
      "id": 141,
      "originalId": 1,
      "sourceExam": 2,
      "situationId": "S2-01",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se audita la documentación propuesta, ¿qué expediente exigiría la mayor subsanación?",
      "options": [
        "Expediente contrastado de transporte en ruta inundable: alertas climáticas, reportes de ruta, convenios y opciones de contingencia, con índice y control de versiones.",
        "Alertas climáticas, análisis de riesgo, convenios y opciones de contingencia, con registro de las decisiones tomadas durante el período de atención del asunto, para que el equipo responsable conozca los efectos esperados y los pasos anunciados.",
        "Alertas climáticas, reportes de ruta, convenios y opciones de contingencia."
      ],
      "correct": 1,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nC. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de coordinar evaluación y alternativas de movilidad segura con responsables del servicio y familias.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 142,
      "originalId": 2,
      "sourceExam": 2,
      "situationId": "S2-01",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Entre las siguientes propuestas de seguimiento, ¿cuál deja una brecha de medición más relevante?",
      "options": [
        "Seguimiento desagregado por período y población de: trayectos seguros realizados y días de continuidad educativa protegida.",
        "Días de servicio seguro, continuidad pedagógica y pérdidas evitadas, como parte de una decisión comunicada a los equipos que resultarían directamente involucrados.",
        "Trayectos seguros realizados y días de continuidad educativa protegida."
      ],
      "correct": 1,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.\n\nC. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 143,
      "originalId": 3,
      "sourceExam": 2,
      "situationId": "S2-01",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué propuesta presenta el riesgo institucional más grave, a pesar de sus aparentes ventajas operativas?",
      "options": [
        "Coordinar evaluación y alternativas de movilidad segura con responsables del servicio y familias, después de revisar el calendario de trabajo de cada coordinación.",
        "Examinar los soportes asociados a transporte en ruta inundable, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Acordar con el operador un monitoreo diario y mantener el recorrido habitual hasta que la autoridad declare cierre oficial; con indicación del período al que se refiere la propuesta de actuación y sus consecuencias."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la prevención, la protección de personas y la continuidad segura del servicio.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la prevención, la protección de personas y la continuidad segura del servicio.\n\nB. La alternativa preserva un examen previo y fundamentado de transporte en ruta inundable antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 144,
      "originalId": 4,
      "sourceExam": 2,
      "situationId": "S2-02",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál conjunto documental permitiría una conclusión menos sólida sobre la actuación?",
      "options": [
        "Trayectoria educativa, relato, disponibilidad y necesidades lingüísticas.",
        "Expediente contrastado de migración en mitad de período: trayectoria educativa, valoración diagnóstica, disponibilidad y necesidades lingüísticas, con índice y control de versiones.",
        "Trayectoria educativa, valoración diagnóstica, disponibilidad y necesidades lingüísticas."
      ],
      "correct": 0,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "B. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nC. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de gestionar acceso y acompañamiento de acogida, sin discriminación y con evaluación diagnóstica pedagógica.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 145,
      "originalId": 5,
      "sourceExam": 2,
      "situationId": "S2-02",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cómo debería proceder la dirección del establecimiento en este escenario?",
      "options": [
        "Gestionar acceso y acompañamiento de acogida, sin discriminación y con evaluación diagnóstica pedagógica; con una constancia escrita de las razones utilizadas para orientar la actuación institucional.",
        "Matricular en grupos provisionales de nivelación separados y transferir al aula regular después de una prueba común.",
        "Asignar cupos disponibles y ubicar al alumnado por edad, programando valoración pedagógica al terminar el primer período; con referencia explícita al contexto escolar particular que originó la controversia."
      ],
      "correct": 0,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la garantía del derecho a la educación y la articulación de protección.",
      "distractors": "B. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.\n\nC. Aunque identifica una salida posible, omite una condición sustantiva para la garantía del derecho a la educación y la articulación de protección.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 146,
      "originalId": 6,
      "sourceExam": 2,
      "situationId": "S2-02",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué indicador tendría menor validez para establecer si se resolvió la necesidad institucional descrita?",
      "options": [
        "Seguimiento desagregado por período y población de: permanencia e integración académica sin exclusiones por procedencia.",
        "Permanencia e integración académica sin exclusiones por procedencia.",
        "Continuidad de trayectoria con decisiones de traslado documentadas y justificadas."
      ],
      "correct": 2,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.\n\nB. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 147,
      "originalId": 7,
      "sourceExam": 2,
      "situationId": "S2-02",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referente delimita de forma más directa las responsabilidades institucionales involucradas?",
      "options": [
        "Ley 1620 de 2013 y sus rutas institucionales",
        "Decreto 1421 de 2017, educación inclusiva y PIAR",
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes"
      ],
      "correct": 2,
      "explanation": "Este marco se relaciona de modo más directo con la garantía del derecho a la educación y la articulación de protección. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nB. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 148,
      "originalId": 8,
      "sourceExam": 2,
      "situationId": "S2-03",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Para orientar la motivación jurídica inicial, ¿qué marco ofrece la conexión más pertinente con los hechos?",
      "options": [
        "Decreto 1290 de 2009, art. 11",
        "Ley 115 de 1994, objetivos, áreas y proyectos educativos",
        "Resolución MEN 003842 de 2022, gestión académica"
      ],
      "correct": 0,
      "explanation": "Este marco se relaciona de modo más directo con las reglas del SIEE, los apoyos y la motivación de decisiones académicas. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "B. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nC. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 149,
      "originalId": 9,
      "sourceExam": 2,
      "situationId": "S2-03",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál formulación introduce la limitación más importante al evaluar el resultado y no solo la gestión?",
      "options": [
        "Reclamaciones resueltas motivadamente en los plazos establecidos, con indicación del período al que se refiere la propuesta de actuación y sus consecuencias.",
        "Seguimiento desagregado por período y población de: correspondencia entre calificaciones y criterios de aprendizaje anunciados.",
        "Correspondencia entre calificaciones y criterios de aprendizaje anunciados."
      ],
      "correct": 0,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "B. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.\n\nC. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 150,
      "originalId": 10,
      "sourceExam": 2,
      "situationId": "S2-03",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál de las medidas planteadas podría producir una actuación institucional objetable por su alcance o secuencia?",
      "options": [
        "Examinar los soportes asociados a nota por disciplina, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Distinguir evaluación de aprendizaje y medidas de convivencia, revisar el SIEE y garantizar reclamación fundada; como parte de una decisión comunicada a los equipos que resultarían directamente involucrados.",
        "Mantener temporalmente la nota disciplinaria y ofrecer al estudiante una actividad adicional para recuperar el puntaje."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para las reglas del SIEE, los apoyos y la motivación de decisiones académicas.",
      "distractors": "A. La alternativa preserva un examen previo y fundamentado de nota por disciplina antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nB. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta las reglas del SIEE, los apoyos y la motivación de decisiones académicas.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 151,
      "originalId": 11,
      "sourceExam": 2,
      "situationId": "S2-03",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Antes de cerrar el análisis, ¿qué información resulta más decisiva para contrastar las afirmaciones?",
      "options": [
        "Criterios del SIEE, rúbrica de área, registro del desempeño y queja documentada.",
        "Criterios del SIEE, rúbrica de área, normas del SIEE y queja documentada, con registro de las decisiones tomadas durante el período de atención del asunto.",
        "Criterios del SIEE, evidencias de desempeño, registro del desempeño y queja documentada."
      ],
      "correct": 0,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de distinguir evaluación de aprendizaje y medidas de convivencia, revisar el siee y garantizar reclamación fundada.",
      "distractors": "B. Esta selección es parcial: no integra registro del desempeño, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra rúbrica de área, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 152,
      "originalId": 12,
      "sourceExam": 2,
      "situationId": "S2-04",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué medida sería menos adecuada como indicador principal para rendir cuentas sobre el resultado específico del caso?",
      "options": [
        "Días de exposición al riesgo y continuidad segura del aprendizaje, con un resumen de los antecedentes que motivaron la convocatoria de los participantes.",
        "Tiempo y seguridad de evacuación de toda la población, desagregados por necesidades.",
        "Seguimiento desagregado por período y población de: tiempo y seguridad de evacuación de toda la población, desagregados por necesidades, con una secuencia de comunicación posterior para facilitar el seguimiento de sus efectos."
      ],
      "correct": 0,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "B. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.\n\nC. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 153,
      "originalId": 13,
      "sourceExam": 2,
      "situationId": "S2-04",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué selección de soportes dejaría el vacío probatorio más importante para justificar la decisión?",
      "options": [
        "Registros de tiempos, barreras de circulación, roles asignados y observaciones.",
        "Expediente contrastado de simulacro de evacuación fallido: registros de tiempos, barreras de circulación, roles asignados y observaciones, con índice y control de versiones.",
        "Registros de tiempos, registros de cortes, roles asignados y observaciones, durante la fase de evaluación definida en el cronograma de gestión de la institución, con una secuencia de comunicación posterior para facilitar el seguimiento de sus efectos."
      ],
      "correct": 2,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de rediseñar rutas, roles y apoyos accesibles, ejecutar pruebas y corregir con evidencias.\n\nB. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 154,
      "originalId": 14,
      "sourceExam": 2,
      "situationId": "S2-04",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál propuesta es jurídicamente y pedagógicamente más defendible?",
      "options": [
        "Modificar únicamente los tiempos objetivo de evacuación e introducir señalización adicional en la ruta ya utilizada.",
        "Rediseñar rutas, roles y apoyos accesibles, ejecutar pruebas y corregir con evidencias.",
        "Repetir el ejercicio con apoyos temporales para quienes tuvieron dificultad y actualizar el plan tras comparar tiempos generales."
      ],
      "correct": 1,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la prevención, la protección de personas y la continuidad segura del servicio.",
      "distractors": "A. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.\n\nC. Aunque identifica una salida posible, omite una condición sustantiva para la prevención, la protección de personas y la continuidad segura del servicio.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 155,
      "originalId": 15,
      "sourceExam": 2,
      "situationId": "S2-04",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referencia normativa conviene revisar primero por su relación directa con el caso?",
      "options": [
        "Resolución MEN 003842 de 2022, gestión institucional y recursos",
        "Ley 715 de 2001, art. 10, funciones del rector",
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes"
      ],
      "correct": 0,
      "explanation": "Este marco se relaciona de modo más directo con la prevención, la protección de personas y la continuidad segura del servicio. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "B. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nC. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 156,
      "originalId": 16,
      "sourceExam": 2,
      "situationId": "S2-05",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "De las siguientes actuaciones, ¿cuál requeriría una corrección prioritaria por comprometer el procedimiento o la garantía central del caso?",
      "options": [
        "Examinar los soportes asociados a escuela de padres punitiva, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Aprobar el régimen de sanciones y permitir exoneraciones individuales a quienes acrediten dificultades de asistencia; con anotación de las circunstancias específicas del establecimiento en la fecha de la decisión.",
        "Diseñar compromisos y participación bajo el marco de Alianza Familias-Escuela y las reglas aplicables, por medio de una circular institucional y un informe posterior de resultados."
      ],
      "correct": 1,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la participación significativa, la accesibilidad y el diálogo territorial.",
      "distractors": "A. La alternativa preserva un examen previo y fundamentado de escuela de padres punitiva antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nC. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la participación significativa, la accesibilidad y el diálogo territorial.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 157,
      "originalId": 17,
      "sourceExam": 2,
      "situationId": "S2-05",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál evidencia de resultado permitiría una evaluación menos sesgada?",
      "options": [
        "Secuencias interculturales implementadas con participación y aprendizajes pertinentes.",
        "Prácticas con supervisión, cobertura de riesgos y tratamiento legítimo de datos.",
        "Cumplimiento razonable de compromisos y mejora de participación accesible, con seguimiento documental del cambio anunciado en el proceso escolar de referencia."
      ],
      "correct": 2,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir cumplimiento razonable de compromisos, componente esencial del resultado propuesto.\n\nB. Considera una variable relacionada con el caso, pero deja sin medir cumplimiento razonable de compromisos, componente esencial del resultado propuesto.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 158,
      "originalId": 18,
      "sourceExam": 2,
      "situationId": "S2-05",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se audita la documentación propuesta, ¿qué expediente exigiría la mayor subsanación?",
      "options": [
        "Actas de construcción de compromisos, barreras justificadas y comunicaciones.",
        "Expediente contrastado de escuela de padres punitiva: actas de construcción de compromisos, barreras justificadas y comunicaciones, con índice y control de versiones.",
        "Actas de construcción de compromisos, cobertura de comunicaciones y comunicaciones, con una secuencia de comunicación posterior para facilitar el seguimiento de sus efectos."
      ],
      "correct": 2,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de diseñar compromisos y participación bajo el marco de alianza familias-escuela y las reglas aplicables.\n\nB. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 159,
      "originalId": 19,
      "sourceExam": 2,
      "situationId": "S2-06",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué indicador tendría menor validez para establecer si se resolvió la necesidad institucional descrita?",
      "options": [
        "Porcentaje de acciones de mejora implementadas y respaldadas por evidencias de aprendizaje.",
        "Avance de estudiantes entre niveles de competencia en períodos equivalentes, con un resumen de los antecedentes que motivaron la convocatoria de los participantes.",
        "Seguimiento desagregado por período y población de: avance de estudiantes entre niveles de competencia en períodos equivalentes."
      ],
      "correct": 0,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "B. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.\n\nC. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 160,
      "originalId": 20,
      "sourceExam": 2,
      "situationId": "S2-06",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Ante la situación descrita, ¿cuál actuación del rector constituye la respuesta mejor fundada?",
      "options": [
        "Mantener el mismo objetivo para todos los cursos y definir apoyos después de identificar quiénes no lo alcanzaron.",
        "Aprobar la meta integral y negociar resultados parciales con los docentes una vez se conozca el primer período.",
        "Convertir el objetivo en metas exigentes pero evaluables, sustentadas en línea de base y rutas de apoyo; con seguimiento documental del cambio anunciado en el proceso escolar de referencia."
      ],
      "correct": 2,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la coherencia entre diagnóstico, metas, ejecución y evidencia.",
      "distractors": "A. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.\n\nB. Aunque identifica una salida posible, omite una condición sustantiva para la coherencia entre diagnóstico, metas, ejecución y evidencia.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 161,
      "originalId": 21,
      "sourceExam": 2,
      "situationId": "S2-06",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referente delimita de forma más directa las responsabilidades institucionales involucradas?",
      "options": [
        "Resolución MEN 003842 de 2022, gestión académica",
        "Ley 715 de 2001, art. 10",
        "Ley 115 de 1994, arts. 142-145"
      ],
      "correct": 1,
      "explanation": "Este marco se relaciona de modo más directo con la coherencia entre diagnóstico, metas, ejecución y evidencia. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nC. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 162,
      "originalId": 22,
      "sourceExam": 2,
      "situationId": "S2-06",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál conjunto documental permitiría una conclusión menos sólida sobre la actuación?",
      "options": [
        "Distribución inicial de niveles, líneas de base por sede y seguimiento por cohortes.",
        "Expediente contrastado de objetivo anual inalcanzable: distribución inicial de niveles, intervenciones posibles y seguimiento por cohortes, con índice y control de versiones.",
        "Distribución inicial de niveles, intervenciones posibles y seguimiento por cohortes, para atender la solicitud presentada formalmente ante la dirección de la institución."
      ],
      "correct": 0,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "B. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nC. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de convertir el objetivo en metas exigentes pero evaluables, sustentadas en línea de base y rutas de apoyo.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 163,
      "originalId": 23,
      "sourceExam": 2,
      "situationId": "S2-07",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Para revisar el avance dentro de un período comparable, ¿qué indicador tiene mayor pertinencia?",
      "options": [
        "Raciones seguras efectivamente servidas y días de interrupción atendidos, en el marco de la discusión sostenida con quienes participaron en la reunión preparatoria.",
        "Permanencia e integración académica sin exclusiones por procedencia.",
        "Protección activada oportunamente y seguimiento articulado sin revictimización."
      ],
      "correct": 2,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir protección activada oportunamente, componente esencial del resultado propuesto.\n\nB. Considera una variable relacionada con el caso, pero deja sin medir protección activada oportunamente, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 164,
      "originalId": 24,
      "sourceExam": 2,
      "situationId": "S2-07",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué combinación de documentos sería la menos adecuada para examinar las condiciones del supuesto?",
      "options": [
        "Relato, informes de entrega, registros de atención y remisión pertinente, según el informe preparado por la coordinación responsable de revisar la propuesta, junto con la constancia de revisión de las condiciones informadas por los responsables.",
        "Relato, indicadores de riesgo y registros de atención y remisión pertinente.",
        "Expediente contrastado de violencia intrafamiliar sospechada: relato, indicadores de riesgo y registros de atención y remisión pertinente, con índice y control de versiones."
      ],
      "correct": 0,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "B. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de valorar riesgo, proteger confidencialidad relativa y activar las rutas de protección según hechos y competencia.\n\nC. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 165,
      "originalId": 25,
      "sourceExam": 2,
      "situationId": "S2-07",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Para orientar la motivación jurídica inicial, ¿qué marco ofrece la conexión más pertinente con los hechos?",
      "options": [
        "Ley 1620 de 2013 y sus rutas institucionales",
        "Decreto 1421 de 2017, educación inclusiva y PIAR",
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes"
      ],
      "correct": 2,
      "explanation": "Este marco se relaciona de modo más directo con la garantía del derecho a la educación y la articulación de protección. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nB. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 166,
      "originalId": 26,
      "sourceExam": 2,
      "situationId": "S2-07",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se comparan tres rutas de decisión, ¿cuál resultaría menos defendible ante una revisión de competencias y garantías?",
      "options": [
        "Examinar los soportes asociados a violencia intrafamiliar sospechada, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Valorar riesgo, proteger confidencialidad relativa y activar las rutas de protección según hechos y competencia.",
        "Solicitar primero versiones familiares contrastadas y abrir acompañamiento escolar cuando exista un relato común verificable; con referencia explícita al contexto escolar particular que originó la controversia."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la garantía del derecho a la educación y la articulación de protección.",
      "distractors": "A. La alternativa preserva un examen previo y fundamentado de violencia intrafamiliar sospechada antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nB. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la garantía del derecho a la educación y la articulación de protección.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 167,
      "originalId": 27,
      "sourceExam": 2,
      "situationId": "S2-08",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué medida sería menos adecuada como indicador principal para rendir cuentas sobre el resultado específico del caso?",
      "options": [
        "Progreso de aprendizaje por condición de acceso y sede.",
        "Seguimiento desagregado por período y población de: progreso por nivel curricular y participación de estudiantes en el aula multigrado.",
        "Progreso por nivel curricular y participación de estudiantes en el aula multigrado."
      ],
      "correct": 0,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "B. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.\n\nC. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 168,
      "originalId": 28,
      "sourceExam": 2,
      "situationId": "S2-08",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué alternativa es más consistente con la responsabilidad directiva frente a los hechos?",
      "options": [
        "Diseñar unidades por asignatura con productos iguales para todos y permitir ritmos distintos sin progresión específica.",
        "Conservar la guía común e incorporar tareas de dificultad variable según el tiempo libre disponible en cada grupo.",
        "Diseñar secuencias flexibles por progresión de competencias y apoyos según ritmos y edades; con anotación de las circunstancias específicas del establecimiento en la fecha de la decisión."
      ],
      "correct": 2,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la correspondencia entre objetivos curriculares, apoyos didácticos y aprendizaje.",
      "distractors": "A. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.\n\nB. Aunque identifica una salida posible, omite una condición sustantiva para la correspondencia entre objetivos curriculares, apoyos didácticos y aprendizaje.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 169,
      "originalId": 29,
      "sourceExam": 2,
      "situationId": "S2-08",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué conjunto de evidencias permitiría sustentar de manera más sólida la decisión?",
      "options": [
        "Competencias por grado, muestras de trabajo, planes de área y tiempos de atención.",
        "Competencias por grado, muestras de argumentación, observación y tiempos de atención, con una descripción de las condiciones que la rectoría consideró relevantes en este supuesto.",
        "Competencias por grado, muestras de trabajo, observación y tiempos de atención, con una comunicación dirigida a los actores mencionados en el expediente institucional."
      ],
      "correct": 2,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de diseñar secuencias flexibles por progresión de competencias y apoyos según ritmos y edades.",
      "distractors": "A. Esta selección es parcial: no integra observación, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nB. Esta selección es parcial: no integra muestras de trabajo, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 170,
      "originalId": 30,
      "sourceExam": 2,
      "situationId": "S2-09",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Entre las siguientes propuestas de seguimiento, ¿cuál deja una brecha de medición más relevante?",
      "options": [
        "Tiempo de homologación y continuidad académica sin perjuicios injustificados.",
        "Reclamaciones resueltas motivadamente en los plazos establecidos, con indicación del período al que se refiere la propuesta de actuación y sus consecuencias.",
        "Seguimiento desagregado por período y población de: tiempo de homologación y continuidad académica sin perjuicios injustificados, con registro de las decisiones tomadas durante el período de atención del asunto."
      ],
      "correct": 1,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.\n\nC. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 171,
      "originalId": 31,
      "sourceExam": 2,
      "situationId": "S2-09",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se audita la documentación propuesta, ¿qué expediente exigiría la mayor subsanación?",
      "options": [
        "Certificados, normas del SIEE, equivalencias y criterios del SIEE, con una comunicación dirigida a los actores mencionados en el expediente institucional.",
        "Certificados, escalas institucionales, equivalencias y criterios del SIEE.",
        "Expediente contrastado de escalas sin equivalencia: certificados, escalas institucionales, equivalencias y criterios del SIEE, con índice y control de versiones."
      ],
      "correct": 0,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "B. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de aplicar el procedimiento de homologación previsto en el siee, con interpretación de desempeños y apoyos.\n\nC. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 172,
      "originalId": 32,
      "sourceExam": 2,
      "situationId": "S2-09",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué iniciativa sería más difícil de justificar si se confronta con las obligaciones rectorales pertinentes?",
      "options": [
        "Aplicar el procedimiento de homologación previsto en el SIEE, con interpretación de desempeños y apoyos, con el acompañamiento del comité correspondiente y registros de avance.",
        "Establecer una equivalencia provisional a partir del promedio numérico y revisarla tras la primera evaluación en la sede; con registro de las decisiones tomadas durante el período de atención del asunto.",
        "Examinar los soportes asociados a escalas sin equivalencia, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables."
      ],
      "correct": 1,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para las reglas del SIEE, los apoyos y la motivación de decisiones académicas.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta las reglas del SIEE, los apoyos y la motivación de decisiones académicas.\n\nC. La alternativa preserva un examen previo y fundamentado de escalas sin equivalencia antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 173,
      "originalId": 33,
      "sourceExam": 2,
      "situationId": "S2-10",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "De las siguientes actuaciones, ¿cuál requeriría una corrección prioritaria por comprometer el procedimiento o la garantía central del caso?",
      "options": [
        "Conservar el calendario y solicitar al comité electoral una aclaración posterior sobre requisitos que ya se aplicaron; con referencia explícita al contexto escolar particular que originó la controversia.",
        "Examinar los soportes asociados a elección estudiantil impugnada, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables; como parte de una decisión comunicada a los equipos que resultarían directamente involucrados.",
        "Revisar reglas vigentes y debido proceso electoral, resolver con publicidad y corregir únicamente los actos afectados."
      ],
      "correct": 0,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para el reparto de competencias y la participación válida del gobierno escolar.",
      "distractors": "B. La alternativa preserva un examen previo y fundamentado de elección estudiantil impugnada antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nC. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta el reparto de competencias y la participación válida del gobierno escolar.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Ley 715 de 2001, art. 10"
    },
    {
      "id": 174,
      "originalId": 34,
      "sourceExam": 2,
      "situationId": "S2-10",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué indicador tendría menor validez para establecer si se resolvió la necesidad institucional descrita?",
      "options": [
        "Seguimiento desagregado por período y población de: reclamaciones electorales resueltas con motivación y oportunidad, por etapa del proceso.",
        "Proporción de disposiciones revisadas con participación y compatibilidad con garantías de derechos.",
        "Reclamaciones electorales resueltas con motivación y oportunidad, por etapa del proceso."
      ],
      "correct": 1,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.\n\nC. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Ley 715 de 2001, art. 10"
    },
    {
      "id": 175,
      "originalId": 35,
      "sourceExam": 2,
      "situationId": "S2-10",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referente delimita de forma más directa las responsabilidades institucionales involucradas?",
      "options": [
        "Ley 715 de 2001, art. 10",
        "Ley 115 de 1994, arts. 142-145",
        "Ley 715 de 2001, art. 10, funciones del rector"
      ],
      "correct": 1,
      "explanation": "Este marco se relaciona de modo más directo con el reparto de competencias y la participación válida del gobierno escolar. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nC. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Ley 715 de 2001, art. 10"
    },
    {
      "id": 176,
      "originalId": 36,
      "sourceExam": 2,
      "situationId": "S2-10",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál conjunto documental permitiría una conclusión menos sólida sobre la actuación?",
      "options": [
        "Cronología de publicación de requisitos, inscripciones, votación y reclamaciones.",
        "Cronología de publicación de requisitos, plan de compras, votación y reclamaciones, como parte de una decisión comunicada a los equipos que resultarían directamente involucrados.",
        "Expediente contrastado de elección estudiantil impugnada: cronología de publicación de requisitos, inscripciones, votación y reclamaciones, con índice y control de versiones."
      ],
      "correct": 1,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de revisar reglas vigentes y debido proceso electoral, resolver con publicidad y corregir únicamente los actos afectados.\n\nC. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Ley 715 de 2001, art. 10"
    },
    {
      "id": 177,
      "originalId": 37,
      "sourceExam": 2,
      "situationId": "S2-11",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuántas raciones programadas no se entregaron en los dos días?",
      "options": [
        "88",
        "82",
        "92"
      ],
      "correct": 0,
      "explanation": "440 programadas menos 352 entregadas son 88 raciones faltantes.",
      "distractors": "B. Corresponde a una operación o denominador distinto del definido; no coincide con los datos.\n\nC. Confunde una magnitud con otra o realiza una agregación que altera la base de comparación.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de razonamiento cuantitativo"
    },
    {
      "id": 178,
      "originalId": 38,
      "sourceExam": 2,
      "situationId": "S2-11",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿En cuánto difieren las tasas de cobertura de lunes y martes?",
      "options": [
        "0 puntos porcentuales",
        "2 puntos porcentuales",
        "4 puntos porcentuales"
      ],
      "correct": 0,
      "explanation": "168/210 = 80 % y 184/230 = 80 %; las tasas son iguales pese a los distintos números absolutos.",
      "distractors": "B. Confunde una magnitud con otra o realiza una agregación que altera la base de comparación.\n\nC. Corresponde a una operación o denominador distinto del definido; no coincide con los datos.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de razonamiento cuantitativo"
    },
    {
      "id": 179,
      "originalId": 39,
      "sourceExam": 2,
      "situationId": "S2-11",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál es la cobertura acumulada de los dos días?",
      "options": [
        "78 %",
        "80 %",
        "82 %"
      ],
      "correct": 1,
      "explanation": "(168 + 184) / (210 + 230) = 352/440 = 80 %. Se suman numeradores y denominadores.",
      "distractors": "A. Corresponde a una operación o denominador distinto del definido; no coincide con los datos.\n\nC. Confunde una magnitud con otra o realiza una agregación que altera la base de comparación.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de razonamiento cuantitativo"
    },
    {
      "id": 180,
      "originalId": 40,
      "sourceExam": 2,
      "situationId": "S2-12",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué medida permitiría valorar el resultado de la intervención sin confundir actividad con impacto?",
      "options": [
        "Tiempo de activación de protección y cumplimiento de medidas de seguimiento.",
        "Cumplimiento de medidas de seguimiento y asistencia a reuniones, junto con la constancia de revisión de las condiciones informadas por los responsables.",
        "Barreras de participación eliminadas sin afectar objetivos institucionales legítimos."
      ],
      "correct": 0,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "B. Considera una variable relacionada con el caso, pero deja sin medir tiempo de activación de protección, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir tiempo de activación de protección, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 181,
      "originalId": 41,
      "sourceExam": 2,
      "situationId": "S2-12",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué fuentes deberían triangularse para reducir el riesgo de una conclusión apresurada?",
      "options": [
        "Información inicial de riesgo, medidas previas y constancias de remisión pertinente.",
        "Información inicial de riesgo, medidas de protección y constancias de remisión pertinente.",
        "Información inicial de riesgo, información de riesgo y constancias de remisión pertinente, con una constancia escrita de las razones utilizadas para orientar la actuación institucional."
      ],
      "correct": 1,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de activar protección y autoridades competentes cuando proceda, con atención institucional sin sustituir instancias externas.",
      "distractors": "A. Esta selección es parcial: no integra medidas de protección, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra medidas de protección, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 182,
      "originalId": 42,
      "sourceExam": 2,
      "situationId": "S2-12",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referencia normativa conviene revisar primero por su relación directa con el caso?",
      "options": [
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes",
        "Ley 1620 de 2013 y sus rutas institucionales",
        "Decreto 1421 de 2017, educación inclusiva y PIAR"
      ],
      "correct": 1,
      "explanation": "Este marco se relaciona de modo más directo con la protección de derechos, los procedimientos y la reserva de información. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nC. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 183,
      "originalId": 43,
      "sourceExam": 2,
      "situationId": "S2-12",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál propuesta es jurídicamente y pedagógicamente más defendible?",
      "options": [
        "Activar protección y autoridades competentes cuando proceda, con atención institucional sin sustituir instancias externas.",
        "Iniciar diálogo restaurativo entre las partes y escalar después la situación si el acuerdo fracasa o aparecen nuevas señales; con referencia explícita al contexto escolar particular que originó la controversia.",
        "Remitir el caso únicamente al comité de convivencia para que defina si amerita activar una autoridad externa."
      ],
      "correct": 0,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la protección de derechos, los procedimientos y la reserva de información.",
      "distractors": "B. Aunque identifica una salida posible, omite una condición sustantiva para la protección de derechos, los procedimientos y la reserva de información.\n\nC. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 184,
      "originalId": 44,
      "sourceExam": 2,
      "situationId": "S2-13",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se audita la documentación propuesta, ¿qué expediente exigiría la mayor subsanación?",
      "options": [
        "Convenio ofrecido, inventario, licencias, costos futuros y alternativas técnicas, junto con la constancia de revisión de las condiciones informadas por los responsables.",
        "Expediente contrastado de donación con costo oculto: convenio ofrecido, inventario, licencias, costos futuros y alternativas técnicas, con índice y control de versiones.",
        "Convenio ofrecido, convenio de origen, licencias, costos futuros y alternativas técnicas."
      ],
      "correct": 2,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de evaluar costo total y sostenibilidad, tramitar autorizaciones y decidir con publicidad y análisis técnico.\n\nB. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 185,
      "originalId": 45,
      "sourceExam": 2,
      "situationId": "S2-13",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál de las medidas planteadas podría producir una actuación institucional objetable por su alcance o secuencia?",
      "options": [
        "Evaluar costo total y sostenibilidad, tramitar autorizaciones y decidir con publicidad y análisis técnico.",
        "Aceptar la dotación y reservar recursos futuros para las licencias, condicionando la renovación a resultados del primer año; y presentar una explicación de su alcance ante los integrantes del órgano correspondiente.",
        "Examinar los soportes asociados a donación con costo oculto, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables."
      ],
      "correct": 1,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la autorización presupuestal, el control y la destinación de recursos públicos.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la autorización presupuestal, el control y la destinación de recursos públicos.\n\nC. La alternativa preserva un examen previo y fundamentado de donación con costo oculto antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 186,
      "originalId": 46,
      "sourceExam": 2,
      "situationId": "S2-13",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Para revisar el avance dentro de un período comparable, ¿qué indicador tiene mayor pertinencia?",
      "options": [
        "Pagos que cumplen condiciones pactadas y respaldos de ejecución, durante la fase de evaluación definida en el cronograma de gestión de la institución.",
        "Costo total por estudiante beneficiado y continuidad efectiva del recurso.",
        "Procesos ejecutados conforme a cuantías reales y reglas de publicidad, en el marco de la discusión sostenida con quienes participaron en la reunión preparatoria."
      ],
      "correct": 1,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir costo total por estudiante beneficiado, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir costo total por estudiante beneficiado, componente esencial del resultado propuesto.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 187,
      "originalId": 47,
      "sourceExam": 2,
      "situationId": "S2-14",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué indicador tendría menor validez para establecer si se resolvió la necesidad institucional descrita?",
      "options": [
        "Secuencias interculturales implementadas con participación y aprendizajes pertinentes.",
        "Seguimiento desagregado por período y población de: secuencias interculturales implementadas con participación y aprendizajes pertinentes, según el informe preparado por la coordinación responsable de revisar la propuesta.",
        "Apoyos recibidos sin explotación publicitaria de datos de estudiantes, con una descripción de las condiciones que la rectoría consideró relevantes en este supuesto."
      ],
      "correct": 2,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.\n\nB. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 188,
      "originalId": 48,
      "sourceExam": 2,
      "situationId": "S2-14",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referente delimita de forma más directa las responsabilidades institucionales involucradas?",
      "options": [
        "Ley 115 de 1994, arts. 142-145",
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes",
        "Decreto 459 de 2024, Alianza Familias-Escuela"
      ],
      "correct": 2,
      "explanation": "Este marco se relaciona de modo más directo con la participación significativa, la accesibilidad y el diálogo territorial. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nB. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 189,
      "originalId": 49,
      "sourceExam": 2,
      "situationId": "S2-14",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué conjunto de evidencias permitiría sustentar de manera más sólida la decisión?",
      "options": [
        "Aportes de comunidad, datos de desempeño, acuerdos y evidencias pedagógicas.",
        "Aportes de comunidad, planes de área, acuerdos y evidencias pedagógicas, con registro de las decisiones tomadas durante el período de atención del asunto.",
        "Aportes de comunidad, planes de área, riesgos de exposición y evidencias pedagógicas."
      ],
      "correct": 1,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de concertar con respeto a derechos, pertinencia cultural y referentes curriculares, mediante espacios representativos.",
      "distractors": "A. Esta selección es parcial: no integra planes de área, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra acuerdos, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 190,
      "originalId": 50,
      "sourceExam": 2,
      "situationId": "S2-14",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué iniciativa sería más difícil de justificar si se confronta con las obligaciones rectorales pertinentes?",
      "options": [
        "Incorporar saberes mediante una unidad aislada y consultar a la comunidad al evaluar resultados del proyecto.",
        "Examinar los soportes asociados a escuela y cabildo indígena, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Concertar con respeto a derechos, pertinencia cultural y referentes curriculares, mediante espacios representativos."
      ],
      "correct": 0,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la participación significativa, la accesibilidad y el diálogo territorial.",
      "distractors": "B. La alternativa preserva un examen previo y fundamentado de escuela y cabildo indígena antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nC. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la participación significativa, la accesibilidad y el diálogo territorial.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 191,
      "originalId": 51,
      "sourceExam": 2,
      "situationId": "S2-15",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué lectura del argumento realizaría la inferencia menos justificable a partir de las pruebas disponibles?",
      "options": [
        "La disponibilidad de equipos no demuestra dominio de competencias digitales.",
        "La afirmación relativa a confusión entre acceso y uso requiere una comprobación complementaria antes de generalizar el efecto.",
        "La cobertura material permite esperar aprendizajes digitales, aunque las diferencias de sede exigen seguimiento."
      ],
      "correct": 2,
      "explanation": "La alternativa extrapola o sustituye indebidamente la evidencia: convierte registro de actividades o ejemplos en demostración suficiente de impacto.",
      "distractors": "A. Esta alternativa se apoya en el argumento y sus límites: la lectura distingue lo sustentado por los datos de una conclusión que excede esa evidencia.\n\nB. Distingue evidencia inicial de un resultado concluyente y delimita el alcance del texto.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de lectura crítica"
    },
    {
      "id": 192,
      "originalId": 52,
      "sourceExam": 2,
      "situationId": "S2-15",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué crítica sería menos pertinente para señalar la debilidad inferencial central del texto?",
      "options": [
        "Inferir aprendizaje a partir de infraestructura disponible.",
        "Concluir que la muestra digital es representativa por incluir varias sedes.",
        "La extrapolación de datos no comparables a un resultado institucional sobre confusión entre acceso y uso."
      ],
      "correct": 1,
      "explanation": "La alternativa extrapola o sustituye indebidamente la evidencia: una definición institucional adicional no corrige la inferencia central.",
      "distractors": "A. Esta alternativa se apoya en el argumento y sus límites: el defecto señalado impide pasar con justificación suficiente de las premisas a la conclusión.\n\nC. La crítica se dirige a la inferencia y a la extensión de las conclusiones, no a cuestiones formales.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de lectura crítica"
    },
    {
      "id": 193,
      "originalId": 53,
      "sourceExam": 2,
      "situationId": "S2-15",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué fuente complementaria aportaría menos capacidad para contrastar la conclusión del documento?",
      "options": [
        "Registros alternativos y comparables sobre confusión entre acceso y uso, contrastados con las condiciones iniciales.",
        "Frecuencia y calidad del uso formativo junto con evaluación de desempeños.",
        "Actas de recibido de computadores y frecuencia de mantenimiento preventivo por sede."
      ],
      "correct": 2,
      "explanation": "La alternativa extrapola o sustituye indebidamente la evidencia: una ratificación del autor no aporta contraste independiente.",
      "distractors": "A. Los datos externos comparables permiten examinar la inferencia expuesta sin limitarse a ratificaciones de quien redactó el informe.\n\nB. Esta alternativa se apoya en el argumento y sus límites: la evidencia propuesta examina directamente el salto inferencial identificado en el texto.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de lectura crítica"
    },
    {
      "id": 194,
      "originalId": 54,
      "sourceExam": 2,
      "situationId": "S2-16",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué medida sería menos adecuada como indicador principal para rendir cuentas sobre el resultado específico del caso?",
      "options": [
        "Proporción de estudiantes que justifican inferencias y evalúan evidencias.",
        "Seguimiento desagregado por período y población de: proporción de estudiantes que justifican inferencias y evalúan evidencias.",
        "Logro de desempeños curriculares vinculados al proyecto por grado, para atender la solicitud presentada formalmente ante la dirección de la institución."
      ],
      "correct": 2,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.\n\nB. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 195,
      "originalId": 55,
      "sourceExam": 2,
      "situationId": "S2-16",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué selección de soportes dejaría el vacío probatorio más importante para justificar la decisión?",
      "options": [
        "Expediente contrastado de lectura mecánica en secundaria: respuestas abiertas, errores de inferencia, rúbricas y muestras de argumentación, con índice y control de versiones.",
        "Respuestas abiertas, errores de inferencia, rúbricas y muestras de argumentación.",
        "Respuestas abiertas, muestras de trabajo, rúbricas y muestras de argumentación, como parte de la respuesta elaborada tras la reunión del personal que participó en el análisis, en el marco de la discusión sostenida con quienes participaron en la reunión preparatoria."
      ],
      "correct": 2,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nB. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de implementar tareas de inferencia, contraste de evidencias y discusión argumentada con evaluación formativa.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 196,
      "originalId": 56,
      "sourceExam": 2,
      "situationId": "S2-16",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué propuesta presenta el riesgo institucional más grave, a pesar de sus aparentes ventajas operativas?",
      "options": [
        "Implementar tareas de inferencia, contraste de evidencias y discusión argumentada con evaluación formativa; con indicación del período al que se refiere la propuesta de actuación y sus consecuencias.",
        "Aumentar ejercicios de identificación de ideas centrales y reservar inferencias complejas para el ciclo final.",
        "Examinar los soportes asociados a lectura mecánica en secundaria, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables."
      ],
      "correct": 1,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la correspondencia entre objetivos curriculares, apoyos didácticos y aprendizaje.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la correspondencia entre objetivos curriculares, apoyos didácticos y aprendizaje.\n\nC. La alternativa preserva un examen previo y fundamentado de lectura mecánica en secundaria antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 197,
      "originalId": 57,
      "sourceExam": 2,
      "situationId": "S2-17",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál evidencia de resultado permitiría una evaluación menos sesgada?",
      "options": [
        "Pagos que cumplen condiciones pactadas y respaldos de ejecución.",
        "Procesos ejecutados conforme a cuantías reales y reglas de publicidad.",
        "Costo total por estudiante beneficiado y continuidad efectiva del recurso."
      ],
      "correct": 1,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir procesos ejecutados conforme a cuantías reales, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir procesos ejecutados conforme a cuantías reales, componente esencial del resultado propuesto.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 198,
      "originalId": 58,
      "sourceExam": 2,
      "situationId": "S2-17",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué disposición es el punto de partida más específico para analizar la actuación?",
      "options": [
        "Ley 715 de 2001, art. 10, funciones del rector",
        "Decreto 1075 de 2015, sección del Fondo de Servicios Educativos",
        "Ley 115 de 1994, arts. 142-145"
      ],
      "correct": 1,
      "explanation": "Este marco se relaciona de modo más directo con la autorización presupuestal, el control y la destinación de recursos públicos. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nC. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 199,
      "originalId": 59,
      "sourceExam": 2,
      "situationId": "S2-17",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si la rectoría debe tomar una decisión inicial motivada, ¿cuál opción es preferible?",
      "options": [
        "Tramitar las tres adquisiciones como procesos independientes y documentar que los bienes corresponden a aulas distintas.",
        "Ejecutar las entregas escalonadas y consolidar el valor contractual solo en el informe de ejecución de cierre.",
        "Determinar cuantía y unidad contractual real, aplicar el régimen procedente y documentar la selección; con un resumen de los antecedentes que motivaron la convocatoria de los participantes."
      ],
      "correct": 2,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la autorización presupuestal, el control y la destinación de recursos públicos.",
      "distractors": "A. Aunque identifica una salida posible, omite una condición sustantiva para la autorización presupuestal, el control y la destinación de recursos públicos.\n\nB. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 200,
      "originalId": 60,
      "sourceExam": 2,
      "situationId": "S2-17",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "En una revisión externa, ¿qué evidencia permitiría reconstruir con mayor rigor lo ocurrido?",
      "options": [
        "Necesidad consolidada, flujo de caja, valor agregado y reglamento contractual.",
        "Necesidad consolidada, estudio de mercado, valor agregado y reglamento contractual.",
        "Necesidad consolidada, estudio de mercado, actas de recibo y reglamento contractual, y presentar una explicación de su alcance ante los integrantes del órgano correspondiente."
      ],
      "correct": 1,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de determinar cuantía y unidad contractual real, aplicar el régimen procedente y documentar la selección.",
      "distractors": "A. Esta selección es parcial: no integra estudio de mercado, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra valor agregado, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 201,
      "originalId": 61,
      "sourceExam": 2,
      "situationId": "S2-18",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué fuentes deberían triangularse para reducir el riesgo de una conclusión apresurada?",
      "options": [
        "Barreras de aula, apoyos disponibles, oportunidades de profundización y oportunidades pedagógicas.",
        "Barreras de aula, apoyos disponibles, participación y oportunidades pedagógicas, en el marco de la discusión sostenida con quienes participaron en la reunión preparatoria.",
        "Barreras de aula, barreras de acceso, participación y oportunidades pedagógicas."
      ],
      "correct": 1,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de organizar apoyos y ajustes en entornos educativos inclusivos, evitando segregación injustificada.",
      "distractors": "A. Esta selección es parcial: no integra participación, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra apoyos disponibles, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Decreto 1421 de 2017, incorporado al Decreto 1075 de 2015"
    },
    {
      "id": 202,
      "originalId": 62,
      "sourceExam": 2,
      "situationId": "S2-18",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál de las medidas planteadas podría producir una actuación institucional objetable por su alcance o secuencia?",
      "options": [
        "Organizar un grupo transitorio separado mientras se definen apoyos, conservándolo hasta que aumente el rendimiento promedio; con una comunicación dirigida a los actores mencionados en el expediente institucional.",
        "Examinar los soportes asociados a aula segregada por comodidad, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables; junto con la constancia de revisión de las condiciones informadas por los responsables.",
        "Organizar apoyos y ajustes en entornos educativos inclusivos, evitando segregación injustificada, con acompañamiento de coordinación para informar los cambios realizados."
      ],
      "correct": 0,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para el retiro de barreras y la participación educativa en igualdad de condiciones.",
      "distractors": "B. La alternativa preserva un examen previo y fundamentado de aula segregada por comodidad antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nC. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta el retiro de barreras y la participación educativa en igualdad de condiciones.",
      "legalBasis": "Decreto 1421 de 2017, incorporado al Decreto 1075 de 2015"
    },
    {
      "id": 203,
      "originalId": 63,
      "sourceExam": 2,
      "situationId": "S2-18",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué medida permitiría valorar el resultado de la intervención sin confundir actividad con impacto?",
      "options": [
        "Participación y cumplimiento del calendario de gestión.",
        "Participación y aprendizaje compartidos en ambientes regulares con apoyos pertinentes.",
        "Cumplimiento de metas individualizadas con ajustes efectivamente implementados."
      ],
      "correct": 1,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir aprendizaje compartidos en ambientes regulares con apoyos pertinentes, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir participación, componente esencial del resultado propuesto.",
      "legalBasis": "Decreto 1421 de 2017, incorporado al Decreto 1075 de 2015"
    },
    {
      "id": 204,
      "originalId": 64,
      "sourceExam": 2,
      "situationId": "S2-18",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referente delimita de forma más directa las responsabilidades institucionales involucradas?",
      "options": [
        "Ley 1620 de 2013 y sus rutas institucionales",
        "Decreto 1421 de 2017, educación inclusiva y PIAR",
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes"
      ],
      "correct": 1,
      "explanation": "Este marco se relaciona de modo más directo con el retiro de barreras y la participación educativa en igualdad de condiciones. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nC. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Decreto 1421 de 2017, incorporado al Decreto 1075 de 2015"
    },
    {
      "id": 205,
      "originalId": 65,
      "sourceExam": 2,
      "situationId": "S2-19",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál formulación introduce la limitación más importante al evaluar el resultado y no solo la gestión?",
      "options": [
        "Oportunidad de respuesta y continuidad de apoyos sin revictimización.",
        "Atención oportuna, protección y seguimiento de situaciones sin exposición de datos.",
        "Seguimiento desagregado por período y población de: atención oportuna, protección y seguimiento de situaciones sin exposición de datos."
      ],
      "correct": 0,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "B. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.\n\nC. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 206,
      "originalId": 66,
      "sourceExam": 2,
      "situationId": "S2-19",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué expediente sería más útil para motivar y posteriormente examinar la actuación?",
      "options": [
        "Relato protegido, capturas custodiadas, información de riesgo y registro de activación de ruta, con indicación del período al que se refiere la propuesta de actuación y sus consecuencias.",
        "Relato protegido, naturaleza de datos, antecedentes y registro de activación de ruta.",
        "Relato protegido, capturas custodiadas, antecedentes y registro de activación de ruta, en el marco de la discusión sostenida con quienes participaron en la reunión preparatoria."
      ],
      "correct": 2,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de proteger la intimidad, documentar hechos, activar la ruta pertinente y evitar revictimización.",
      "distractors": "A. Esta selección es parcial: no integra antecedentes, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nB. Esta selección es parcial: no integra capturas custodiadas, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 207,
      "originalId": 67,
      "sourceExam": 2,
      "situationId": "S2-19",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué respuesta preserva mejor las garantías comprometidas en el caso?",
      "options": [
        "Proteger la intimidad, documentar hechos, activar la ruta pertinente y evitar revictimización; para que el equipo responsable conozca los efectos esperados y los pasos anunciados.",
        "Compartir versiones editadas en el grupo del grado y solicitar que quienes reconozcan detalles informen a coordinación.",
        "Presentar capturas en una reunión cerrada de familias para identificar el origen del hostigamiento con mayor rapidez."
      ],
      "correct": 0,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la protección de derechos, los procedimientos y la reserva de información.",
      "distractors": "B. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.\n\nC. Aunque identifica una salida posible, omite una condición sustantiva para la protección de derechos, los procedimientos y la reserva de información.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 208,
      "originalId": 68,
      "sourceExam": 2,
      "situationId": "S2-20",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál criterio de seguimiento refleja mejor el problema que se pretende corregir?",
      "options": [
        "Diferencias de aprendizaje y participación entre modalidades de acceso.",
        "Publicaciones conformes a reglas de protección y sin exposición innecesaria.",
        "Registros únicos consistentes con matrículas efectivamente activas."
      ],
      "correct": 1,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir publicaciones conformes a reglas de protección, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir publicaciones conformes a reglas de protección, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 209,
      "originalId": 69,
      "sourceExam": 2,
      "situationId": "S2-20",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referencia normativa conviene revisar primero por su relación directa con el caso?",
      "options": [
        "Ley 1581 de 2012, tratamiento y protección de datos personales",
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes",
        "Decreto 459 de 2024, Alianza Familias-Escuela"
      ],
      "correct": 0,
      "explanation": "Este marco se relaciona de modo más directo con la finalidad legítima, la calidad de datos y los controles de acceso. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "B. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nC. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 210,
      "originalId": 70,
      "sourceExam": 2,
      "situationId": "S2-20",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué conjunto de evidencias permitiría sustentar de manera más sólida la decisión?",
      "options": [
        "Finalidad de publicación, mapa de cámaras, audiencia, riesgos y repositorio de imágenes.",
        "Finalidad de publicación, autorizaciones, audiencia, riesgos y repositorio de imágenes, durante la fase de evaluación definida en el cronograma de gestión de la institución.",
        "Finalidad de publicación, autorizaciones, audiencia, registro de acceso y repositorio de imágenes, como parte de la respuesta elaborada tras la reunión del personal que participó en el análisis."
      ],
      "correct": 1,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de revisar base y finalidad del tratamiento, minimizar exposición y establecer protocolos de publicación.",
      "distractors": "A. Esta selección es parcial: no integra autorizaciones, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra riesgos, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 211,
      "originalId": 71,
      "sourceExam": 2,
      "situationId": "S2-20",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál propuesta es jurídicamente y pedagógicamente más defendible?",
      "options": [
        "Mantener publicaciones en cuentas institucionales con acceso restringido y solicitar autorizaciones cuando alguien presente oposición.",
        "Retirar etiquetas nominales y continuar difundiendo rostros reconocibles sin establecer previamente finalidades y bases de tratamiento; con indicación del período al que se refiere la propuesta de actuación y sus consecuencias.",
        "Revisar base y finalidad del tratamiento, minimizar exposición y establecer protocolos de publicación; en el marco de la discusión sostenida con quienes participaron en la reunión preparatoria."
      ],
      "correct": 2,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la finalidad legítima, la calidad de datos y los controles de acceso.",
      "distractors": "A. Aunque identifica una salida posible, omite una condición sustantiva para la finalidad legítima, la calidad de datos y los controles de acceso.\n\nB. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 212,
      "originalId": 72,
      "sourceExam": 2,
      "situationId": "S2-21",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué propuesta presenta el riesgo institucional más grave, a pesar de sus aparentes ventajas operativas?",
      "options": [
        "Documentar incumplimientos y riesgos, coordinar medidas de continuidad y reportar a autoridad responsable del programa, después de revisar el calendario de trabajo de cada coordinación.",
        "Examinar los soportes asociados a programa alimentario interrumpido, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Organizar un suministro alterno por contratación directa de la escuela y notificar después a la entidad administradora; junto con la constancia de revisión de las condiciones informadas por los responsables."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la garantía del derecho a la educación y la articulación de protección.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la garantía del derecho a la educación y la articulación de protección.\n\nB. La alternativa preserva un examen previo y fundamentado de programa alimentario interrumpido antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 213,
      "originalId": 73,
      "sourceExam": 2,
      "situationId": "S2-21",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Antes de cerrar el análisis, ¿qué información resulta más decisiva para contrastar las afirmaciones?",
      "options": [
        "Informes de entrega, orientaciones de la entidad territorial, población atendida, comunicaciones con operador y entidad responsable.",
        "Informes de entrega, calidad, población atendida, patrón de ausencias y entidad responsable.",
        "Informes de entrega, calidad, población atendida y comunicaciones con operador y entidad responsable."
      ],
      "correct": 2,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de documentar incumplimientos y riesgos, coordinar medidas de continuidad y reportar a autoridad responsable del programa.",
      "distractors": "A. Esta selección es parcial: no integra calidad, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nB. Esta selección es parcial: no integra comunicaciones con operador, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 214,
      "originalId": 74,
      "sourceExam": 2,
      "situationId": "S2-21",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cómo debería operacionalizarse el resultado esperado en el plan de seguimiento?",
      "options": [
        "Continuidad de trayectoria con decisiones de traslado documentadas y justificadas, con una secuencia de comunicación posterior para facilitar el seguimiento de sus efectos.",
        "Raciones seguras efectivamente servidas y días de interrupción atendidos, y presentar una explicación de su alcance ante los integrantes del órgano correspondiente.",
        "Protección activada oportunamente y seguimiento articulado sin revictimización."
      ],
      "correct": 1,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir raciones seguras efectivamente servidas, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir raciones seguras efectivamente servidas, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 215,
      "originalId": 75,
      "sourceExam": 2,
      "situationId": "S2-22",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referente delimita de forma más directa las responsabilidades institucionales involucradas?",
      "options": [
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes",
        "Decreto 459 de 2024, Alianza Familias-Escuela",
        "Ley 1581 de 2012, tratamiento y protección de datos personales"
      ],
      "correct": 2,
      "explanation": "Este marco se relaciona de modo más directo con la finalidad legítima, la calidad de datos y los controles de acceso. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nB. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 216,
      "originalId": 76,
      "sourceExam": 2,
      "situationId": "S2-22",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué observación sería más informativa al rendir cuentas sobre este caso?",
      "options": [
        "Incidentes contenidos, alcance de exposición y remediaciones verificables, con una secuencia de comunicación posterior para facilitar el seguimiento de sus efectos.",
        "Registros únicos consistentes con matrículas efectivamente activas.",
        "Diferencias de aprendizaje y participación entre modalidades de acceso."
      ],
      "correct": 0,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "B. Considera una variable relacionada con el caso, pero deja sin medir incidentes contenidos, alcance de exposición, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir incidentes contenidos, alcance de exposición, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 217,
      "originalId": 77,
      "sourceExam": 2,
      "situationId": "S2-22",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué soportes documentales aportan el mejor fundamento para la actuación institucional?",
      "options": [
        "Destinatarios, encuesta de acceso, registro de acceso y medidas de contención, bajo una programación conocida por los integrantes responsables de examinar los resultados.",
        "Destinatarios, permisos, registro de acceso y medidas de contención, con anotación de las circunstancias específicas del establecimiento en la fecha de la decisión.",
        "Destinatarios, permisos, controles de acceso y medidas de contención."
      ],
      "correct": 1,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de contener exposición, activar protocolo institucional y evaluar comunicaciones y medidas pertinentes.",
      "distractors": "A. Esta selección es parcial: no integra permisos, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra registro de acceso, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 218,
      "originalId": 78,
      "sourceExam": 2,
      "situationId": "S2-22",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se comparan tres rutas de decisión, ¿cuál resultaría menos defendible ante una revisión de competencias y garantías?",
      "options": [
        "Examinar los soportes asociados a filtración de resultados, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Contener exposición, activar protocolo institucional y evaluar comunicaciones y medidas pertinentes.",
        "Enviar un mensaje de rectificación a destinatarios y registrar el incidente como cerrado cuando confirmen recepción; con una comunicación dirigida a los actores mencionados en el expediente institucional."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la finalidad legítima, la calidad de datos y los controles de acceso.",
      "distractors": "A. La alternativa preserva un examen previo y fundamentado de filtración de resultados antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nB. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la finalidad legítima, la calidad de datos y los controles de acceso.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 219,
      "originalId": 79,
      "sourceExam": 2,
      "situationId": "S2-23",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Para orientar la motivación jurídica inicial, ¿qué marco ofrece la conexión más pertinente con los hechos?",
      "options": [
        "Ley 115 de 1994, objetivos, áreas y proyectos educativos",
        "Resolución MEN 003842 de 2022, gestión académica",
        "Decreto 1290 de 2009, art. 11"
      ],
      "correct": 0,
      "explanation": "Este marco se relaciona de modo más directo con la integralidad curricular y la función pedagógica institucional. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "B. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nC. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 220,
      "originalId": 80,
      "sourceExam": 2,
      "situationId": "S2-23",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué combinación de documentos sería la menos adecuada para examinar las condiciones del supuesto?",
      "options": [
        "Horas perdidas, planes de área y competencias de educación física, bajo una programación conocida por los integrantes responsables de examinar los resultados.",
        "Expediente contrastado de educación física suspendida por lluvia: horas perdidas, infraestructura cubierta y competencias de educación física, con índice y control de versiones.",
        "Horas perdidas, infraestructura cubierta y competencias de educación física."
      ],
      "correct": 0,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "B. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nC. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de planear alternativas seguras y pedagógicamente equivalentes dentro del espacio disponible, con seguimiento curricular.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 221,
      "originalId": 81,
      "sourceExam": 2,
      "situationId": "S2-23",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál evidencia de resultado permitiría una evaluación menos sesgada?",
      "options": [
        "Capacidad de deliberación y seguimiento de acuerdos en ejercicios formativos.",
        "Proyectos autorizados con salvaguardas y aprovechamiento pedagógico definido.",
        "Horas efectivas y desempeños logrados con alternativas de enseñanza."
      ],
      "correct": 2,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir horas efectivas, componente esencial del resultado propuesto.\n\nB. Considera una variable relacionada con el caso, pero deja sin medir horas efectivas, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 222,
      "originalId": 82,
      "sourceExam": 2,
      "situationId": "S2-23",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál de las medidas planteadas podría producir una actuación institucional objetable por su alcance o secuencia?",
      "options": [
        "Reprogramar sesiones deportivas para el final del año y conservar horas ordinarias sin experiencia formativa equivalente.",
        "Examinar los soportes asociados a educación física suspendida por lluvia, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Planear alternativas seguras y pedagógicamente equivalentes dentro del espacio disponible, con seguimiento curricular, previa evaluación de viabilidad por el grupo directivo de la institución."
      ],
      "correct": 0,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la integralidad curricular y la función pedagógica institucional.",
      "distractors": "B. La alternativa preserva un examen previo y fundamentado de educación física suspendida por lluvia antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nC. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la integralidad curricular y la función pedagógica institucional.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 223,
      "originalId": 83,
      "sourceExam": 2,
      "situationId": "S2-24",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué crítica sería menos pertinente para señalar la debilidad inferencial central del texto?",
      "options": [
        "Generalización desde un agregado que oculta heterogeneidad territorial.",
        "Confusión entre una variación de tasa y una razón de crecimiento relativo, como parte de una decisión comunicada a los equipos que resultarían directamente involucrados.",
        "La extrapolación de datos no comparables a un resultado institucional sobre dato agregado y brecha."
      ],
      "correct": 1,
      "explanation": "La alternativa extrapola o sustituye indebidamente la evidencia: una definición institucional adicional no corrige la inferencia central.",
      "distractors": "A. Esta alternativa se apoya en el argumento y sus límites: el defecto señalado impide pasar con justificación suficiente de las premisas a la conclusión.\n\nC. La crítica se dirige a la inferencia y a la extensión de las conclusiones, no a cuestiones formales.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de lectura crítica"
    },
    {
      "id": 224,
      "originalId": 84,
      "sourceExam": 2,
      "situationId": "S2-24",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué lectura del argumento realizaría la inferencia menos justificable a partir de las pruebas disponibles?",
      "options": [
        "El 85 % respalda una conclusión general favorable, aunque las sedes rurales deban recibir atención focalizada, como parte de una decisión comunicada a los equipos que resultarían directamente involucrados.",
        "El promedio institucional puede ocultar desigualdades importantes entre sedes.",
        "La afirmación relativa a dato agregado y brecha requiere una comprobación complementaria antes de generalizar el efecto."
      ],
      "correct": 0,
      "explanation": "La alternativa extrapola o sustituye indebidamente la evidencia: convierte registro de actividades o ejemplos en demostración suficiente de impacto.",
      "distractors": "B. Esta alternativa se apoya en el argumento y sus límites: la lectura distingue lo sustentado por los datos de una conclusión que excede esa evidencia.\n\nC. Distingue evidencia inicial de un resultado concluyente y delimita el alcance del texto.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de lectura crítica"
    },
    {
      "id": 225,
      "originalId": 85,
      "sourceExam": 2,
      "situationId": "S2-24",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué fuente complementaria aportaría menos capacidad para contrastar la conclusión del documento?",
      "options": [
        "Promedio general de asistencia y percepción de docentes de la sede urbana, como parte de una decisión comunicada a los equipos que resultarían directamente involucrados.",
        "Denominadores, series de asistencia y barreras de cada sede.",
        "Registros alternativos y comparables sobre dato agregado y brecha, contrastados con las condiciones iniciales."
      ],
      "correct": 0,
      "explanation": "La alternativa extrapola o sustituye indebidamente la evidencia: una ratificación del autor no aporta contraste independiente.",
      "distractors": "B. Esta alternativa se apoya en el argumento y sus límites: la evidencia propuesta examina directamente el salto inferencial identificado en el texto.\n\nC. Los datos externos comparables permiten examinar la inferencia expuesta sin limitarse a ratificaciones de quien redactó el informe.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de lectura crítica"
    },
    {
      "id": 226,
      "originalId": 86,
      "sourceExam": 2,
      "situationId": "S2-25",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Manteniendo lo demás constante, ¿aproximadamente qué avance en lectura alcanzaría un global de 80?",
      "options": [
        "76,67 puntos",
        "70 puntos",
        "73,33 puntos"
      ],
      "correct": 2,
      "explanation": "40 + 0,30×x + 18 = 80; x = 22/0,30 = 73,333... puntos.",
      "distractors": "A. Confunde una magnitud con otra o realiza una agregación que altera la base de comparación.\n\nB. Corresponde a una operación o denominador distinto del definido; no coincide con los datos.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de razonamiento cuantitativo"
    },
    {
      "id": 227,
      "originalId": 87,
      "sourceExam": 2,
      "situationId": "S2-25",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál es el cumplimiento global ponderado?",
      "options": [
        "80 puntos",
        "76 puntos",
        "76,67 puntos"
      ],
      "correct": 1,
      "explanation": "0,50×80 + 0,30×60 + 0,20×90 = 40 + 18 + 18 = 76.",
      "distractors": "A. Confunde una magnitud con otra o realiza una agregación que altera la base de comparación.\n\nC. Corresponde a una operación o denominador distinto del definido; no coincide con los datos.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de razonamiento cuantitativo"
    },
    {
      "id": 228,
      "originalId": 88,
      "sourceExam": 2,
      "situationId": "S2-25",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si lectura aumenta de 60 a 70 y los demás avances permanecen, ¿cuál es el nuevo resultado ponderado?",
      "options": [
        "80 puntos",
        "86 puntos",
        "79 puntos"
      ],
      "correct": 2,
      "explanation": "El aumento en lectura aporta 0,30×10 = 3 puntos globales; pasa de 76 a 79.",
      "distractors": "A. Confunde una magnitud con otra o realiza una agregación que altera la base de comparación.\n\nB. Corresponde a una operación o denominador distinto del definido; no coincide con los datos.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de razonamiento cuantitativo"
    },
    {
      "id": 229,
      "originalId": 89,
      "sourceExam": 2,
      "situationId": "S2-26",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué conjunto de evidencias permitiría sustentar de manera más sólida la decisión?",
      "options": [
        "Versiones, metadatos, instrucciones recibidas y ruta de reporte disponible, con una secuencia de comunicación posterior para facilitar el seguimiento de sus efectos.",
        "Versiones, entrega de llaves, instrucciones recibidas y ruta de reporte disponible.",
        "Versiones, metadatos, partes de atención y ruta de reporte disponible."
      ],
      "correct": 0,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de negarse a alterar registros, conservar evidencia y usar canales institucionales de reporte.",
      "distractors": "B. Esta selección es parcial: no integra metadatos, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra instrucciones recibidas, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 230,
      "originalId": 90,
      "sourceExam": 2,
      "situationId": "S2-26",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué propuesta presenta el riesgo institucional más grave, a pesar de sus aparentes ventajas operativas?",
      "options": [
        "Examinar los soportes asociados a orden verbal improcedente, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Realizar el ajuste solicitado como versión preliminar no publicada y requerir confirmación escrita antes del cierre del expediente; como parte de una decisión comunicada a los equipos que resultarían directamente involucrados.",
        "Negarse a alterar registros, conservar evidencia y usar canales institucionales de reporte, con un registro de compromisos para la siguiente reunión del Consejo."
      ],
      "correct": 1,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la probidad, el criterio directivo y la rendición de cuentas.",
      "distractors": "A. La alternativa preserva un examen previo y fundamentado de orden verbal improcedente antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nC. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la probidad, el criterio directivo y la rendición de cuentas.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 231,
      "originalId": 91,
      "sourceExam": 2,
      "situationId": "S2-26",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué indicador tendría menor validez para establecer si se resolvió la necesidad institucional descrita?",
      "options": [
        "Seguimiento desagregado por período y población de: integridad documental y trazabilidad de actuaciones frente a instrucciones improcedentes.",
        "Comunicaciones oportunas, precisas y respetuosas de privacidad.",
        "Integridad documental y trazabilidad de actuaciones frente a instrucciones improcedentes."
      ],
      "correct": 1,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.\n\nC. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 232,
      "originalId": 92,
      "sourceExam": 2,
      "situationId": "S2-27",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué combinación de documentos sería la menos adecuada para examinar las condiciones del supuesto?",
      "options": [
        "Relato, documentación, instancias competentes y medidas preventivas posibles.",
        "Expediente contrastado de acoso laboral denunciado: relato, documentación, instancias competentes y medidas preventivas posibles, con índice y control de versiones.",
        "Relato, actas, instancias competentes y medidas preventivas posibles."
      ],
      "correct": 2,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de proteger a la denunciante, canalizar por mecanismos competentes y mantener imparcialidad y reserva.\n\nB. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 233,
      "originalId": 93,
      "sourceExam": 2,
      "situationId": "S2-27",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se comparan tres rutas de decisión, ¿cuál resultaría menos defendible ante una revisión de competencias y garantías?",
      "options": [
        "Escuchar por separado a las partes y proponer un acuerdo privado que cierre la queja antes de acudir a instancias competentes; con una descripción de las condiciones que la rectoría consideró relevantes en este supuesto.",
        "Examinar los soportes asociados a acoso laboral denunciado, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Proteger a la denunciante, canalizar por mecanismos competentes y mantener imparcialidad y reserva, con una verificación posterior de costos y resultados administrativos."
      ],
      "correct": 0,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para las funciones del rector, la continuidad del servicio y las garantías del personal.",
      "distractors": "B. La alternativa preserva un examen previo y fundamentado de acoso laboral denunciado antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nC. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta las funciones del rector, la continuidad del servicio y las garantías del personal.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 234,
      "originalId": 94,
      "sourceExam": 2,
      "situationId": "S2-27",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cómo debería operacionalizarse el resultado esperado en el plan de seguimiento?",
      "options": [
        "Cumplimiento de fases y calidad de evidencias de evaluación.",
        "Protección frente a represalias y asistencia a reuniones.",
        "Quejas encauzadas con reserva, oportunidad y protección frente a represalias."
      ],
      "correct": 2,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir quejas encauzadas con reserva, oportunidad, componente esencial del resultado propuesto.\n\nB. Considera una variable relacionada con el caso, pero deja sin medir quejas encauzadas con reserva, oportunidad, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 235,
      "originalId": 95,
      "sourceExam": 2,
      "situationId": "S2-28",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referencia normativa conviene revisar primero por su relación directa con el caso?",
      "options": [
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes",
        "Ley 1581 de 2012, tratamiento y protección de datos personales",
        "Decreto 459 de 2024, Alianza Familias-Escuela"
      ],
      "correct": 1,
      "explanation": "Este marco se relaciona de modo más directo con la finalidad legítima, la calidad de datos y los controles de acceso. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nC. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 236,
      "originalId": 96,
      "sourceExam": 2,
      "situationId": "S2-28",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál propuesta es jurídicamente y pedagógicamente más defendible?",
      "options": [
        "Aplicar la plataforma obligatoria y ofrecer plazos ampliados a quienes compartan dispositivos móviles en el hogar.",
        "Garantizar alternativas pedagógicas equivalentes y medir brechas antes de imponer uso exclusivo; con indicación del período al que se refiere la propuesta de actuación y sus consecuencias.",
        "Permitir entregas impresas, pero evaluar su calidad con una escala distinta para reflejar las condiciones tecnológicas."
      ],
      "correct": 1,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la finalidad legítima, la calidad de datos y los controles de acceso.",
      "distractors": "A. Aunque identifica una salida posible, omite una condición sustantiva para la finalidad legítima, la calidad de datos y los controles de acceso.\n\nC. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 237,
      "originalId": 97,
      "sourceExam": 2,
      "situationId": "S2-28",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué soportes documentales aportan el mejor fundamento para la actuación institucional?",
      "options": [
        "Encuesta de acceso, recursos por sede y resultados por modalidad, con referencia explícita al contexto escolar particular que originó la controversia.",
        "Encuesta de acceso, mapa de cámaras y resultados por modalidad.",
        "Encuesta de acceso, resultados por subgrupo y resultados por modalidad."
      ],
      "correct": 0,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de garantizar alternativas pedagógicas equivalentes y medir brechas antes de imponer uso exclusivo.",
      "distractors": "B. Esta selección es parcial: no integra recursos por sede, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra recursos por sede, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 238,
      "originalId": 98,
      "sourceExam": 2,
      "situationId": "S2-28",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué observación sería más informativa al rendir cuentas sobre este caso?",
      "options": [
        "Diferencias de aprendizaje y participación entre modalidades de acceso, con un resumen de los antecedentes que motivaron la convocatoria de los participantes.",
        "Publicaciones conformes a reglas de protección y sin exposición innecesaria, con una secuencia de comunicación posterior para facilitar el seguimiento de sus efectos.",
        "Diferencias de aprendizaje y cumplimiento del calendario de gestión."
      ],
      "correct": 0,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "B. Considera una variable relacionada con el caso, pero deja sin medir diferencias de aprendizaje, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir participación entre modalidades de acceso, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 239,
      "originalId": 99,
      "sourceExam": 2,
      "situationId": "S2-29",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "En una revisión externa, ¿qué evidencia permitiría reconstruir con mayor rigor lo ocurrido?",
      "options": [
        "Reglamento, circunstancias del hecho, información de riesgo y participación de implicados.",
        "Reglamento, naturaleza de datos, elementos probatorios y participación de implicados.",
        "Reglamento, circunstancias del hecho, elementos probatorios y participación de implicados, durante la fase de evaluación definida en el cronograma de gestión de la institución."
      ],
      "correct": 2,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de individualizar actuaciones con debido proceso y utilizar respuestas formativas compatibles con derechos.",
      "distractors": "A. Esta selección es parcial: no integra elementos probatorios, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nB. Esta selección es parcial: no integra circunstancias del hecho, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 240,
      "originalId": 100,
      "sourceExam": 2,
      "situationId": "S2-29",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué decisión permite atender el problema sin crear uno adicional de competencia o procedimiento?",
      "options": [
        "Asignar una medida disciplinaria uniforme aprobada por el grupo y permitir apelación individual a quienes discrepen.",
        "Individualizar actuaciones con debido proceso y utilizar respuestas formativas compatibles con derechos; bajo una programación conocida por los integrantes responsables de examinar los resultados.",
        "Aplicar una reparación comunitaria obligatoria a todo el curso y abrir posteriormente verificación individual de responsabilidades; con un resumen de los antecedentes que motivaron la convocatoria de los participantes."
      ],
      "correct": 1,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la protección de derechos, los procedimientos y la reserva de información.",
      "distractors": "A. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.\n\nC. Aunque identifica una salida posible, omite una condición sustantiva para la protección de derechos, los procedimientos y la reserva de información.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 241,
      "originalId": 101,
      "sourceExam": 2,
      "situationId": "S2-29",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Entre las siguientes propuestas de seguimiento, ¿cuál deja una brecha de medición más relevante?",
      "options": [
        "Oportunidad de respuesta y continuidad de apoyos sin revictimización, con una constancia escrita de las razones utilizadas para orientar la actuación institucional.",
        "Actuaciones con individualización, garantías y medidas restaurativas pertinentes.",
        "Seguimiento desagregado por período y población de: actuaciones con individualización, garantías y medidas restaurativas pertinentes, con seguimiento documental del cambio anunciado en el proceso escolar de referencia."
      ],
      "correct": 0,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "B. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.\n\nC. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 242,
      "originalId": 102,
      "sourceExam": 2,
      "situationId": "S2-29",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué disposición es el punto de partida más específico para analizar la actuación?",
      "options": [
        "Decreto 1421 de 2017, educación inclusiva y PIAR",
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes",
        "Ley 1620 de 2013 y sus rutas institucionales"
      ],
      "correct": 2,
      "explanation": "Este marco se relaciona de modo más directo con la protección de derechos, los procedimientos y la reserva de información. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nB. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 243,
      "originalId": 103,
      "sourceExam": 2,
      "situationId": "S2-30",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué indicador tendría menor validez para establecer si se resolvió la necesidad institucional descrita?",
      "options": [
        "Seguimiento desagregado por período y población de: requerimientos gestionados por autoridad competente con respuesta y seguimiento.",
        "Requerimientos gestionados por autoridad competente con respuesta y seguimiento.",
        "Cupos asignados según reglas y sin pagos condicionantes."
      ],
      "correct": 2,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.\n\nB. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 244,
      "originalId": 104,
      "sourceExam": 2,
      "situationId": "S2-30",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "De las siguientes actuaciones, ¿cuál requeriría una corrección prioritaria por comprometer el procedimiento o la garantía central del caso?",
      "options": [
        "Distinguir facultades institucionales de atribuciones de la entidad territorial y gestionar solicitudes justificadas.",
        "Anunciar la provisión de cargos como compromiso de rectoría y gestionar después ante la Secretaría las autorizaciones pertinentes; con una descripción de las condiciones que la rectoría consideró relevantes en este supuesto.",
        "Examinar los soportes asociados a promesa fuera de competencia, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables."
      ],
      "correct": 1,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la probidad, el criterio directivo y la rendición de cuentas.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la probidad, el criterio directivo y la rendición de cuentas.\n\nC. La alternativa preserva un examen previo y fundamentado de promesa fuera de competencia antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 245,
      "originalId": 105,
      "sourceExam": 2,
      "situationId": "S2-30",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué fuentes deberían triangularse para reducir el riesgo de una conclusión apresurada?",
      "options": [
        "Normas de competencias, entrega de llaves, necesidades y oficios radicados.",
        "Normas de competencias, planta autorizada, necesidades y oficios radicados, con referencia explícita al contexto escolar particular que originó la controversia.",
        "Normas de competencias, planta autorizada, partes de atención y oficios radicados, como parte de una decisión comunicada a los equipos que resultarían directamente involucrados."
      ],
      "correct": 1,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de distinguir facultades institucionales de atribuciones de la entidad territorial y gestionar solicitudes justificadas.",
      "distractors": "A. Esta selección es parcial: no integra planta autorizada, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra necesidades, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 246,
      "originalId": 106,
      "sourceExam": 2,
      "situationId": "S2-30",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referente delimita de forma más directa las responsabilidades institucionales involucradas?",
      "options": [
        "Ley 715 de 2001, art. 10, dirección y seguimiento institucional",
        "Ley 115 de 1994, arts. 142-145",
        "Ley 715 de 2001, art. 10, funciones del rector"
      ],
      "correct": 0,
      "explanation": "Este marco se relaciona de modo más directo con la probidad, el criterio directivo y la rendición de cuentas. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "B. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nC. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 247,
      "originalId": 107,
      "sourceExam": 2,
      "situationId": "S2-31",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué propuesta presenta el riesgo institucional más grave, a pesar de sus aparentes ventajas operativas?",
      "options": [
        "Comparar progreso con línea de base y diferencias relevantes antes de atribuir ventajas a la estrategia; con seguimiento documental del cambio anunciado en el proceso escolar de referencia.",
        "Examinar los soportes asociados a innovación sin comparación justa, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Adoptar el método con base en el promedio final e incorporar análisis de diferencias iniciales solo durante la expansión."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la correspondencia entre objetivos curriculares, apoyos didácticos y aprendizaje.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la correspondencia entre objetivos curriculares, apoyos didácticos y aprendizaje.\n\nB. La alternativa preserva un examen previo y fundamentado de innovación sin comparación justa antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 248,
      "originalId": 108,
      "sourceExam": 2,
      "situationId": "S2-31",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Para revisar el avance dentro de un período comparable, ¿qué indicador tiene mayor pertinencia?",
      "options": [
        "Progreso de aprendizaje por condición de acceso y sede.",
        "Logro de desempeños curriculares vinculados al proyecto por grado.",
        "Cambio de desempeño ajustado al punto de partida y condiciones comparables."
      ],
      "correct": 2,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir cambio de desempeño ajustado al punto de partida, componente esencial del resultado propuesto.\n\nB. Considera una variable relacionada con el caso, pero deja sin medir cambio de desempeño ajustado al punto de partida, componente esencial del resultado propuesto.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 249,
      "originalId": 109,
      "sourceExam": 2,
      "situationId": "S2-31",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Para orientar la motivación jurídica inicial, ¿qué marco ofrece la conexión más pertinente con los hechos?",
      "options": [
        "Resolución MEN 003842 de 2022, gestión académica",
        "Ley 115 de 1994, objetivos, áreas y proyectos educativos",
        "Decreto 1290 de 2009, art. 11"
      ],
      "correct": 0,
      "explanation": "Este marco se relaciona de modo más directo con la correspondencia entre objetivos curriculares, apoyos didácticos y aprendizaje. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "B. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nC. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 250,
      "originalId": 110,
      "sourceExam": 2,
      "situationId": "S2-31",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué expediente sería más útil para motivar y posteriormente examinar la actuación?",
      "options": [
        "Notas previas, asistencia, características de grupos y criterios de evaluación.",
        "Notas previas, asistencia, planes de área y criterios de evaluación, en el marco de la discusión sostenida con quienes participaron en la reunión preparatoria.",
        "Notas previas, evaluación de riesgos, características de grupos y criterios de evaluación."
      ],
      "correct": 0,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de comparar progreso con línea de base y diferencias relevantes antes de atribuir ventajas a la estrategia.",
      "distractors": "B. Esta selección es parcial: no integra características de grupos, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra asistencia, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 251,
      "originalId": 111,
      "sourceExam": 2,
      "situationId": "S2-32",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué conjunto de evidencias permitiría sustentar de manera más sólida la decisión?",
      "options": [
        "Radicado, criterios del SIEE, actuaciones, respuestas y normas del SIEE.",
        "Radicado, rúbricas, actuaciones, criterios del SIEE y normas del SIEE.",
        "Radicado, rúbricas, actuaciones, respuestas y normas del SIEE."
      ],
      "correct": 2,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de activar la ruta de reclamación del siee, motivar respuesta y registrar actuaciones y plazos.",
      "distractors": "A. Esta selección es parcial: no integra rúbricas, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nB. Esta selección es parcial: no integra respuestas, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 252,
      "originalId": 112,
      "sourceExam": 2,
      "situationId": "S2-32",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué medida sería menos adecuada como indicador principal para rendir cuentas sobre el resultado específico del caso?",
      "options": [
        "Familias que comprenden el avance y conocen acciones concretas de acompañamiento, con un resumen de los antecedentes que motivaron la convocatoria de los participantes.",
        "Seguimiento desagregado por período y población de: reclamaciones resueltas motivadamente en los plazos establecidos.",
        "Reclamaciones resueltas motivadamente en los plazos establecidos."
      ],
      "correct": 0,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "B. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.\n\nC. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 253,
      "originalId": 113,
      "sourceExam": 2,
      "situationId": "S2-32",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se comparan tres rutas de decisión, ¿cuál resultaría menos defendible ante una revisión de competencias y garantías?",
      "options": [
        "Activar la ruta de reclamación del SIEE, motivar respuesta y registrar actuaciones y plazos, con un cronograma de ejecución conocido por las instancias participantes.",
        "Examinar los soportes asociados a reclamación sin respuesta, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Pedir al docente una revisión informal y modificar la nota si ambas partes expresan conformidad por escrito; con registro de las decisiones tomadas durante el período de atención del asunto."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para las reglas del SIEE, los apoyos y la motivación de decisiones académicas.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta las reglas del SIEE, los apoyos y la motivación de decisiones académicas.\n\nB. La alternativa preserva un examen previo y fundamentado de reclamación sin respuesta antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 254,
      "originalId": 114,
      "sourceExam": 2,
      "situationId": "S2-33",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Antes de cerrar el análisis, ¿qué información resulta más decisiva para contrastar las afirmaciones?",
      "options": [
        "PMI, planes de área, actas de ciclos y productos de aula, con anotación de las circunstancias específicas del establecimiento en la fecha de la decisión.",
        "PMI, planes de área, matriz de acciones y productos de aula.",
        "PMI, actas de evaluación, actas de ciclos y productos de aula."
      ],
      "correct": 0,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de vincular compromisos del pmi con planeaciones pedagógicas, tiempos, responsables e instrumentos de evaluación.",
      "distractors": "B. Esta selección es parcial: no integra actas de ciclos, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra planes de área, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 255,
      "originalId": 115,
      "sourceExam": 2,
      "situationId": "S2-33",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Entre las siguientes propuestas de seguimiento, ¿cuál deja una brecha de medición más relevante?",
      "options": [
        "Seguimiento desagregado por período y población de: porcentaje de acciones de mejora implementadas y respaldadas por evidencias de aprendizaje.",
        "Avance de estudiantes entre niveles de competencia en períodos equivalentes, con indicación del período al que se refiere la propuesta de actuación y sus consecuencias.",
        "Porcentaje de acciones de mejora implementadas y respaldadas por evidencias de aprendizaje."
      ],
      "correct": 1,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.\n\nC. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 256,
      "originalId": 116,
      "sourceExam": 2,
      "situationId": "S2-33",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál de las medidas planteadas podría producir una actuación institucional objetable por su alcance o secuencia?",
      "options": [
        "Vincular compromisos del PMI con planeaciones pedagógicas, tiempos, responsables e instrumentos de evaluación, previa discusión con los representantes de las sedes involucradas.",
        "Examinar los soportes asociados a plan que no llega a aulas, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Incorporar informes de área al PMI y evaluar su calidad documental sin modificar todavía la planificación de las clases; y presentar una explicación de su alcance ante los integrantes del órgano correspondiente."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la coherencia entre diagnóstico, metas, ejecución y evidencia.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la coherencia entre diagnóstico, metas, ejecución y evidencia.\n\nB. La alternativa preserva un examen previo y fundamentado de plan que no llega a aulas antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 257,
      "originalId": 117,
      "sourceExam": 2,
      "situationId": "S2-34",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál conjunto documental permitiría una conclusión menos sólida sobre la actuación?",
      "options": [
        "Planeaciones, planes de área, situaciones de diálogo y rúbricas de convivencia.",
        "Expediente contrastado de cátedra de paz memorística: planeaciones, tareas, situaciones de diálogo y rúbricas de convivencia, con índice y control de versiones.",
        "Planeaciones, tareas, situaciones de diálogo y rúbricas de convivencia, con una comunicación dirigida a los actores mencionados en el expediente institucional."
      ],
      "correct": 0,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "B. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nC. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de articular saber conceptual con habilidades deliberativas, convivencia y evaluación de desempeños aplicados.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 258,
      "originalId": 118,
      "sourceExam": 2,
      "situationId": "S2-34",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cómo debería proceder la dirección del establecimiento en este escenario?",
      "options": [
        "Articular saber conceptual con habilidades deliberativas, convivencia y evaluación de desempeños aplicados; con una comunicación dirigida a los actores mencionados en el expediente institucional.",
        "Mantener conceptos y añadir debates informales, sin criterios compartidos para evaluar destrezas de resolución de conflictos; con una descripción de las condiciones que la rectoría consideró relevantes en este supuesto.",
        "Reemplazar evaluaciones por jornadas de convivencia y atribuir avances de ciudadanía al número de compromisos firmados."
      ],
      "correct": 0,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la integralidad curricular y la función pedagógica institucional.",
      "distractors": "B. Aunque identifica una salida posible, omite una condición sustantiva para la integralidad curricular y la función pedagógica institucional.\n\nC. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 259,
      "originalId": 119,
      "sourceExam": 2,
      "situationId": "S2-34",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referente delimita de forma más directa las responsabilidades institucionales involucradas?",
      "options": [
        "Resolución MEN 003842 de 2022, gestión académica",
        "Ley 115 de 1994, objetivos, áreas y proyectos educativos",
        "Decreto 1290 de 2009, art. 11"
      ],
      "correct": 1,
      "explanation": "Este marco se relaciona de modo más directo con la integralidad curricular y la función pedagógica institucional. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nC. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 260,
      "originalId": 120,
      "sourceExam": 2,
      "situationId": "S2-34",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué indicador tendría menor validez para establecer si se resolvió la necesidad institucional descrita?",
      "options": [
        "Progresión de desempeños comunicativos por ciclo y grado, para que el equipo responsable conozca los efectos esperados y los pasos anunciados.",
        "Capacidad de analizar dilemas y resolver conflictos en actividades formativas.",
        "Seguimiento desagregado por período y población de: capacidad de analizar dilemas y resolver conflictos en actividades formativas, con una comunicación dirigida a los actores mencionados en el expediente institucional."
      ],
      "correct": 0,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "B. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.\n\nC. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 261,
      "originalId": 121,
      "sourceExam": 2,
      "situationId": "S2-35",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "En una revisión externa, ¿qué evidencia permitiría reconstruir con mayor rigor lo ocurrido?",
      "options": [
        "Productos complejos, intereses, valoración pedagógica y oportunidades de profundización, con seguimiento documental del cambio anunciado en el proceso escolar de referencia.",
        "Productos complejos, barreras de aula, valoración pedagógica y oportunidades de profundización, como parte de una decisión comunicada a los equipos que resultarían directamente involucrados.",
        "Productos complejos, intereses, barreras de acceso y oportunidades de profundización."
      ],
      "correct": 0,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de acordar estrategias de profundización y enriquecimiento con valoración de intereses, sin aislarla.",
      "distractors": "B. Esta selección es parcial: no integra intereses, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra valoración pedagógica, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Decreto 1421 de 2017, incorporado al Decreto 1075 de 2015"
    },
    {
      "id": 262,
      "originalId": 122,
      "sourceExam": 2,
      "situationId": "S2-35",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál formulación introduce la limitación más importante al evaluar el resultado y no solo la gestión?",
      "options": [
        "Progreso en retos de mayor complejidad y participación sostenida, con referencia explícita al contexto escolar particular que originó la controversia.",
        "Seguimiento desagregado por período y población de: progreso en retos de mayor complejidad y participación sostenida.",
        "Cumplimiento de metas individualizadas con ajustes efectivamente implementados."
      ],
      "correct": 2,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.\n\nB. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.",
      "legalBasis": "Decreto 1421 de 2017, incorporado al Decreto 1075 de 2015"
    },
    {
      "id": 263,
      "originalId": 123,
      "sourceExam": 2,
      "situationId": "S2-35",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "De las siguientes actuaciones, ¿cuál requeriría una corrección prioritaria por comprometer el procedimiento o la garantía central del caso?",
      "options": [
        "Examinar los soportes asociados a talento excepcional y apoyos, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Acordar estrategias de profundización y enriquecimiento con valoración de intereses, sin aislarla, con participación de responsables de área para examinar su ejecución.",
        "Asignar materiales del grado siguiente sin valorar intereses ni necesidades de enriquecimiento y revisar después la respuesta; con anotación de las circunstancias específicas del establecimiento en la fecha de la decisión."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para el retiro de barreras y la participación educativa en igualdad de condiciones.",
      "distractors": "A. La alternativa preserva un examen previo y fundamentado de talento excepcional y apoyos antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nB. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta el retiro de barreras y la participación educativa en igualdad de condiciones.",
      "legalBasis": "Decreto 1421 de 2017, incorporado al Decreto 1075 de 2015"
    },
    {
      "id": 264,
      "originalId": 124,
      "sourceExam": 2,
      "situationId": "S2-36",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué fuentes deberían triangularse para reducir el riesgo de una conclusión apresurada?",
      "options": [
        "Convocatoria, postulaciones, reglas de representación y soportes de elección.",
        "Convocatoria, reglas de selección aplicables, reglas de representación y soportes de elección.",
        "Convocatoria, postulaciones, plan de compras y soportes de elección, con seguimiento documental del cambio anunciado en el proceso escolar de referencia."
      ],
      "correct": 0,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de aplicar las reglas de integración y elección del consejo, resolver la controversia mediante procedimiento transparente.",
      "distractors": "B. Esta selección es parcial: no integra postulaciones, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra reglas de representación, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Ley 715 de 2001, art. 10"
    },
    {
      "id": 265,
      "originalId": 125,
      "sourceExam": 2,
      "situationId": "S2-36",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referencia normativa conviene revisar primero por su relación directa con el caso?",
      "options": [
        "Ley 115 de 1994, arts. 142-145",
        "Ley 715 de 2001, art. 10, funciones del rector",
        "Ley 715 de 2001, art. 10"
      ],
      "correct": 0,
      "explanation": "Este marco se relaciona de modo más directo con el reparto de competencias y la participación válida del gobierno escolar. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "B. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nC. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Ley 715 de 2001, art. 10"
    },
    {
      "id": 266,
      "originalId": 126,
      "sourceExam": 2,
      "situationId": "S2-36",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué propuesta presenta el riesgo institucional más grave, a pesar de sus aparentes ventajas operativas?",
      "options": [
        "Examinar los soportes asociados a representación de egresados, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Aplicar las reglas de integración y elección del Consejo, resolver la controversia mediante procedimiento transparente, con un plan de divulgación de los acuerdos entre las partes.",
        "Invitar a los dos grupos a compartir temporalmente el asiento y definir después la titularidad mediante el reglamento; bajo una programación conocida por los integrantes responsables de examinar los resultados."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para el reparto de competencias y la participación válida del gobierno escolar.",
      "distractors": "A. La alternativa preserva un examen previo y fundamentado de representación de egresados antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nB. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta el reparto de competencias y la participación válida del gobierno escolar.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Ley 715 de 2001, art. 10"
    },
    {
      "id": 267,
      "originalId": 127,
      "sourceExam": 2,
      "situationId": "S2-36",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué medida permitiría valorar el resultado de la intervención sin confundir actividad con impacto?",
      "options": [
        "Proporción de acuerdos adoptados con soporte de quórum y seguimiento de ejecución, con registro de las decisiones tomadas durante el período de atención del asunto.",
        "Participación efectiva de representantes elegidos conforme al procedimiento institucional.",
        "Proporción de disposiciones revisadas con participación y compatibilidad con garantías de derechos."
      ],
      "correct": 1,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.\n\nC. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Ley 715 de 2001, art. 10"
    },
    {
      "id": 268,
      "originalId": 128,
      "sourceExam": 2,
      "situationId": "S2-37",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se comparan tres rutas de decisión, ¿cuál resultaría menos defendible ante una revisión de competencias y garantías?",
      "options": [
        "Utilizar la observación reciente como base de calificación y ofrecer una sesión de retroalimentación antes de publicar el resultado.",
        "Examinar los soportes asociados a evaluación de desempeño improvisada, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Aplicar proceso evaluativo pertinente con criterios conocidos, evidencias variadas y retroalimentación motivada; para que el equipo responsable conozca los efectos esperados y los pasos anunciados."
      ],
      "correct": 0,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para las funciones del rector, la continuidad del servicio y las garantías del personal.",
      "distractors": "B. La alternativa preserva un examen previo y fundamentado de evaluación de desempeño improvisada antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nC. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta las funciones del rector, la continuidad del servicio y las garantías del personal.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 269,
      "originalId": 129,
      "sourceExam": 2,
      "situationId": "S2-37",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué disposición es el punto de partida más específico para analizar la actuación?",
      "options": [
        "Ley 115 de 1994, arts. 142-145",
        "Ley 715 de 2001, art. 10, funciones del rector",
        "Ley 715 de 2001, art. 10"
      ],
      "correct": 1,
      "explanation": "Este marco se relaciona de modo más directo con las funciones del rector, la continuidad del servicio y las garantías del personal. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nC. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 270,
      "originalId": 130,
      "sourceExam": 2,
      "situationId": "S2-37",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se audita la documentación propuesta, ¿qué expediente exigiría la mayor subsanación?",
      "options": [
        "Expediente contrastado de evaluación de desempeño improvisada: criterios, compromisos, observaciones, productos y registros de retroalimentación, con índice y control de versiones.",
        "Criterios, compromisos, observaciones, productos y registros de retroalimentación.",
        "Criterios, registros de asistencia, observaciones, productos y registros de retroalimentación, durante la fase de evaluación definida en el cronograma de gestión de la institución, con una secuencia de comunicación posterior para facilitar el seguimiento de sus efectos."
      ],
      "correct": 2,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nB. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de aplicar proceso evaluativo pertinente con criterios conocidos, evidencias variadas y retroalimentación motivada.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 271,
      "originalId": 131,
      "sourceExam": 2,
      "situationId": "S2-37",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Entre las siguientes propuestas de seguimiento, ¿cuál deja una brecha de medición más relevante?",
      "options": [
        "Seguimiento desagregado por período y población de: cumplimiento de fases y calidad de evidencias de evaluación.",
        "Quejas encauzadas con reserva, oportunidad y protección frente a represalias.",
        "Cumplimiento de fases y calidad de evidencias de evaluación, en el marco de la discusión sostenida con quienes participaron en la reunión preparatoria."
      ],
      "correct": 1,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.\n\nC. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 272,
      "originalId": 132,
      "sourceExam": 2,
      "situationId": "S2-38",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué conjunto de evidencias permitiría sustentar de manera más sólida la decisión?",
      "options": [
        "Series de asistencia, planes de área, calendario y definiciones previas del indicador, para que el equipo responsable conozca los efectos esperados y los pasos anunciados, con indicación del período al que se refiere la propuesta de actuación y sus consecuencias.",
        "Series de asistencia, matrícula, actas de ciclos y definiciones previas del indicador.",
        "Series de asistencia, matrícula, calendario y definiciones previas del indicador, con indicación del período al que se refiere la propuesta de actuación y sus consecuencias."
      ],
      "correct": 2,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de definir fórmula, población, línea de base, horizonte temporal y responsables antes de fijar metas de mejoramiento.",
      "distractors": "A. Esta selección es parcial: no integra matrícula, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nB. Esta selección es parcial: no integra calendario, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 273,
      "originalId": 133,
      "sourceExam": 2,
      "situationId": "S2-38",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál de las medidas planteadas podría producir una actuación institucional objetable por su alcance o secuencia?",
      "options": [
        "Definir fórmula, población, línea de base, horizonte temporal y responsables antes de fijar metas de mejoramiento.",
        "Examinar los soportes asociados a metas sin línea de base, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Mantener la meta institucional y establecer la línea de base con registros recopilados durante el primer período de implementación; según el informe preparado por la coordinación responsable de revisar la propuesta."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la coherencia entre diagnóstico, metas, ejecución y evidencia.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la coherencia entre diagnóstico, metas, ejecución y evidencia.\n\nB. La alternativa preserva un examen previo y fundamentado de metas sin línea de base antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 274,
      "originalId": 134,
      "sourceExam": 2,
      "situationId": "S2-38",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál criterio de seguimiento refleja mejor el problema que se pretende corregir?",
      "options": [
        "Avance de estudiantes entre niveles de competencia en períodos equivalentes, con una constancia escrita de las razones utilizadas para orientar la actuación institucional.",
        "Variación de la tasa de ausencia con el mismo denominador entre períodos comparables.",
        "Proporción de juicios institucionales respaldados por evidencias pertinentes, con referencia explícita al contexto escolar particular que originó la controversia."
      ],
      "correct": 1,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.\n\nC. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 275,
      "originalId": 135,
      "sourceExam": 2,
      "situationId": "S2-39",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué iniciativa sería más difícil de justificar si se confronta con las obligaciones rectorales pertinentes?",
      "options": [
        "Examinar los soportes asociados a evaluación oral rígida, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables; con anotación de las circunstancias específicas del establecimiento en la fecha de la decisión.",
        "Conservar la evaluación oral y permitir respuestas escritas después de finalizar el tiempo previsto para el resto del curso; como parte de una decisión comunicada a los equipos que resultarían directamente involucrados.",
        "Ajustar medios de expresión conforme a valoración pedagógica, conservando los aprendizajes esenciales, con acta de socialización y seguimiento por el equipo académico."
      ],
      "correct": 1,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para el retiro de barreras y la participación educativa en igualdad de condiciones.",
      "distractors": "A. La alternativa preserva un examen previo y fundamentado de evaluación oral rígida antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nC. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta el retiro de barreras y la participación educativa en igualdad de condiciones.",
      "legalBasis": "Decreto 1421 de 2017, incorporado al Decreto 1075 de 2015"
    },
    {
      "id": 276,
      "originalId": 136,
      "sourceExam": 2,
      "situationId": "S2-39",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál formulación introduce la limitación más importante al evaluar el resultado y no solo la gestión?",
      "options": [
        "Validez de la demostración de aprendizaje tras retirar barreras de respuesta, como parte de la respuesta elaborada tras la reunión del personal que participó en el análisis.",
        "Cumplimiento de metas individualizadas con ajustes efectivamente implementados.",
        "Seguimiento desagregado por período y población de: validez de la demostración de aprendizaje tras retirar barreras de respuesta."
      ],
      "correct": 1,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.\n\nC. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.",
      "legalBasis": "Decreto 1421 de 2017, incorporado al Decreto 1075 de 2015"
    },
    {
      "id": 277,
      "originalId": 137,
      "sourceExam": 2,
      "situationId": "S2-39",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué combinación de documentos sería la menos adecuada para examinar las condiciones del supuesto?",
      "options": [
        "Evidencias de conocimientos, evidencias de aprendizaje y ajustes registrados, con indicación del período al que se refiere la propuesta de actuación y sus consecuencias.",
        "Expediente contrastado de evaluación oral rígida: evidencias de conocimientos, medios comunicativos funcionales y ajustes registrados, con índice y control de versiones, con registro de las decisiones tomadas durante el período de atención del asunto.",
        "Evidencias de conocimientos, medios comunicativos funcionales y ajustes registrados."
      ],
      "correct": 0,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "B. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nC. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de ajustar medios de expresión conforme a valoración pedagógica, conservando los aprendizajes esenciales.",
      "legalBasis": "Decreto 1421 de 2017, incorporado al Decreto 1075 de 2015"
    },
    {
      "id": 278,
      "originalId": 138,
      "sourceExam": 2,
      "situationId": "S2-40",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué fuente complementaria aportaría menos capacidad para contrastar la conclusión del documento?",
      "options": [
        "Incidentes comparables, participación y condiciones de implementación antes y después.",
        "Actas de asistencia por grado y valoración general de docentes sobre cada taller, como parte de una decisión comunicada a los equipos que resultarían directamente involucrados.",
        "Registros alternativos y comparables sobre argumento de presupuesto sin datos, contrastados con las condiciones iniciales."
      ],
      "correct": 1,
      "explanation": "La alternativa extrapola o sustituye indebidamente la evidencia: una ratificación del autor no aporta contraste independiente.",
      "distractors": "A. Esta alternativa se apoya en el argumento y sus límites: la evidencia propuesta examina directamente el salto inferencial identificado en el texto.\n\nC. Los datos externos comparables permiten examinar la inferencia expuesta sin limitarse a ratificaciones de quien redactó el informe.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de lectura crítica"
    },
    {
      "id": 279,
      "originalId": 139,
      "sourceExam": 2,
      "situationId": "S2-40",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué crítica sería menos pertinente para señalar la debilidad inferencial central del texto?",
      "options": [
        "Confundir un indicador de actividad con un resultado de convivencia.",
        "Sesgo de selección al priorizar opiniones de familias con mayor asistencia, como parte de una decisión comunicada a los equipos que resultarían directamente involucrados.",
        "La extrapolación de datos no comparables a un resultado institucional sobre argumento de presupuesto sin datos."
      ],
      "correct": 1,
      "explanation": "La alternativa extrapola o sustituye indebidamente la evidencia: una definición institucional adicional no corrige la inferencia central.",
      "distractors": "A. Esta alternativa se apoya en el argumento y sus límites: el defecto señalado impide pasar con justificación suficiente de las premisas a la conclusión.\n\nC. La crítica se dirige a la inferencia y a la extensión de las conclusiones, no a cuestiones formales.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de lectura crítica"
    },
    {
      "id": 280,
      "originalId": 140,
      "sourceExam": 2,
      "situationId": "S2-40",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué lectura del argumento realizaría la inferencia menos justificable a partir de las pruebas disponibles?",
      "options": [
        "La frecuencia de talleres constituye un indicio de cobertura que permite presumir mejora si la participación creció, como parte de una decisión comunicada a los equipos que resultarían directamente involucrados.",
        "La afirmación relativa a argumento de presupuesto sin datos requiere una comprobación complementaria antes de generalizar el efecto.",
        "La intensidad del programa está documentada, pero su eficacia permanece sin medir."
      ],
      "correct": 0,
      "explanation": "La alternativa extrapola o sustituye indebidamente la evidencia: convierte registro de actividades o ejemplos en demostración suficiente de impacto.",
      "distractors": "B. Distingue evidencia inicial de un resultado concluyente y delimita el alcance del texto.\n\nC. Esta alternativa se apoya en el argumento y sus límites: la lectura distingue lo sustentado por los datos de una conclusión que excede esa evidencia.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de lectura crítica"
    },
    {
      "id": 281,
      "originalId": 1,
      "sourceExam": 3,
      "situationId": "S3-01",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué observación sería más informativa al rendir cuentas sobre este caso?",
      "options": [
        "Traslados con acuerdos previos y ejecución conforme a disponibilidad.",
        "Recursos aplicados a destinaciones permitidas según documentos fuente, bajo una programación conocida por los integrantes responsables de examinar los resultados.",
        "Diferencias de inventario resueltas y bienes rastreables por responsable."
      ],
      "correct": 1,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.\n\nC. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 282,
      "originalId": 2,
      "sourceExam": 3,
      "situationId": "S3-01",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Antes de cerrar el análisis, ¿qué información resulta más decisiva para contrastar las afirmaciones?",
      "options": [
        "Convenio de origen, presupuesto, rubros, actas de recibo y autorizaciones posibles.",
        "Convenio de origen, flujo de caja, rubros, restricciones y autorizaciones posibles.",
        "Convenio de origen, presupuesto, rubros, restricciones y autorizaciones posibles, con seguimiento documental del cambio anunciado en el proceso escolar de referencia."
      ],
      "correct": 2,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de comprobar destinación y condiciones del recurso, aplicar ajustes autorizados y mantener trazabilidad.",
      "distractors": "A. Esta selección es parcial: no integra restricciones, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nB. Esta selección es parcial: no integra presupuesto, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 283,
      "originalId": 3,
      "sourceExam": 3,
      "situationId": "S3-01",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué propuesta presenta el riesgo institucional más grave, a pesar de sus aparentes ventajas operativas?",
      "options": [
        "Examinar los soportes asociados a sobrante de proyecto restringido, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables; en el marco de la discusión sostenida con quienes participaron en la reunión preparatoria.",
        "Comprobar destinación y condiciones del recurso, aplicar ajustes autorizados y mantener trazabilidad, con constancia de la decisión en las actas y archivos de rectoría.",
        "Trasladar el remanente al evento institucional y solicitar una modificación escrita del convenio después de ejecutarlo; con una secuencia de comunicación posterior para facilitar el seguimiento de sus efectos."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la autorización presupuestal, el control y la destinación de recursos públicos.",
      "distractors": "A. La alternativa preserva un examen previo y fundamentado de sobrante de proyecto restringido antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nB. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la autorización presupuestal, el control y la destinación de recursos públicos.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 284,
      "originalId": 4,
      "sourceExam": 3,
      "situationId": "S3-02",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué respuesta preserva mejor las garantías comprometidas en el caso?",
      "options": [
        "Mantener una tabla central compartida por docentes y colaboradores, con seudónimos y un registro de acceso posterior.",
        "Dividir los campos sensibles por hojas y distribuir enlaces separados sin revisar finalidades ni permisos de los usuarios.",
        "Minimizar datos, controlar accesos y validar finalidad, autorizaciones y salvaguardas de información sensible; y presentar una explicación de su alcance ante los integrantes del órgano correspondiente."
      ],
      "correct": 2,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la finalidad legítima, la calidad de datos y los controles de acceso.",
      "distractors": "A. Aunque identifica una salida posible, omite una condición sustantiva para la finalidad legítima, la calidad de datos y los controles de acceso.\n\nB. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 285,
      "originalId": 5,
      "sourceExam": 3,
      "situationId": "S3-02",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál conjunto documental permitiría una conclusión menos sólida sobre la actuación?",
      "options": [
        "Inventario de campos, sistema de permisos, finalidad y permisos reales del sistema.",
        "Inventario de campos, usuarios autorizados, finalidad y permisos reales del sistema, bajo una programación conocida por los integrantes responsables de examinar los resultados.",
        "Expediente contrastado de listado de salud en nube pública: inventario de campos, usuarios autorizados, finalidad y permisos reales del sistema, con índice y control de versiones."
      ],
      "correct": 0,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "B. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de minimizar datos, controlar accesos y validar finalidad, autorizaciones y salvaguardas de información sensible.\n\nC. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 286,
      "originalId": 6,
      "sourceExam": 3,
      "situationId": "S3-02",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál evidencia de resultado permitiría una evaluación menos sesgada?",
      "options": [
        "Publicaciones conformes a reglas de protección y sin exposición innecesaria.",
        "Accesos justificados y cumplimiento del calendario de gestión.",
        "Accesos justificados y ausencia de exposición de información sensible."
      ],
      "correct": 2,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir accesos justificados, componente esencial del resultado propuesto.\n\nB. Considera una variable relacionada con el caso, pero deja sin medir ausencia de exposición de información sensible, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 287,
      "originalId": 7,
      "sourceExam": 3,
      "situationId": "S3-03",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Según la definición de abandono de la premisa, ¿cuál es la tasa de retiros efectivos?",
      "options": [
        "5,0 %",
        "5,3 %",
        "7,5 %"
      ],
      "correct": 0,
      "explanation": "24 / 480 × 100 = 5,0 %. Los traslados certificados no son retiros efectivos bajo esta definición.",
      "distractors": "B. Confunde una magnitud con otra o realiza una agregación que altera la base de comparación.\n\nC. Corresponde a una operación o denominador distinto del definido; no coincide con los datos.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de razonamiento cuantitativo"
    },
    {
      "id": 288,
      "originalId": 8,
      "sourceExam": 3,
      "situationId": "S3-03",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se identifican otros ocho retiros efectivos de esa cohorte, ¿qué tasa acumulada resulta?",
      "options": [
        "6,25 % exactamente",
        "6,67 % aproximadamente",
        "8,33 % aproximadamente"
      ],
      "correct": 1,
      "explanation": "(24 + 8) / 480 × 100 = 6,666... %. El denominador permanece en la matrícula inicial.",
      "distractors": "A. Confunde una magnitud con otra o realiza una agregación que altera la base de comparación.\n\nC. Corresponde a una operación o denominador distinto del definido; no coincide con los datos.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de razonamiento cuantitativo"
    },
    {
      "id": 289,
      "originalId": 9,
      "sourceExam": 3,
      "situationId": "S3-03",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál es el porcentaje de movimientos de salida si se cuentan retiros y traslados, sin llamarlo deserción?",
      "options": [
        "7,5 %",
        "5,0 %",
        "8,1 %"
      ],
      "correct": 0,
      "explanation": "(24 + 12) / 480 × 100 = 7,5 %. La tasa incluye tipos de salida diferentes.",
      "distractors": "B. Corresponde a una operación o denominador distinto del definido; no coincide con los datos.\n\nC. Confunde una magnitud con otra o realiza una agregación que altera la base de comparación.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de razonamiento cuantitativo"
    },
    {
      "id": 290,
      "originalId": 10,
      "sourceExam": 3,
      "situationId": "S3-04",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué crítica sería menos pertinente para señalar la debilidad inferencial central del texto?",
      "options": [
        "La extrapolación de datos no comparables a un resultado institucional sobre silencio del acta.",
        "Sesgo de selección por registrar exclusivamente casos exitosos de transporte.",
        "Tomar la mención de un problema como evidencia de solución."
      ],
      "correct": 1,
      "explanation": "La alternativa extrapola o sustituye indebidamente la evidencia: una definición institucional adicional no corrige la inferencia central.",
      "distractors": "A. La crítica se dirige a la inferencia y a la extensión de las conclusiones, no a cuestiones formales.\n\nC. Esta alternativa se apoya en el argumento y sus límites: el defecto señalado impide pasar con justificación suficiente de las premisas a la conclusión.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de lectura crítica"
    },
    {
      "id": 291,
      "originalId": 11,
      "sourceExam": 3,
      "situationId": "S3-04",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué lectura del argumento realizaría la inferencia menos justificable a partir de las pruebas disponibles?",
      "options": [
        "El registro confirma que se discutió un asunto; no permite concluir que quedó resuelto.",
        "La afirmación relativa a silencio del acta requiere una comprobación complementaria antes de generalizar el efecto.",
        "La inclusión en acta permite afirmar que el problema se incorporó al plan de solución institucional."
      ],
      "correct": 2,
      "explanation": "La alternativa extrapola o sustituye indebidamente la evidencia: convierte registro de actividades o ejemplos en demostración suficiente de impacto.",
      "distractors": "A. Esta alternativa se apoya en el argumento y sus límites: la lectura distingue lo sustentado por los datos de una conclusión que excede esa evidencia.\n\nB. Distingue evidencia inicial de un resultado concluyente y delimita el alcance del texto.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de lectura crítica"
    },
    {
      "id": 292,
      "originalId": 12,
      "sourceExam": 3,
      "situationId": "S3-04",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué fuente complementaria aportaría menos capacidad para contrastar la conclusión del documento?",
      "options": [
        "Registros alternativos y comparables sobre silencio del acta, contrastados con las condiciones iniciales, según el informe preparado por la coordinación responsable de revisar la propuesta.",
        "Lista de asistentes y orden del día de la reunión en que se discutió el asunto, con una descripción de las condiciones que la rectoría consideró relevantes en este supuesto.",
        "Actas posteriores, responsables, acciones efectuadas y comprobación de resultados."
      ],
      "correct": 1,
      "explanation": "La alternativa extrapola o sustituye indebidamente la evidencia: una ratificación del autor no aporta contraste independiente.",
      "distractors": "A. Los datos externos comparables permiten examinar la inferencia expuesta sin limitarse a ratificaciones de quien redactó el informe.\n\nC. Esta alternativa se apoya en el argumento y sus límites: la evidencia propuesta examina directamente el salto inferencial identificado en el texto.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de lectura crítica"
    },
    {
      "id": 293,
      "originalId": 13,
      "sourceExam": 3,
      "situationId": "S3-05",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué fuente complementaria aportaría menos capacidad para contrastar la conclusión del documento?",
      "options": [
        "Registros alternativos y comparables sobre falsa disyuntiva de inclusión, contrastados con las condiciones iniciales.",
        "Costos, barreras y beneficios de alternativas que benefician a distintas poblaciones.",
        "Cuantía global asignada a apoyos y valoración del Consejo sobre su aceptación."
      ],
      "correct": 2,
      "explanation": "La alternativa extrapola o sustituye indebidamente la evidencia: una ratificación del autor no aporta contraste independiente.",
      "distractors": "A. Los datos externos comparables permiten examinar la inferencia expuesta sin limitarse a ratificaciones de quien redactó el informe.\n\nB. Esta alternativa se apoya en el argumento y sus límites: la evidencia propuesta examina directamente el salto inferencial identificado en el texto.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de lectura crítica"
    },
    {
      "id": 294,
      "originalId": 14,
      "sourceExam": 3,
      "situationId": "S3-05",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué crítica sería menos pertinente para señalar la debilidad inferencial central del texto?",
      "options": [
        "Falso dilema en la asignación de apoyos educativos, y presentar una explicación de su alcance ante los integrantes del órgano correspondiente.",
        "La extrapolación de datos no comparables a un resultado institucional sobre falsa disyuntiva de inclusión.",
        "Inferir causalidad educativa a partir de una coincidencia en el calendario."
      ],
      "correct": 2,
      "explanation": "La alternativa extrapola o sustituye indebidamente la evidencia: una definición institucional adicional no corrige la inferencia central.",
      "distractors": "A. Esta alternativa se apoya en el argumento y sus límites: el defecto señalado impide pasar con justificación suficiente de las premisas a la conclusión.\n\nB. La crítica se dirige a la inferencia y a la extensión de las conclusiones, no a cuestiones formales.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de lectura crítica"
    },
    {
      "id": 295,
      "originalId": 15,
      "sourceExam": 3,
      "situationId": "S3-05",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué lectura del argumento realizaría la inferencia menos justificable a partir de las pruebas disponibles?",
      "options": [
        "La premisa presenta como excluyentes soluciones que pueden diseñarse de modo compatible, y presentar una explicación de su alcance ante los integrantes del órgano correspondiente.",
        "La prioridad de los ajustes especializados resulta excluyente cuando el presupuesto disponible es fijo.",
        "La afirmación relativa a falsa disyuntiva de inclusión requiere una comprobación complementaria antes de generalizar el efecto."
      ],
      "correct": 1,
      "explanation": "La alternativa extrapola o sustituye indebidamente la evidencia: convierte registro de actividades o ejemplos en demostración suficiente de impacto.",
      "distractors": "A. Esta alternativa se apoya en el argumento y sus límites: la lectura distingue lo sustentado por los datos de una conclusión que excede esa evidencia.\n\nC. Distingue evidencia inicial de un resultado concluyente y delimita el alcance del texto.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de lectura crítica"
    },
    {
      "id": 296,
      "originalId": 16,
      "sourceExam": 3,
      "situationId": "S3-06",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Para orientar la motivación jurídica inicial, ¿qué marco ofrece la conexión más pertinente con los hechos?",
      "options": [
        "Resolución MEN 003842 de 2022, gestión académica",
        "Ley 115 de 1994, objetivos, áreas y proyectos educativos",
        "Decreto 1290 de 2009, art. 11"
      ],
      "correct": 0,
      "explanation": "Este marco se relaciona de modo más directo con la correspondencia entre objetivos curriculares, apoyos didácticos y aprendizaje. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "B. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nC. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 297,
      "originalId": 17,
      "sourceExam": 3,
      "situationId": "S3-06",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cómo debería operacionalizarse el resultado esperado en el plan de seguimiento?",
      "options": [
        "Progreso por nivel curricular y participación de estudiantes en el aula multigrado.",
        "Progreso de aprendizaje por condición de acceso y sede.",
        "Sede y asistencia a reuniones."
      ],
      "correct": 1,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir progreso de aprendizaje por condición de acceso, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir progreso de aprendizaje por condición de acceso, componente esencial del resultado propuesto.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 298,
      "originalId": 18,
      "sourceExam": 3,
      "situationId": "S3-06",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué conjunto de evidencias permitiría sustentar de manera más sólida la decisión?",
      "options": [
        "Conectividad por sede, desempeños antes, desempeños previos y productos comparables.",
        "Conectividad por sede, asistencia, competencias por grado y productos comparables.",
        "Conectividad por sede, asistencia, desempeños previos y productos comparables."
      ],
      "correct": 2,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de diseñar alternativas equivalentes de acceso y evaluar resultados de manera desagregada antes de escalar.",
      "distractors": "A. Esta selección es parcial: no integra asistencia, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nB. Esta selección es parcial: no integra desempeños previos, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 299,
      "originalId": 19,
      "sourceExam": 3,
      "situationId": "S3-06",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué propuesta presenta el riesgo institucional más grave, a pesar de sus aparentes ventajas operativas?",
      "options": [
        "Diseñar alternativas equivalentes de acceso y evaluar resultados de manera desagregada antes de escalar, previa discusión con los representantes de las sedes involucradas.",
        "Escalar primero a las sedes conectadas y usar sus resultados como punto de partida para calcular mejoras institucionales; con seguimiento documental del cambio anunciado en el proceso escolar de referencia.",
        "Examinar los soportes asociados a robótica y brecha digital, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables."
      ],
      "correct": 1,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la correspondencia entre objetivos curriculares, apoyos didácticos y aprendizaje.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la correspondencia entre objetivos curriculares, apoyos didácticos y aprendizaje.\n\nC. La alternativa preserva un examen previo y fundamentado de robótica y brecha digital antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 300,
      "originalId": 20,
      "sourceExam": 3,
      "situationId": "S3-07",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Antes de cerrar el análisis, ¿qué información resulta más decisiva para contrastar las afirmaciones?",
      "options": [
        "Encuestas de disponibilidad, conectividad, rutas y registros de asistencia.",
        "Encuestas de disponibilidad, conectividad, datos de desempeño y registros de asistencia.",
        "Encuestas de disponibilidad, planes de área, rutas y registros de asistencia, con una constancia escrita de las razones utilizadas para orientar la actuación institucional."
      ],
      "correct": 0,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de concertar modalidades y horarios flexibles, escuchar barreras y construir agenda con familias diversas.",
      "distractors": "B. Esta selección es parcial: no integra rutas, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra conectividad, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 301,
      "originalId": 21,
      "sourceExam": 3,
      "situationId": "S3-07",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué observación sería más informativa al rendir cuentas sobre este caso?",
      "options": [
        "Tipo de familia y asistencia a reuniones, con una constancia escrita de las razones utilizadas para orientar la actuación institucional.",
        "Prácticas con supervisión, cobertura de riesgos y tratamiento legítimo de datos.",
        "Participación sostenida por barreras territoriales y tipo de familia."
      ],
      "correct": 2,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir participación sostenida por barreras territoriales, componente esencial del resultado propuesto.\n\nB. Considera una variable relacionada con el caso, pero deja sin medir participación sostenida por barreras territoriales, componente esencial del resultado propuesto.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 302,
      "originalId": 22,
      "sourceExam": 3,
      "situationId": "S3-07",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué alternativa es más consistente con la responsabilidad directiva frente a los hechos?",
      "options": [
        "Organizar sesiones presenciales en cada sede, con idéntico horario de trabajo para facilitar la logística institucional.",
        "Concertar modalidades y horarios flexibles, escuchar barreras y construir agenda con familias diversas; según el informe preparado por la coordinación responsable de revisar la propuesta.",
        "Conservar una reunión presencial central y transmitir su grabación posteriormente para las familias de zonas alejadas."
      ],
      "correct": 1,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la participación significativa, la accesibilidad y el diálogo territorial.",
      "distractors": "A. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.\n\nC. Aunque identifica una salida posible, omite una condición sustantiva para la participación significativa, la accesibilidad y el diálogo territorial.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 303,
      "originalId": 23,
      "sourceExam": 3,
      "situationId": "S3-08",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál evidencia de resultado permitiría una evaluación menos sesgada?",
      "options": [
        "Pérdidas evitadas y asistencia a reuniones, con referencia explícita al contexto escolar particular que originó la controversia.",
        "Días de servicio seguro, continuidad pedagógica y pérdidas evitadas.",
        "Tiempo para asegurar consumo seguro y cobertura de las medidas preventivas."
      ],
      "correct": 1,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir días de servicio seguro, continuidad pedagógica, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir días de servicio seguro, continuidad pedagógica, componente esencial del resultado propuesto.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 304,
      "originalId": 24,
      "sourceExam": 3,
      "situationId": "S3-08",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si la rectoría debe tomar una decisión inicial motivada, ¿cuál opción es preferible?",
      "options": [
        "Priorizar protección sanitaria y plan pedagógico de contingencia mientras se gestiona solución técnica; como parte de una decisión comunicada a los equipos que resultarían directamente involucrados.",
        "Trasladar las clases de informática a otras horas y conservar los alimentos bajo los controles térmicos anteriores.",
        "Alquilar una planta eléctrica temporal y mantener los protocolos actuales hasta completar su evaluación de funcionamiento; con anotación de las circunstancias específicas del establecimiento en la fecha de la decisión."
      ],
      "correct": 0,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la prevención, la protección de personas y la continuidad segura del servicio.",
      "distractors": "B. Aunque identifica una salida posible, omite una condición sustantiva para la prevención, la protección de personas y la continuidad segura del servicio.\n\nC. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 305,
      "originalId": 25,
      "sourceExam": 3,
      "situationId": "S3-08",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué soportes documentales aportan el mejor fundamento para la actuación institucional?",
      "options": [
        "Registros de cortes, temperaturas, inventario eléctrico y alternativas de enseñanza, con una comunicación dirigida a los actores mencionados en el expediente institucional.",
        "Registros de cortes, temperaturas, reportes de ruta y alternativas de enseñanza.",
        "Registros de cortes, registros de tiempos, inventario eléctrico y alternativas de enseñanza."
      ],
      "correct": 0,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de priorizar protección sanitaria y plan pedagógico de contingencia mientras se gestiona solución técnica.",
      "distractors": "B. Esta selección es parcial: no integra inventario eléctrico, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra temperaturas, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 306,
      "originalId": 26,
      "sourceExam": 3,
      "situationId": "S3-09",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué medida permitiría valorar el resultado de la intervención sin confundir actividad con impacto?",
      "options": [
        "Permanencia e integración académica sin exclusiones por procedencia.",
        "Raciones seguras efectivamente servidas y días de interrupción atendidos.",
        "Continuidad de trayectoria con decisiones de traslado documentadas y justificadas."
      ],
      "correct": 2,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir continuidad de trayectoria con decisiones de traslado documentadas, componente esencial del resultado propuesto.\n\nB. Considera una variable relacionada con el caso, pero deja sin medir continuidad de trayectoria con decisiones de traslado documentadas, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 307,
      "originalId": 27,
      "sourceExam": 3,
      "situationId": "S3-09",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "En una revisión externa, ¿qué evidencia permitiría reconstruir con mayor rigor lo ocurrido?",
      "options": [
        "Matrícula, capacidad, normas de cobertura, patrón de ausencias y solicitudes familiares, como parte de una decisión comunicada a los equipos que resultarían directamente involucrados.",
        "Matrícula, informes de entrega, normas de cobertura, nuevas condiciones y solicitudes familiares.",
        "Matrícula, capacidad, normas de cobertura, nuevas condiciones y solicitudes familiares."
      ],
      "correct": 2,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de analizar reglas efectivas de cobertura, continuidad y procedimiento, evitando decisiones arbitrarias de exclusión.",
      "distractors": "A. Esta selección es parcial: no integra nuevas condiciones, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nB. Esta selección es parcial: no integra capacidad, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 308,
      "originalId": 28,
      "sourceExam": 3,
      "situationId": "S3-09",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referente delimita de forma más directa las responsabilidades institucionales involucradas?",
      "options": [
        "Ley 1620 de 2013 y sus rutas institucionales",
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes",
        "Decreto 1421 de 2017, educación inclusiva y PIAR"
      ],
      "correct": 1,
      "explanation": "Este marco se relaciona de modo más directo con la garantía del derecho a la educación y la articulación de protección. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nC. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 309,
      "originalId": 29,
      "sourceExam": 3,
      "situationId": "S3-09",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué iniciativa sería más difícil de justificar si se confronta con las obligaciones rectorales pertinentes?",
      "options": [
        "Examinar los soportes asociados a conflicto por cambio de residencia, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Conservar el cupo por el período y gestionar traslado obligatorio al inicio del siguiente sin valorar circunstancias particulares; con una constancia escrita de las razones utilizadas para orientar la actuación institucional.",
        "Analizar reglas efectivas de cobertura, continuidad y procedimiento, evitando decisiones arbitrarias de exclusión."
      ],
      "correct": 1,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la garantía del derecho a la educación y la articulación de protección.",
      "distractors": "A. La alternativa preserva un examen previo y fundamentado de conflicto por cambio de residencia antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nC. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la garantía del derecho a la educación y la articulación de protección.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 310,
      "originalId": 30,
      "sourceExam": 3,
      "situationId": "S3-10",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué fuentes deberían triangularse para reducir el riesgo de una conclusión apresurada?",
      "options": [
        "Inspección técnica, rutas utilizadas, comunicaciones y alternativas seguras.",
        "Inspección técnica, rutas utilizadas, roles y alternativas seguras, bajo una programación conocida por los integrantes responsables de examinar los resultados.",
        "Inspección técnica, alternativas de enseñanza, comunicaciones y alternativas seguras."
      ],
      "correct": 0,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de adoptar mitigaciones de acceso seguro, comunicar a autoridades responsables y seguir riesgo hasta solución.",
      "distractors": "B. Esta selección es parcial: no integra comunicaciones, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra rutas utilizadas, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 311,
      "originalId": 31,
      "sourceExam": 3,
      "situationId": "S3-10",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Para revisar el avance dentro de un período comparable, ¿qué indicador tiene mayor pertinencia?",
      "options": [
        "Exposición diaria al riesgo y efectividad de la ruta segura acordada, en el marco de la discusión sostenida con quienes participaron en la reunión preparatoria.",
        "Condiciones de seguridad verificadas y tiempos de respuesta ante contingencias.",
        "Tiempo y seguridad de evacuación de toda la población, desagregados por necesidades, como parte de la respuesta elaborada tras la reunión del personal que participó en el análisis."
      ],
      "correct": 0,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "B. Considera una variable relacionada con el caso, pero deja sin medir exposición diaria al riesgo, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir exposición diaria al riesgo, componente esencial del resultado propuesto.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 312,
      "originalId": 32,
      "sourceExam": 3,
      "situationId": "S3-10",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué respuesta preserva mejor las garantías comprometidas en el caso?",
      "options": [
        "Adoptar mitigaciones de acceso seguro, comunicar a autoridades responsables y seguir riesgo hasta solución; con una comunicación dirigida a los actores mencionados en el expediente institucional.",
        "Solicitar intervención de infraestructura local y mantener el acceso usual con acompañamiento docente en horas de ingreso.",
        "Organizar una inspección con líderes familiares y autorizar el trayecto mientras se obtiene informe técnico de la entidad competente."
      ],
      "correct": 0,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la prevención, la protección de personas y la continuidad segura del servicio.",
      "distractors": "B. Aunque identifica una salida posible, omite una condición sustantiva para la prevención, la protección de personas y la continuidad segura del servicio.\n\nC. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 313,
      "originalId": 33,
      "sourceExam": 3,
      "situationId": "S3-11",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referencia normativa conviene revisar primero por su relación directa con el caso?",
      "options": [
        "Decreto 1290 de 2009, art. 11",
        "Resolución MEN 003842 de 2022, gestión académica",
        "Ley 115 de 1994, objetivos, áreas y proyectos educativos"
      ],
      "correct": 2,
      "explanation": "Este marco se relaciona de modo más directo con la integralidad curricular y la función pedagógica institucional. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nB. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 314,
      "originalId": 34,
      "sourceExam": 3,
      "situationId": "S3-11",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué combinación de documentos sería la menos adecuada para examinar las condiciones del supuesto?",
      "options": [
        "Mallas curriculares, estándares, desempeños y muestras de clase.",
        "Expediente contrastado de lengua extranjera sin articulación: mallas curriculares, estándares, desempeños y muestras de clase, con índice y control de versiones.",
        "Mallas curriculares, planes de área, desempeños y muestras de clase, como parte de la respuesta elaborada tras la reunión del personal que participó en el análisis, en el marco de la discusión sostenida con quienes participaron en la reunión preparatoria."
      ],
      "correct": 2,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de establecer progresiones, criterios comunes de evaluación y estrategias de transición por grados.\n\nB. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 315,
      "originalId": 35,
      "sourceExam": 3,
      "situationId": "S3-11",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál propuesta es jurídicamente y pedagógicamente más defendible?",
      "options": [
        "Homologar pruebas finales entre cursos y revisar el currículo únicamente después de conocer las diferencias de resultados.",
        "Definir un libro institucional común y permitir que cada docente establezca libremente progresiones y evaluación por grado; para que el equipo responsable conozca los efectos esperados y los pasos anunciados.",
        "Establecer progresiones, criterios comunes de evaluación y estrategias de transición por grados; con indicación del período al que se refiere la propuesta de actuación y sus consecuencias."
      ],
      "correct": 2,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la integralidad curricular y la función pedagógica institucional.",
      "distractors": "A. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.\n\nB. Aunque identifica una salida posible, omite una condición sustantiva para la integralidad curricular y la función pedagógica institucional.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 316,
      "originalId": 36,
      "sourceExam": 3,
      "situationId": "S3-11",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál formulación introduce la limitación más importante al evaluar el resultado y no solo la gestión?",
      "options": [
        "Capacidad de analizar dilemas y resolver conflictos en actividades formativas.",
        "Seguimiento desagregado por período y población de: progresión de desempeños comunicativos por ciclo y grado.",
        "Progresión de desempeños comunicativos por ciclo y grado, según el informe preparado por la coordinación responsable de revisar la propuesta."
      ],
      "correct": 0,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "B. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.\n\nC. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 317,
      "originalId": 37,
      "sourceExam": 3,
      "situationId": "S3-12",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cómo debería operacionalizarse el resultado esperado en el plan de seguimiento?",
      "options": [
        "Secuencias interculturales implementadas con participación y aprendizajes pertinentes.",
        "Participación diversa por sede y asistencia a reuniones.",
        "Acceso efectivo a rendición de cuentas y participación diversa por sede, con seguimiento documental del cambio anunciado en el proceso escolar de referencia."
      ],
      "correct": 2,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir acceso efectivo a rendición de cuentas, componente esencial del resultado propuesto.\n\nB. Considera una variable relacionada con el caso, pero deja sin medir acceso efectivo a rendición de cuentas, componente esencial del resultado propuesto.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 318,
      "originalId": 38,
      "sourceExam": 3,
      "situationId": "S3-12",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué disposición es el punto de partida más específico para analizar la actuación?",
      "options": [
        "Ley 115 de 1994, arts. 142-145",
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes",
        "Decreto 459 de 2024, Alianza Familias-Escuela"
      ],
      "correct": 2,
      "explanation": "Este marco se relaciona de modo más directo con la participación significativa, la accesibilidad y el diálogo territorial. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nB. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 319,
      "originalId": 39,
      "sourceExam": 3,
      "situationId": "S3-12",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se comparan tres rutas de decisión, ¿cuál resultaría menos defendible ante una revisión de competencias y garantías?",
      "options": [
        "Garantizar canales y formatos accesibles de convocatoria y rendición, conservando información pública pertinente, con acta de socialización y seguimiento por el equipo académico.",
        "Examinar los soportes asociados a reunión de rendición excluyente, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Difundir el informe por internet y presentar un resumen impreso a quienes se acerquen voluntariamente a la sede; con una constancia escrita de las razones utilizadas para orientar la actuación institucional."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la participación significativa, la accesibilidad y el diálogo territorial.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la participación significativa, la accesibilidad y el diálogo territorial.\n\nB. La alternativa preserva un examen previo y fundamentado de reunión de rendición excluyente antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 320,
      "originalId": 40,
      "sourceExam": 3,
      "situationId": "S3-12",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué selección de soportes dejaría el vacío probatorio más importante para justificar la decisión?",
      "options": [
        "Conectividad, canales de participación y versiones públicas e insumos de participación, y presentar una explicación de su alcance ante los integrantes del órgano correspondiente.",
        "Expediente contrastado de reunión de rendición excluyente: conectividad, cobertura de comunicaciones, versiones públicas e insumos de participación, con índice y control de versiones.",
        "Conectividad, cobertura de comunicaciones, versiones públicas e insumos de participación."
      ],
      "correct": 0,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "B. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nC. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de garantizar canales y formatos accesibles de convocatoria y rendición, conservando información pública pertinente.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 321,
      "originalId": 41,
      "sourceExam": 3,
      "situationId": "S3-13",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Ante la situación descrita, ¿cuál actuación del rector constituye la respuesta mejor fundada?",
      "options": [
        "Reemplazar el accesorio discutido por otro único diseño decidido por rectoría, después de escuchar a representantes.",
        "Revisar la medida desde igualdad, participación y proporcionalidad, adoptando ajustes razonables compatibles con derechos.",
        "Permitir excepciones individuales mientras se conserve la regla general sin deliberación sobre sus impactos diferenciados; con una descripción de las condiciones que la rectoría consideró relevantes en este supuesto."
      ],
      "correct": 1,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la protección de derechos, los procedimientos y la reserva de información.",
      "distractors": "A. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.\n\nC. Aunque identifica una salida posible, omite una condición sustantiva para la protección de derechos, los procedimientos y la reserva de información.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 322,
      "originalId": 42,
      "sourceExam": 3,
      "situationId": "S3-13",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Antes de cerrar el análisis, ¿qué información resulta más decisiva para contrastar las afirmaciones?",
      "options": [
        "Justificación pedagógica de la regla, participación de implicados y participación comunitaria, con referencia explícita al contexto escolar particular que originó la controversia.",
        "Justificación pedagógica de la regla, alcance de la solicitud y participación comunitaria.",
        "Justificación pedagógica de la regla, impactos diferenciados y participación comunitaria, según el informe preparado por la coordinación responsable de revisar la propuesta."
      ],
      "correct": 2,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de revisar la medida desde igualdad, participación y proporcionalidad, adoptando ajustes razonables compatibles con derechos.",
      "distractors": "A. Esta selección es parcial: no integra impactos diferenciados, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nB. Esta selección es parcial: no integra impactos diferenciados, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 323,
      "originalId": 43,
      "sourceExam": 3,
      "situationId": "S3-13",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué observación sería más informativa al rendir cuentas sobre este caso?",
      "options": [
        "Barreras de participación eliminadas sin afectar objetivos institucionales legítimos.",
        "Oportunidad de respuesta y continuidad de apoyos sin revictimización.",
        "Solicitudes resueltas con justificación y protección de datos sensibles, con registro de las decisiones tomadas durante el período de atención del asunto."
      ],
      "correct": 0,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "B. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.\n\nC. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 324,
      "originalId": 44,
      "sourceExam": 3,
      "situationId": "S3-14",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál evidencia de resultado permitiría una evaluación menos sesgada?",
      "options": [
        "Reducción de brechas de permanencia o aprendizaje según la prioridad formalmente definida.",
        "Proporción de juicios institucionales respaldados por evidencias pertinentes, con registro de las decisiones tomadas durante el período de atención del asunto.",
        "Porcentaje de acciones de mejora implementadas y respaldadas por evidencias de aprendizaje, con una comunicación dirigida a los actores mencionados en el expediente institucional."
      ],
      "correct": 1,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.\n\nC. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 325,
      "originalId": 45,
      "sourceExam": 3,
      "situationId": "S3-14",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál conjunto documental permitiría una conclusión menos sólida sobre la actuación?",
      "options": [
        "Expediente contrastado de autodiagnóstico complaciente: rúbricas, datos de convivencia, infraestructura, trayectorias y actas de evaluación, con índice y control de versiones.",
        "Rúbricas, actas de ciclos, infraestructura, trayectorias y actas de evaluación, con registro de las decisiones tomadas durante el período de atención del asunto, para que el equipo responsable conozca los efectos esperados y los pasos anunciados.",
        "Rúbricas, datos de convivencia, infraestructura, trayectorias y actas de evaluación."
      ],
      "correct": 1,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nC. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de contrastar valoraciones con evidencias diversas y convocar deliberación crítica para reconocer brechas reales.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 326,
      "originalId": 46,
      "sourceExam": 3,
      "situationId": "S3-14",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué iniciativa sería más difícil de justificar si se confronta con las obligaciones rectorales pertinentes?",
      "options": [
        "Conservar el puntaje de autoevaluación y adjuntar las evidencias críticas como información de contexto para el PMI; bajo una programación conocida por los integrantes responsables de examinar los resultados.",
        "Examinar los soportes asociados a autodiagnóstico complaciente, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables; y presentar una explicación de su alcance ante los integrantes del órgano correspondiente.",
        "Contrastar valoraciones con evidencias diversas y convocar deliberación crítica para reconocer brechas reales, después de revisar el calendario de trabajo de cada coordinación."
      ],
      "correct": 0,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la coherencia entre diagnóstico, metas, ejecución y evidencia.",
      "distractors": "B. La alternativa preserva un examen previo y fundamentado de autodiagnóstico complaciente antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nC. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la coherencia entre diagnóstico, metas, ejecución y evidencia.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 327,
      "originalId": 47,
      "sourceExam": 3,
      "situationId": "S3-14",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Para orientar la motivación jurídica inicial, ¿qué marco ofrece la conexión más pertinente con los hechos?",
      "options": [
        "Resolución MEN 003842 de 2022, gestión académica",
        "Ley 715 de 2001, art. 10",
        "Ley 115 de 1994, arts. 142-145"
      ],
      "correct": 1,
      "explanation": "Este marco se relaciona de modo más directo con la coherencia entre diagnóstico, metas, ejecución y evidencia. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nC. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 328,
      "originalId": 48,
      "sourceExam": 3,
      "situationId": "S3-15",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "En una revisión externa, ¿qué evidencia permitiría reconstruir con mayor rigor lo ocurrido?",
      "options": [
        "Recomendaciones pertinentes, patrón de ausencias y plan de continuidad educativa, junto con la constancia de revisión de las condiciones informadas por los responsables.",
        "Recomendaciones pertinentes, competencias priorizadas y plan de continuidad educativa.",
        "Recomendaciones pertinentes, informes de entrega y plan de continuidad educativa, con una descripción de las condiciones que la rectoría consideró relevantes en este supuesto."
      ],
      "correct": 1,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de coordinar alternativas pedagógicas y ajustes razonables según situación, preservando trayectoria y evaluación pertinente.",
      "distractors": "A. Esta selección es parcial: no integra competencias priorizadas, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra competencias priorizadas, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 329,
      "originalId": 49,
      "sourceExam": 3,
      "situationId": "S3-15",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué alternativa es más consistente con la responsabilidad directiva frente a los hechos?",
      "options": [
        "Suspender calificaciones durante el tratamiento y ofrecer evaluación global cuando la estudiante pueda reincorporarse al aula.",
        "Diseñar materiales de estudio remoto idénticos al aula sin ajustar secuencias, comunicación ni criterios de seguimiento.",
        "Coordinar alternativas pedagógicas y ajustes razonables según situación, preservando trayectoria y evaluación pertinente; con referencia explícita al contexto escolar particular que originó la controversia."
      ],
      "correct": 2,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la garantía del derecho a la educación y la articulación de protección.",
      "distractors": "A. Aunque identifica una salida posible, omite una condición sustantiva para la garantía del derecho a la educación y la articulación de protección.\n\nB. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 330,
      "originalId": 50,
      "sourceExam": 3,
      "situationId": "S3-15",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál formulación introduce la limitación más importante al evaluar el resultado y no solo la gestión?",
      "options": [
        "Aprendizajes sostenidos y participación posible durante el tratamiento, con una descripción de las condiciones que la rectoría consideró relevantes en este supuesto.",
        "Protección activada oportunamente y seguimiento articulado sin revictimización.",
        "Seguimiento desagregado por período y población de: aprendizajes sostenidos y participación posible durante el tratamiento."
      ],
      "correct": 1,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.\n\nC. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 331,
      "originalId": 51,
      "sourceExam": 3,
      "situationId": "S3-16",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si la rectoría debe tomar una decisión inicial motivada, ¿cuál opción es preferible?",
      "options": [
        "Usar una rúbrica común de participación para todas las áreas y conservar los objetivos curriculares sin articulación adicional.",
        "Precisar problemas auténticos, desempeños curriculares, instrumentos de valoración y seguimiento de aprendizajes.",
        "Aprobar la huerta y medir productos físicos por asignatura, dejando criterios de aprendizaje para una evaluación posterior."
      ],
      "correct": 1,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la correspondencia entre objetivos curriculares, apoyos didácticos y aprendizaje.",
      "distractors": "A. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.\n\nC. Aunque identifica una salida posible, omite una condición sustantiva para la correspondencia entre objetivos curriculares, apoyos didácticos y aprendizaje.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 332,
      "originalId": 52,
      "sourceExam": 3,
      "situationId": "S3-16",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué medida sería menos adecuada como indicador principal para rendir cuentas sobre el resultado específico del caso?",
      "options": [
        "Logro de desempeños curriculares vinculados al proyecto por grado.",
        "Seguimiento desagregado por período y población de: logro de desempeños curriculares vinculados al proyecto por grado.",
        "Experiencias desarrolladas con controles de seguridad y logro científico previsto."
      ],
      "correct": 2,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.\n\nB. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 333,
      "originalId": 53,
      "sourceExam": 3,
      "situationId": "S3-16",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué disposición es el punto de partida más específico para analizar la actuación?",
      "options": [
        "Decreto 1290 de 2009, art. 11",
        "Ley 115 de 1994, objetivos, áreas y proyectos educativos",
        "Resolución MEN 003842 de 2022, gestión académica"
      ],
      "correct": 2,
      "explanation": "Este marco se relaciona de modo más directo con la correspondencia entre objetivos curriculares, apoyos didácticos y aprendizaje. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nB. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 334,
      "originalId": 54,
      "sourceExam": 3,
      "situationId": "S3-16",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué fuentes deberían triangularse para reducir el riesgo de una conclusión apresurada?",
      "options": [
        "Planes de área, productos estudiantiles, rúbricas, desempeños previos y después.",
        "Planes de área, productos estudiantiles, rúbricas y desempeños antes y después, durante la fase de evaluación definida en el cronograma de gestión de la institución.",
        "Planes de área, planes de clase, rúbricas, desempeños antes y después."
      ],
      "correct": 1,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de precisar problemas auténticos, desempeños curriculares, instrumentos de valoración y seguimiento de aprendizajes.",
      "distractors": "A. Esta selección es parcial: no integra desempeños antes, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra productos estudiantiles, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 335,
      "originalId": 55,
      "sourceExam": 3,
      "situationId": "S3-17",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál es la tasa consolidada de logro de las dos sedes?",
      "options": [
        "70,0 %",
        "75,0 %",
        "72,5 %"
      ],
      "correct": 2,
      "explanation": "(40 + 18) / (50 + 30) × 100 = 72,5 %. No es correcto promediar tasas sin ponderación.",
      "distractors": "A. Corresponde a una operación o denominador distinto del definido; no coincide con los datos.\n\nB. Confunde una magnitud con otra o realiza una agregación que altera la base de comparación.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de razonamiento cuantitativo"
    },
    {
      "id": 336,
      "originalId": 56,
      "sourceExam": 3,
      "situationId": "S3-17",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuántos estudiantes adicionales necesita la sede B para alcanzar al menos 75 % de logro, manteniendo 30 evaluados?",
      "options": [
        "5 estudiantes",
        "4 estudiantes",
        "6 estudiantes"
      ],
      "correct": 0,
      "explanation": "Se requiere como mínimo 23/30 = 76,67 %, pues 22/30 = 73,33 %; faltan 23 - 18 = 5 estudiantes.",
      "distractors": "B. Corresponde a una operación o denominador distinto del definido; no coincide con los datos.\n\nC. Confunde una magnitud con otra o realiza una agregación que altera la base de comparación.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de razonamiento cuantitativo"
    },
    {
      "id": 337,
      "originalId": 57,
      "sourceExam": 3,
      "situationId": "S3-17",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál es la diferencia de logro entre las sedes, en puntos porcentuales?",
      "options": [
        "25 puntos",
        "10 puntos",
        "20 puntos"
      ],
      "correct": 2,
      "explanation": "40/50 = 80 % y 18/30 = 60 %; la diferencia es 20 puntos porcentuales.",
      "distractors": "A. Confunde una magnitud con otra o realiza una agregación que altera la base de comparación.\n\nB. Corresponde a una operación o denominador distinto del definido; no coincide con los datos.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de razonamiento cuantitativo"
    },
    {
      "id": 338,
      "originalId": 58,
      "sourceExam": 3,
      "situationId": "S3-18",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Para orientar la motivación jurídica inicial, ¿qué marco ofrece la conexión más pertinente con los hechos?",
      "options": [
        "Ley 115 de 1994, arts. 142-145",
        "Ley 715 de 2001, art. 10, funciones del rector",
        "Decreto 1075 de 2015, sección del Fondo de Servicios Educativos"
      ],
      "correct": 2,
      "explanation": "Este marco se relaciona de modo más directo con la autorización presupuestal, el control y la destinación de recursos públicos. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nB. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 339,
      "originalId": 59,
      "sourceExam": 3,
      "situationId": "S3-18",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál conjunto documental permitiría una conclusión menos sólida sobre la actuación?",
      "options": [
        "Expediente contrastado de informe trimestral omitido: libros, reportes, flujo mensual, soportes contractuales y actas de entrega, con índice y control de versiones.",
        "Libros, flujo de caja, flujo mensual, soportes contractuales y actas de entrega.",
        "Libros, reportes, flujo mensual, soportes contractuales y actas de entrega."
      ],
      "correct": 1,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nC. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de presentar ejecución y flujo de caja con soportes, decisiones pendientes y trazabilidad de la rendición.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 340,
      "originalId": 60,
      "sourceExam": 3,
      "situationId": "S3-18",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué respuesta preserva mejor las garantías comprometidas en el caso?",
      "options": [
        "Presentar ejecución y flujo de caja con soportes, decisiones pendientes y trazabilidad de la rendición; con registro de las decisiones tomadas durante el período de atención del asunto.",
        "Presentar un resumen de ejecución al Consejo Directivo y conservar el flujo de caja detallado para consulta posterior; con una comunicación dirigida a los actores mencionados en el expediente institucional.",
        "Divulgar los estados financieros en carteleras y programar una discusión colegiada solo si se requieren traslados."
      ],
      "correct": 0,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la autorización presupuestal, el control y la destinación de recursos públicos.",
      "distractors": "B. Aunque identifica una salida posible, omite una condición sustantiva para la autorización presupuestal, el control y la destinación de recursos públicos.\n\nC. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 341,
      "originalId": 61,
      "sourceExam": 3,
      "situationId": "S3-18",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cómo debería operacionalizarse el resultado esperado en el plan de seguimiento?",
      "options": [
        "Procesos ejecutados conforme a cuantías reales y reglas de publicidad.",
        "Informes entregados a órganos competentes con oportunidad y consistencia, con anotación de las circunstancias específicas del establecimiento en la fecha de la decisión.",
        "Recursos aplicados a destinaciones permitidas según documentos fuente."
      ],
      "correct": 1,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir informes entregados a órganos competentes con oportunidad, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir informes entregados a órganos competentes con oportunidad, componente esencial del resultado propuesto.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 342,
      "originalId": 62,
      "sourceExam": 3,
      "situationId": "S3-19",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué iniciativa sería más difícil de justificar si se confronta con las obligaciones rectorales pertinentes?",
      "options": [
        "Validar una plantilla común por grado y personalizar sus apoyos al finalizar el primer período de ejecución.",
        "Construir ajustes pertinentes basados en valoración pedagógica individual y seguimiento colaborativo.",
        "Examinar los soportes asociados a piar copiado, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables."
      ],
      "correct": 0,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para el retiro de barreras y la participación educativa en igualdad de condiciones.",
      "distractors": "B. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta el retiro de barreras y la participación educativa en igualdad de condiciones.\n\nC. La alternativa preserva un examen previo y fundamentado de piar copiado antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Decreto 1421 de 2017, incorporado al Decreto 1075 de 2015"
    },
    {
      "id": 343,
      "originalId": 63,
      "sourceExam": 3,
      "situationId": "S3-19",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referencia normativa conviene revisar primero por su relación directa con el caso?",
      "options": [
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes",
        "Decreto 1421 de 2017, educación inclusiva y PIAR",
        "Ley 1620 de 2013 y sus rutas institucionales"
      ],
      "correct": 1,
      "explanation": "Este marco se relaciona de modo más directo con el retiro de barreras y la participación educativa en igualdad de condiciones. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nC. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Decreto 1421 de 2017, incorporado al Decreto 1075 de 2015"
    },
    {
      "id": 344,
      "originalId": 64,
      "sourceExam": 3,
      "situationId": "S3-19",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué combinación de documentos sería la menos adecuada para examinar las condiciones del supuesto?",
      "options": [
        "Valoraciones individuales, barreras, participación del estudiante y evidencias de aprendizaje, según el informe preparado por la coordinación responsable de revisar la propuesta.",
        "Valoraciones individuales, evidencias de conocimientos, participación del estudiante y evidencias de aprendizaje.",
        "Expediente contrastado de piar copiado: valoraciones individuales, barreras, participación del estudiante y evidencias de aprendizaje, con índice y control de versiones."
      ],
      "correct": 1,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de construir ajustes pertinentes basados en valoración pedagógica individual y seguimiento colaborativo.\n\nC. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.",
      "legalBasis": "Decreto 1421 de 2017, incorporado al Decreto 1075 de 2015"
    },
    {
      "id": 345,
      "originalId": 65,
      "sourceExam": 3,
      "situationId": "S3-19",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál formulación introduce la limitación más importante al evaluar el resultado y no solo la gestión?",
      "options": [
        "Progreso en retos de mayor complejidad y participación sostenida, con anotación de las circunstancias específicas del establecimiento en la fecha de la decisión.",
        "Seguimiento desagregado por período y población de: cumplimiento de metas individualizadas con ajustes efectivamente implementados.",
        "Cumplimiento de metas individualizadas con ajustes efectivamente implementados."
      ],
      "correct": 0,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "B. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.\n\nC. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "legalBasis": "Decreto 1421 de 2017, incorporado al Decreto 1075 de 2015"
    },
    {
      "id": 346,
      "originalId": 66,
      "sourceExam": 3,
      "situationId": "S3-20",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "De las siguientes actuaciones, ¿cuál requeriría una corrección prioritaria por comprometer el procedimiento o la garantía central del caso?",
      "options": [
        "Examinar los soportes asociados a agua contaminada, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables; como parte de la respuesta elaborada tras la reunión del personal que participó en el análisis.",
        "Activar medidas preventivas inmediatas, coordinación sanitaria y continuidad segura del servicio, con una verificación posterior de costos y resultados administrativos.",
        "Restringir consumo únicamente en el punto muestreado y mantener los demás usos hasta confirmar la extensión de la contaminación; durante la fase de evaluación definida en el cronograma de gestión de la institución."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la prevención, la protección de personas y la continuidad segura del servicio.",
      "distractors": "A. La alternativa preserva un examen previo y fundamentado de agua contaminada antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nB. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la prevención, la protección de personas y la continuidad segura del servicio.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 347,
      "originalId": 67,
      "sourceExam": 3,
      "situationId": "S3-20",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué selección de soportes dejaría el vacío probatorio más importante para justificar la decisión?",
      "options": [
        "Resultado de laboratorio, reportes de ruta, responsables sanitarios y contingencias, con una constancia escrita de las razones utilizadas para orientar la actuación institucional.",
        "Expediente contrastado de agua contaminada: resultado de laboratorio, puntos de abastecimiento, responsables sanitarios y contingencias, con índice y control de versiones, con seguimiento documental del cambio anunciado en el proceso escolar de referencia.",
        "Resultado de laboratorio, puntos de abastecimiento, responsables sanitarios y contingencias."
      ],
      "correct": 0,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "B. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nC. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de activar medidas preventivas inmediatas, coordinación sanitaria y continuidad segura del servicio.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 348,
      "originalId": 68,
      "sourceExam": 3,
      "situationId": "S3-20",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué disposición es el punto de partida más específico para analizar la actuación?",
      "options": [
        "Resolución MEN 003842 de 2022, gestión institucional y recursos",
        "Ley 715 de 2001, art. 10, funciones del rector",
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes"
      ],
      "correct": 0,
      "explanation": "Este marco se relaciona de modo más directo con la prevención, la protección de personas y la continuidad segura del servicio. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "B. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nC. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 349,
      "originalId": 69,
      "sourceExam": 3,
      "situationId": "S3-20",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué medida sería menos adecuada como indicador principal para rendir cuentas sobre el resultado específico del caso?",
      "options": [
        "Días de exposición al riesgo y continuidad segura del aprendizaje, para atender la solicitud presentada formalmente ante la dirección de la institución.",
        "Seguimiento desagregado por período y población de: tiempo para asegurar consumo seguro y cobertura de las medidas preventivas, bajo una programación conocida por los integrantes responsables de examinar los resultados.",
        "Tiempo para asegurar consumo seguro y cobertura de las medidas preventivas."
      ],
      "correct": 0,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "B. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.\n\nC. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 350,
      "originalId": 70,
      "sourceExam": 3,
      "situationId": "S3-21",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Ante la situación descrita, ¿cuál actuación del rector constituye la respuesta mejor fundada?",
      "options": [
        "Conservar el registro más reciente de cada estudiante y validar manualmente únicamente las inconsistencias notificadas por familias.",
        "Conciliar identificadores, depurar con trazabilidad y corregir reportes por el conducto competente; bajo una programación conocida por los integrantes responsables de examinar los resultados.",
        "Depurar los duplicados al finalizar el corte oficial y utilizar entretanto la matrícula reportada por el sistema sin ajustes."
      ],
      "correct": 1,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la finalidad legítima, la calidad de datos y los controles de acceso.",
      "distractors": "A. Aunque identifica una salida posible, omite una condición sustantiva para la finalidad legítima, la calidad de datos y los controles de acceso.\n\nC. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 351,
      "originalId": 71,
      "sourceExam": 3,
      "situationId": "S3-21",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "En una revisión externa, ¿qué evidencia permitiría reconstruir con mayor rigor lo ocurrido?",
      "options": [
        "Identificadores, historial de traslados, operaciones de matrícula y reglas del sistema, en el marco de la discusión sostenida con quienes participaron en la reunión preparatoria.",
        "Identificadores, historial de traslados, soportes de matrícula y reglas del sistema.",
        "Identificadores, sistema de permisos, soportes de matrícula y reglas del sistema, durante la fase de evaluación definida en el cronograma de gestión de la institución."
      ],
      "correct": 1,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de conciliar identificadores, depurar con trazabilidad y corregir reportes por el conducto competente.",
      "distractors": "A. Esta selección es parcial: no integra soportes de matrícula, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra historial de traslados, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 352,
      "originalId": 72,
      "sourceExam": 3,
      "situationId": "S3-21",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referente delimita de forma más directa las responsabilidades institucionales involucradas?",
      "options": [
        "Decreto 459 de 2024, Alianza Familias-Escuela",
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes",
        "Ley 1581 de 2012, tratamiento y protección de datos personales"
      ],
      "correct": 2,
      "explanation": "Este marco se relaciona de modo más directo con la finalidad legítima, la calidad de datos y los controles de acceso. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nB. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 353,
      "originalId": 73,
      "sourceExam": 3,
      "situationId": "S3-21",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué medida permitiría valorar el resultado de la intervención sin confundir actividad con impacto?",
      "options": [
        "Errores y efectos diferenciales del modelo junto con eficacia de apoyos humanos.",
        "Registros únicos consistentes con matrículas efectivamente activas.",
        "Publicaciones conformes a reglas de protección y sin exposición innecesaria."
      ],
      "correct": 1,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.\n\nC. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 354,
      "originalId": 74,
      "sourceExam": 3,
      "situationId": "S3-22",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál conjunto documental permitiría una conclusión menos sólida sobre la actuación?",
      "options": [
        "Proyecto existente, planes del proyecto, propuestas de docentes y familias, y presentar una explicación de su alcance ante los integrantes del órgano correspondiente, con un resumen de los antecedentes que motivaron la convocatoria de los participantes.",
        "Expediente contrastado de educación sexual sin enfoque de derechos: proyecto existente, necesidades del alumnado y propuestas de docentes y familias, con índice y control de versiones.",
        "Proyecto existente, necesidades del alumnado y propuestas de docentes y familias."
      ],
      "correct": 0,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "B. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nC. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de revisar pertinencia del proyecto pedagógico desde formación integral, evidencia y garantías de derechos.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 355,
      "originalId": 75,
      "sourceExam": 3,
      "situationId": "S3-22",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se comparan tres rutas de decisión, ¿cuál resultaría menos defendible ante una revisión de competencias y garantías?",
      "options": [
        "Contratar un programa externo basado en información sanitaria y adoptar sus contenidos como proyecto escolar completo.",
        "Examinar los soportes asociados a educación sexual sin enfoque de derechos, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Revisar pertinencia del proyecto pedagógico desde formación integral, evidencia y garantías de derechos, con el acompañamiento del comité correspondiente y registros de avance."
      ],
      "correct": 0,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la integralidad curricular y la función pedagógica institucional.",
      "distractors": "B. La alternativa preserva un examen previo y fundamentado de educación sexual sin enfoque de derechos antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nC. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la integralidad curricular y la función pedagógica institucional.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 356,
      "originalId": 76,
      "sourceExam": 3,
      "situationId": "S3-22",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Para orientar la motivación jurídica inicial, ¿qué marco ofrece la conexión más pertinente con los hechos?",
      "options": [
        "Decreto 1290 de 2009, art. 11",
        "Ley 115 de 1994, objetivos, áreas y proyectos educativos",
        "Resolución MEN 003842 de 2022, gestión académica"
      ],
      "correct": 1,
      "explanation": "Este marco se relaciona de modo más directo con la integralidad curricular y la función pedagógica institucional. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nC. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 357,
      "originalId": 77,
      "sourceExam": 3,
      "situationId": "S3-22",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué indicador tendría menor validez para establecer si se resolvió la necesidad institucional descrita?",
      "options": [
        "Seguimiento desagregado por período y población de: aprendizajes pertinentes y acceso a información formativa ajustada a edad, con una constancia escrita de las razones utilizadas para orientar la actuación institucional.",
        "Aprendizajes pertinentes y acceso a información formativa ajustada a edad.",
        "Progresión de desempeños comunicativos por ciclo y grado, junto con la constancia de revisión de las condiciones informadas por los responsables."
      ],
      "correct": 2,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.\n\nB. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 358,
      "originalId": 78,
      "sourceExam": 3,
      "situationId": "S3-23",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué alternativa es más consistente con la responsabilidad directiva frente a los hechos?",
      "options": [
        "Reasignar clases por disponibilidad horaria y autorizar laboratorios solo cuando el docente manifieste contar con experiencia.",
        "Encargar provisionalmente todas las sesiones experimentales a coordinación y revisar idoneidad después del primer período.",
        "Examinar perfiles, riesgos y cobertura, gestionar provisión o soluciones autorizadas sin comprometer calidad."
      ],
      "correct": 2,
      "explanation": "La medida aborda directamente el hecho descrito y respeta las funciones del rector, la continuidad del servicio y las garantías del personal.",
      "distractors": "A. Aunque identifica una salida posible, omite una condición sustantiva para las funciones del rector, la continuidad del servicio y las garantías del personal.\n\nB. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 359,
      "originalId": 79,
      "sourceExam": 3,
      "situationId": "S3-23",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué combinación de documentos sería la menos adecuada para examinar las condiciones del supuesto?",
      "options": [
        "Perfiles, cargas, plan de estudios, condiciones de laboratorio y requerimientos reportados.",
        "Perfiles, planes de aula, plan de estudios, condiciones de laboratorio y requerimientos reportados.",
        "Expediente contrastado de asignación docente fuera de perfil: perfiles, cargas, plan de estudios, condiciones de laboratorio y requerimientos reportados, con índice y control de versiones."
      ],
      "correct": 1,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de examinar perfiles, riesgos y cobertura, gestionar provisión o soluciones autorizadas sin comprometer calidad.\n\nC. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 360,
      "originalId": 80,
      "sourceExam": 3,
      "situationId": "S3-23",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referencia normativa conviene revisar primero por su relación directa con el caso?",
      "options": [
        "Ley 115 de 1994, arts. 142-145",
        "Ley 715 de 2001, art. 10",
        "Ley 715 de 2001, art. 10, funciones del rector"
      ],
      "correct": 2,
      "explanation": "Este marco se relaciona de modo más directo con las funciones del rector, la continuidad del servicio y las garantías del personal. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nB. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 361,
      "originalId": 81,
      "sourceExam": 3,
      "situationId": "S3-23",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál criterio de seguimiento refleja mejor el problema que se pretende corregir?",
      "options": [
        "Controles de seguridad y asistencia a reuniones, con indicación del período al que se refiere la propuesta de actuación y sus consecuencias.",
        "Quejas encauzadas con reserva, oportunidad y protección frente a represalias.",
        "Cobertura curricular con personal idóneo y controles de seguridad."
      ],
      "correct": 2,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir cobertura curricular con personal idóneo, componente esencial del resultado propuesto.\n\nB. Considera una variable relacionada con el caso, pero deja sin medir cobertura curricular con personal idóneo, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 362,
      "originalId": 82,
      "sourceExam": 3,
      "situationId": "S3-24",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué selección de soportes dejaría el vacío probatorio más importante para justificar la decisión?",
      "options": [
        "Expediente contrastado de proyecto de convenio local: texto de oferta, reglamento del gobierno escolar, actas y evaluación de riesgos del convenio, con índice y control de versiones.",
        "Texto de oferta, actas de la sesión, actas y evaluación de riesgos del convenio, según el informe preparado por la coordinación responsable de revisar la propuesta.",
        "Texto de oferta, reglamento del gobierno escolar, actas y evaluación de riesgos del convenio."
      ],
      "correct": 1,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nC. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de examinar el convenio desde los órganos competentes, preservar la autonomía del gobierno escolar y delimitar por escrito las obligaciones.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Ley 715 de 2001, art. 10"
    },
    {
      "id": 363,
      "originalId": 83,
      "sourceExam": 3,
      "situationId": "S3-24",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si la rectoría debe tomar una decisión inicial motivada, ¿cuál opción es preferible?",
      "options": [
        "Suscribir una carta de intención con la empresa y permitirle acompañar decisiones del Consejo sobre el uso de su aporte, con reuniones de seguimiento y una matriz de compromisos documentada.",
        "Examinar el convenio desde los órganos competentes, preservar la autonomía del gobierno escolar y delimitar por escrito las obligaciones; según el informe preparado por la coordinación responsable de revisar la propuesta.",
        "Aceptar el financiamiento condicionado, reservando al rector la facultad de revisar posteriormente la elección de representantes, con acompañamiento de coordinación para informar los cambios realizados."
      ],
      "correct": 1,
      "explanation": "La medida aborda directamente el hecho descrito y respeta el reparto de competencias y la participación válida del gobierno escolar.",
      "distractors": "A. Aunque identifica una salida posible, omite una condición sustantiva para el reparto de competencias y la participación válida del gobierno escolar.\n\nC. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Ley 715 de 2001, art. 10"
    },
    {
      "id": 364,
      "originalId": 84,
      "sourceExam": 3,
      "situationId": "S3-24",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cómo debería operacionalizarse el resultado esperado en el plan de seguimiento?",
      "options": [
        "Porcentaje de compromisos financiados ejecutados sin interferencia en decisiones institucionales.",
        "Proporción de acuerdos adoptados con soporte de quórum y seguimiento de ejecución.",
        "Reclamaciones electorales resueltas con motivación y oportunidad, por etapa del proceso."
      ],
      "correct": 0,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "B. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.\n\nC. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Ley 715 de 2001, art. 10"
    },
    {
      "id": 365,
      "originalId": 85,
      "sourceExam": 3,
      "situationId": "S3-25",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se audita la documentación propuesta, ¿qué expediente exigiría la mayor subsanación?",
      "options": [
        "Partes de atención, reportes oficiales, autorización de divulgación y cronología.",
        "Partes de atención, entrega de llaves, autorización de divulgación y cronología, según el informe preparado por la coordinación responsable de revisar la propuesta.",
        "Expediente contrastado de mensaje público tras accidente: partes de atención, reportes oficiales, autorización de divulgación y cronología, con índice y control de versiones."
      ],
      "correct": 1,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de comunicar hechos confirmados, medidas de atención y canales oficiales sin especular ni revelar datos protegidos.\n\nC. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 366,
      "originalId": 86,
      "sourceExam": 3,
      "situationId": "S3-25",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué observación sería más informativa al rendir cuentas sobre este caso?",
      "options": [
        "Comunicaciones oportunas, precisas y respetuosas de privacidad.",
        "Respetuosas de privacidad y asistencia a reuniones.",
        "Integridad documental y trazabilidad de actuaciones frente a instrucciones improcedentes."
      ],
      "correct": 0,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "B. Considera una variable relacionada con el caso, pero deja sin medir comunicaciones oportunas, precisas, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir comunicaciones oportunas, precisas, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 367,
      "originalId": 87,
      "sourceExam": 3,
      "situationId": "S3-25",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "De las siguientes actuaciones, ¿cuál requeriría una corrección prioritaria por comprometer el procedimiento o la garantía central del caso?",
      "options": [
        "Comunicar hechos confirmados, medidas de atención y canales oficiales sin especular ni revelar datos protegidos, con un cronograma de ejecución conocido por las instancias participantes.",
        "Emitir un comunicado con las hipótesis más probables y actualizarlo cuando se conozcan conclusiones de las autoridades; como parte de una decisión comunicada a los equipos que resultarían directamente involucrados.",
        "Examinar los soportes asociados a mensaje público tras accidente, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables; con anotación de las circunstancias específicas del establecimiento en la fecha de la decisión."
      ],
      "correct": 1,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la probidad, el criterio directivo y la rendición de cuentas.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la probidad, el criterio directivo y la rendición de cuentas.\n\nC. La alternativa preserva un examen previo y fundamentado de mensaje público tras accidente antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 368,
      "originalId": 88,
      "sourceExam": 3,
      "situationId": "S3-26",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué soportes documentales aportan el mejor fundamento para la actuación institucional?",
      "options": [
        "Modelos de boletín, necesidades de familias, rúbricas y planes de apoyo.",
        "Modelos de boletín, informes de apoyo, rúbricas y planes de apoyo, según el informe preparado por la coordinación responsable de revisar la propuesta.",
        "Modelos de boletín, necesidades de familias, actividades de apoyo y planes de apoyo."
      ],
      "correct": 0,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de garantizar informes interpretables sobre desempeños, dificultades, recomendaciones y apoyos disponibles.",
      "distractors": "B. Esta selección es parcial: no integra necesidades de familias, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra rúbricas, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 369,
      "originalId": 89,
      "sourceExam": 3,
      "situationId": "S3-26",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Para orientar la motivación jurídica inicial, ¿qué marco ofrece la conexión más pertinente con los hechos?",
      "options": [
        "Resolución MEN 003842 de 2022, gestión académica",
        "Decreto 1290 de 2009, art. 11",
        "Ley 115 de 1994, objetivos, áreas y proyectos educativos"
      ],
      "correct": 1,
      "explanation": "Este marco se relaciona de modo más directo con las reglas del SIEE, los apoyos y la motivación de decisiones académicas. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nC. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 370,
      "originalId": 90,
      "sourceExam": 3,
      "situationId": "S3-26",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué indicador tendría menor validez para establecer si se resolvió la necesidad institucional descrita?",
      "options": [
        "Reclamaciones resueltas motivadamente en los plazos establecidos, con una comunicación dirigida a los actores mencionados en el expediente institucional.",
        "Familias que comprenden el avance y conocen acciones concretas de acompañamiento.",
        "Seguimiento desagregado por período y población de: familias que comprenden el avance y conocen acciones concretas de acompañamiento."
      ],
      "correct": 0,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "B. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.\n\nC. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 371,
      "originalId": 91,
      "sourceExam": 3,
      "situationId": "S3-26",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué respuesta preserva mejor las garantías comprometidas en el caso?",
      "options": [
        "Garantizar informes interpretables sobre desempeños, dificultades, recomendaciones y apoyos disponibles; con anotación de las circunstancias específicas del establecimiento en la fecha de la decisión.",
        "Agregar una descripción estándar por área a los boletines, manteniendo la información individual exclusivamente en los registros docentes; bajo una programación conocida por los integrantes responsables de examinar los resultados.",
        "Entregar un reporte numérico y convocar reuniones grupales para que cada familia infiera las necesidades de apoyo."
      ],
      "correct": 0,
      "explanation": "La medida aborda directamente el hecho descrito y respeta las reglas del SIEE, los apoyos y la motivación de decisiones académicas.",
      "distractors": "B. Aunque identifica una salida posible, omite una condición sustantiva para las reglas del SIEE, los apoyos y la motivación de decisiones académicas.\n\nC. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 372,
      "originalId": 92,
      "sourceExam": 3,
      "situationId": "S3-27",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "En una revisión externa, ¿qué evidencia permitiría reconstruir con mayor rigor lo ocurrido?",
      "options": [
        "Horarios, registros de asistencia, justificaciones y comunicaciones oficiales.",
        "Horarios, registros de asistencia, planes de aula y comunicaciones oficiales, con un resumen de los antecedentes que motivaron la convocatoria de los participantes.",
        "Horarios, registros de retroalimentación, justificaciones y comunicaciones oficiales."
      ],
      "correct": 0,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de comprobar hechos, preservar debido proceso y reportar novedades documentadas a la autoridad competente.",
      "distractors": "B. Esta selección es parcial: no integra justificaciones, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra registros de asistencia, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 373,
      "originalId": 93,
      "sourceExam": 3,
      "situationId": "S3-27",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se comparan tres rutas de decisión, ¿cuál resultaría menos defendible ante una revisión de competencias y garantías?",
      "options": [
        "Comprobar hechos, preservar debido proceso y reportar novedades documentadas a la autoridad competente, con un reporte al finalizar el siguiente período institucional.",
        "Registrar las novedades según audios del coordinador y solicitar después al personal señalado que presente justificaciones.",
        "Examinar los soportes asociados a ausencia reportada de modo informal, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables."
      ],
      "correct": 1,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para las funciones del rector, la continuidad del servicio y las garantías del personal.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta las funciones del rector, la continuidad del servicio y las garantías del personal.\n\nC. La alternativa preserva un examen previo y fundamentado de ausencia reportada de modo informal antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 374,
      "originalId": 94,
      "sourceExam": 3,
      "situationId": "S3-27",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué medida permitiría valorar el resultado de la intervención sin confundir actividad con impacto?",
      "options": [
        "Novedades de personal tramitadas oportunamente con soportes, con un resumen de los antecedentes que motivaron la convocatoria de los participantes.",
        "Acuerdos pedagógicos implementados y evaluados respecto de los adoptados.",
        "Quejas encauzadas con reserva, oportunidad y protección frente a represalias, y presentar una explicación de su alcance ante los integrantes del órgano correspondiente."
      ],
      "correct": 0,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "B. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.\n\nC. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 375,
      "originalId": 95,
      "sourceExam": 3,
      "situationId": "S3-28",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué disposición es el punto de partida más específico para analizar la actuación?",
      "options": [
        "Decreto 459 de 2024, Alianza Familias-Escuela",
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes",
        "Ley 1581 de 2012, tratamiento y protección de datos personales"
      ],
      "correct": 2,
      "explanation": "Este marco se relaciona de modo más directo con la finalidad legítima, la calidad de datos y los controles de acceso. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nB. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 376,
      "originalId": 96,
      "sourceExam": 3,
      "situationId": "S3-28",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué selección de soportes dejaría el vacío probatorio más importante para justificar la decisión?",
      "options": [
        "Expediente contrastado de cámara y almacenamiento indefinido: mapa de cámaras, política de tratamiento, controles de acceso y riesgos, con índice y control de versiones.",
        "Mapa de cámaras, política de tratamiento, controles de acceso y riesgos.",
        "Mapa de cámaras, registro de acceso, controles de acceso y riesgos, bajo una programación conocida por los integrantes responsables de examinar los resultados, con anotación de las circunstancias específicas del establecimiento en la fecha de la decisión."
      ],
      "correct": 2,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nB. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de definir finalidad legítima, necesidad, acceso, retención proporcionada y comunicación transparente.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 377,
      "originalId": 97,
      "sourceExam": 3,
      "situationId": "S3-28",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Para revisar el avance dentro de un período comparable, ¿qué indicador tiene mayor pertinencia?",
      "options": [
        "Conservación proporcional y asistencia a reuniones.",
        "Errores y efectos diferenciales del modelo junto con eficacia de apoyos humanos.",
        "Incidentes atendidos con acceso justificado y conservación proporcional."
      ],
      "correct": 2,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir incidentes atendidos con acceso justificado, componente esencial del resultado propuesto.\n\nB. Considera una variable relacionada con el caso, pero deja sin medir incidentes atendidos con acceso justificado, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 378,
      "originalId": 98,
      "sourceExam": 3,
      "situationId": "S3-28",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué decisión permite atender el problema sin crear uno adicional de competencia o procedimiento?",
      "options": [
        "Definir finalidad legítima, necesidad, acceso, retención proporcionada y comunicación transparente; para atender la solicitud presentada formalmente ante la dirección de la institución.",
        "Instalar las cámaras solo en pasillos y permitir consulta de grabaciones a familias cuando exista una inquietud escolar.",
        "Conservar grabaciones durante un plazo amplio definido por el proveedor y restringir inicialmente el acceso a coordinación."
      ],
      "correct": 0,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la finalidad legítima, la calidad de datos y los controles de acceso.",
      "distractors": "B. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.\n\nC. Aunque identifica una salida posible, omite una condición sustantiva para la finalidad legítima, la calidad de datos y los controles de acceso.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 379,
      "originalId": 99,
      "sourceExam": 3,
      "situationId": "S3-29",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se audita la documentación propuesta, ¿qué expediente exigiría la mayor subsanación?",
      "options": [
        "Expediente contrastado de registro civil pendiente: declaración de situación, matrícula posible y orientaciones de la entidad territorial, con índice y control de versiones.",
        "Declaración de situación, informes de entrega y orientaciones de la entidad territorial.",
        "Declaración de situación, matrícula posible y orientaciones de la entidad territorial, con referencia explícita al contexto escolar particular que originó la controversia."
      ],
      "correct": 1,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nC. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de garantizar acceso mediante procedimientos disponibles, articular regularización documental con autoridad competente y proteger trayectoria.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 380,
      "originalId": 100,
      "sourceExam": 3,
      "situationId": "S3-29",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué iniciativa sería más difícil de justificar si se confronta con las obligaciones rectorales pertinentes?",
      "options": [
        "Garantizar acceso mediante procedimientos disponibles, articular regularización documental con autoridad competente y proteger trayectoria.",
        "Aceptar documentos provisionales para reservar el cupo y comenzar clases una vez se complete el registro de identidad; con una constancia escrita de las razones utilizadas para orientar la actuación institucional.",
        "Examinar los soportes asociados a registro civil pendiente, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables; con seguimiento documental del cambio anunciado en el proceso escolar de referencia."
      ],
      "correct": 1,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la garantía del derecho a la educación y la articulación de protección.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la garantía del derecho a la educación y la articulación de protección.\n\nC. La alternativa preserva un examen previo y fundamentado de registro civil pendiente antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 381,
      "originalId": 101,
      "sourceExam": 3,
      "situationId": "S3-29",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referente delimita de forma más directa las responsabilidades institucionales involucradas?",
      "options": [
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes",
        "Decreto 1421 de 2017, educación inclusiva y PIAR",
        "Ley 1620 de 2013 y sus rutas institucionales"
      ],
      "correct": 0,
      "explanation": "Este marco se relaciona de modo más directo con la garantía del derecho a la educación y la articulación de protección. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "B. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nC. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 382,
      "originalId": 102,
      "sourceExam": 3,
      "situationId": "S3-29",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál criterio de seguimiento refleja mejor el problema que se pretende corregir?",
      "options": [
        "Acceso oportuno a apoyos sin exposición de información sensible, junto con la constancia de revisión de las condiciones informadas por los responsables.",
        "Permanencia e integración académica sin exclusiones por procedencia, según el informe preparado por la coordinación responsable de revisar la propuesta.",
        "Días de interrupción educativa y continuidad del proceso de regularización."
      ],
      "correct": 2,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir días de interrupción educativa, componente esencial del resultado propuesto.\n\nB. Considera una variable relacionada con el caso, pero deja sin medir días de interrupción educativa, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 383,
      "originalId": 103,
      "sourceExam": 3,
      "situationId": "S3-30",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué conjunto de evidencias permitiría sustentar de manera más sólida la decisión?",
      "options": [
        "Propuestas, puntos de desacuerdo, resultados previos y condiciones del piloto, con registro de las decisiones tomadas durante el período de atención del asunto.",
        "Propuestas, entrega de llaves, resultados previos y condiciones del piloto.",
        "Propuestas, puntos de desacuerdo, partes de atención y condiciones del piloto, con una descripción de las condiciones que la rectoría consideró relevantes en este supuesto."
      ],
      "correct": 0,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de facilitar deliberación basada en evidencias, acordar piloto y definir condiciones de evaluación transparentes.",
      "distractors": "B. Esta selección es parcial: no integra puntos de desacuerdo, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra resultados previos, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 384,
      "originalId": 104,
      "sourceExam": 3,
      "situationId": "S3-30",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué curso de acción resuelve el problema central sin desbordar las atribuciones institucionales?",
      "options": [
        "Implementar dos metodologías permanentes según preferencia docente y comparar sus resultados al cierre del año académico.",
        "Seleccionar la estrategia del grupo con mejores resultados y ofrecer capacitación al otro antes de iniciar el siguiente período.",
        "Facilitar deliberación basada en evidencias, acordar piloto y definir condiciones de evaluación transparentes; con una descripción de las condiciones que la rectoría consideró relevantes en este supuesto."
      ],
      "correct": 2,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la probidad, el criterio directivo y la rendición de cuentas.",
      "distractors": "A. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.\n\nB. Aunque identifica una salida posible, omite una condición sustantiva para la probidad, el criterio directivo y la rendición de cuentas.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 385,
      "originalId": 105,
      "sourceExam": 3,
      "situationId": "S3-30",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué indicador tendría menor validez para establecer si se resolvió la necesidad institucional descrita?",
      "options": [
        "Seguimiento desagregado por período y población de: adopción informada y resultados pedagógicos comparables con línea de base.",
        "Adopción informada y resultados pedagógicos comparables con línea de base.",
        "Propuestas respondidas con motivación y participación sobre decisiones efectivamente abiertas."
      ],
      "correct": 2,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.\n\nB. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 386,
      "originalId": 106,
      "sourceExam": 3,
      "situationId": "S3-31",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué alternativa es más consistente con la responsabilidad directiva frente a los hechos?",
      "options": [
        "Articular necesidades comunes identificadas en PIAR con planeación institucional y gestión de recursos; como parte de una decisión comunicada a los equipos que resultarían directamente involucrados.",
        "Atender las solicitudes con compras puntuales y evaluar su integración al PMI en la siguiente autoevaluación institucional; para atender la solicitud presentada formalmente ante la dirección de la institución.",
        "Dejar la señalización en los PIAR individuales y priorizar recursos comunes que ya aparecen en el PMI."
      ],
      "correct": 0,
      "explanation": "La medida aborda directamente el hecho descrito y respeta el retiro de barreras y la participación educativa en igualdad de condiciones.",
      "distractors": "B. Aunque identifica una salida posible, omite una condición sustantiva para el retiro de barreras y la participación educativa en igualdad de condiciones.\n\nC. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.",
      "legalBasis": "Decreto 1421 de 2017, incorporado al Decreto 1075 de 2015"
    },
    {
      "id": 387,
      "originalId": 107,
      "sourceExam": 3,
      "situationId": "S3-31",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué combinación de documentos sería la menos adecuada para examinar las condiciones del supuesto?",
      "options": [
        "Expediente contrastado de ajustes fuera del pmi: pIAR, inspección de espacios, prioridades del PMI y factibilidad presupuestal, con índice y control de versiones, en el marco de la discusión sostenida con quienes participaron en la reunión preparatoria.",
        "PIAR, barreras de aula, prioridades del PMI y factibilidad presupuestal, con una secuencia de comunicación posterior para facilitar el seguimiento de sus efectos.",
        "PIAR, inspección de espacios, prioridades del PMI y factibilidad presupuestal."
      ],
      "correct": 1,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nC. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de articular necesidades comunes identificadas en piar con planeación institucional y gestión de recursos.",
      "legalBasis": "Decreto 1421 de 2017, incorporado al Decreto 1075 de 2015"
    },
    {
      "id": 388,
      "originalId": 108,
      "sourceExam": 3,
      "situationId": "S3-31",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué observación sería más informativa al rendir cuentas sobre este caso?",
      "options": [
        "Días de acceso efectivo y apoyos iniciados desde la vinculación, con referencia explícita al contexto escolar particular que originó la controversia.",
        "Barreras institucionales resueltas respecto de las identificadas y priorizadas.",
        "Progreso en retos de mayor complejidad y participación sostenida, con seguimiento documental del cambio anunciado en el proceso escolar de referencia."
      ],
      "correct": 1,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir barreras institucionales resueltas respecto de las identificadas, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir barreras institucionales resueltas respecto de las identificadas, componente esencial del resultado propuesto.",
      "legalBasis": "Decreto 1421 de 2017, incorporado al Decreto 1075 de 2015"
    },
    {
      "id": 389,
      "originalId": 109,
      "sourceExam": 3,
      "situationId": "S3-32",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si la rectoría debe tomar una decisión inicial motivada, ¿cuál opción es preferible?",
      "options": [
        "Aplicar una única prueba de recuperación con más tiempo disponible y ofrecer orientación general a quienes la reprueben.",
        "Diseñar apoyos diferenciados con seguimiento formativo y oportunidades pertinentes al aprendizaje.",
        "Dividir la recuperación en dos grupos según nota final, manteniendo idéntico instrumento para distintas dificultades."
      ],
      "correct": 1,
      "explanation": "La medida aborda directamente el hecho descrito y respeta las reglas del SIEE, los apoyos y la motivación de decisiones académicas.",
      "distractors": "A. Aunque identifica una salida posible, omite una condición sustantiva para las reglas del SIEE, los apoyos y la motivación de decisiones académicas.\n\nC. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 390,
      "originalId": 110,
      "sourceExam": 3,
      "situationId": "S3-32",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué selección de soportes dejaría el vacío probatorio más importante para justificar la decisión?",
      "options": [
        "Diagnóstico por competencia, planes de apoyo y registros de progreso individual, como parte de la respuesta elaborada tras la reunión del personal que participó en el análisis, en el marco de la discusión sostenida con quienes participaron en la reunión preparatoria.",
        "Diagnóstico por competencia, actividades de apoyo y registros de progreso individual.",
        "Expediente contrastado de recuperación meramente formal: diagnóstico por competencia, actividades de apoyo y registros de progreso individual, con índice y control de versiones."
      ],
      "correct": 0,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "B. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de diseñar apoyos diferenciados con seguimiento formativo y oportunidades pertinentes al aprendizaje.\n\nC. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 391,
      "originalId": 111,
      "sourceExam": 3,
      "situationId": "S3-32",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál evidencia de resultado permitiría una evaluación menos sesgada?",
      "options": [
        "Tiempo de homologación y continuidad académica sin perjuicios injustificados.",
        "Reclamaciones resueltas motivadamente en los plazos establecidos.",
        "Estudiantes que superan dificultades específicas tras apoyos pertinentes, con una secuencia de comunicación posterior para facilitar el seguimiento de sus efectos."
      ],
      "correct": 2,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.\n\nB. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 392,
      "originalId": 112,
      "sourceExam": 3,
      "situationId": "S3-32",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué disposición es el punto de partida más específico para analizar la actuación?",
      "options": [
        "Decreto 1290 de 2009, art. 11",
        "Ley 115 de 1994, objetivos, áreas y proyectos educativos",
        "Resolución MEN 003842 de 2022, gestión académica"
      ],
      "correct": 0,
      "explanation": "Este marco se relaciona de modo más directo con las reglas del SIEE, los apoyos y la motivación de decisiones académicas. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "B. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nC. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 393,
      "originalId": 113,
      "sourceExam": 3,
      "situationId": "S3-33",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál de las medidas planteadas podría producir una actuación institucional objetable por su alcance o secuencia?",
      "options": [
        "Examinar los soportes asociados a presión por mejorar ranking, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Rechazar manipulación del universo evaluado, conservar información íntegra y enfocar apoyos académicos, después de comunicar los criterios y escuchar observaciones de las familias.",
        "Aplicar el indicador solo al alumnado asistente durante la medición y publicar una nota aclaratoria sobre su alcance."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la probidad, el criterio directivo y la rendición de cuentas.",
      "distractors": "A. La alternativa preserva un examen previo y fundamentado de presión por mejorar ranking antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nB. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la probidad, el criterio directivo y la rendición de cuentas.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 394,
      "originalId": 114,
      "sourceExam": 3,
      "situationId": "S3-33",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "En una revisión externa, ¿qué evidencia permitiría reconstruir con mayor rigor lo ocurrido?",
      "options": [
        "Matrícula, criterios de selección, pruebas y series históricas completas, como parte de la respuesta elaborada tras la reunión del personal que participó en el análisis.",
        "Matrícula, criterios de selección, entrega de llaves y series históricas completas.",
        "Matrícula, criterios de priorización, pruebas y series históricas completas."
      ],
      "correct": 0,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de rechazar manipulación del universo evaluado, conservar información íntegra y enfocar apoyos académicos.",
      "distractors": "B. Esta selección es parcial: no integra pruebas, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra criterios de selección, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 395,
      "originalId": 115,
      "sourceExam": 3,
      "situationId": "S3-33",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Entre las siguientes propuestas de seguimiento, ¿cuál deja una brecha de medición más relevante?",
      "options": [
        "Indicadores representativos de toda la población pertinente y mejora real.",
        "Seguimiento desagregado por período y población de: indicadores representativos de toda la población pertinente y mejora real.",
        "Cupos asignados según reglas y sin pagos condicionantes, durante la fase de evaluación definida en el cronograma de gestión de la institución."
      ],
      "correct": 2,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.\n\nB. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 396,
      "originalId": 116,
      "sourceExam": 3,
      "situationId": "S3-33",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referente delimita de forma más directa las responsabilidades institucionales involucradas?",
      "options": [
        "Ley 715 de 2001, art. 10, dirección y seguimiento institucional",
        "Ley 115 de 1994, arts. 142-145",
        "Ley 715 de 2001, art. 10, funciones del rector"
      ],
      "correct": 0,
      "explanation": "Este marco se relaciona de modo más directo con la probidad, el criterio directivo y la rendición de cuentas. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "B. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nC. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 397,
      "originalId": 117,
      "sourceExam": 3,
      "situationId": "S3-34",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿De cuántos puntos porcentuales es la disminución entre meses?",
      "options": [
        "0,5 puntos",
        "1 punto",
        "2 puntos"
      ],
      "correct": 1,
      "explanation": "La diferencia entre 7 % y 6 % es 1 punto porcentual.",
      "distractors": "A. Confunde una magnitud con otra o realiza una agregación que altera la base de comparación.\n\nC. Corresponde a una operación o denominador distinto del definido; no coincide con los datos.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de razonamiento cuantitativo"
    },
    {
      "id": 398,
      "originalId": 118,
      "sourceExam": 3,
      "situationId": "S3-34",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál es la reducción relativa respecto de la tasa de abril?",
      "options": [
        "7,14 % aproximadamente",
        "1 % aproximadamente",
        "14,29 % aproximadamente"
      ],
      "correct": 2,
      "explanation": "(7 - 6) / 7 × 100 = 14,2857... % de reducción relativa.",
      "distractors": "A. Confunde una magnitud con otra o realiza una agregación que altera la base de comparación.\n\nB. Corresponde a una operación o denominador distinto del definido; no coincide con los datos.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de razonamiento cuantitativo"
    },
    {
      "id": 399,
      "originalId": 119,
      "sourceExam": 3,
      "situationId": "S3-34",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuáles son las tasas de ausencia de abril y mayo, respectivamente?",
      "options": [
        "7 % y 6 %",
        "7 % y 5,4 %",
        "6 % y 7 %"
      ],
      "correct": 0,
      "explanation": "140/2000 = 7 %; 108/1800 = 6 %. Cada período tiene su propio denominador.",
      "distractors": "B. Corresponde a una operación o denominador distinto del definido; no coincide con los datos.\n\nC. Confunde una magnitud con otra o realiza una agregación que altera la base de comparación.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de razonamiento cuantitativo"
    },
    {
      "id": 400,
      "originalId": 120,
      "sourceExam": 3,
      "situationId": "S3-35",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué combinación de documentos sería la menos adecuada para examinar las condiciones del supuesto?",
      "options": [
        "Intensidades horarias, plan de estudios, resultados y necesidades académicas, junto con la constancia de revisión de las condiciones informadas por los responsables.",
        "Intensidades horarias, planes de área, resultados y necesidades académicas.",
        "Expediente contrastado de educación artística residual: intensidades horarias, plan de estudios, resultados y necesidades académicas, con índice y control de versiones."
      ],
      "correct": 1,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de proteger integralidad del plan de estudios y revisar estrategias de refuerzo compatibles con áreas obligatorias.\n\nC. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 401,
      "originalId": 121,
      "sourceExam": 3,
      "situationId": "S3-35",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "De las siguientes actuaciones, ¿cuál requeriría una corrección prioritaria por comprometer el procedimiento o la garantía central del caso?",
      "options": [
        "Proteger integralidad del plan de estudios y revisar estrategias de refuerzo compatibles con áreas obligatorias.",
        "Reasignar parcialmente horas de arte a refuerzos evaluados y compensar luego mediante un evento artístico institucional; con un resumen de los antecedentes que motivaron la convocatoria de los participantes.",
        "Examinar los soportes asociados a educación artística residual, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables."
      ],
      "correct": 1,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la integralidad curricular y la función pedagógica institucional.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la integralidad curricular y la función pedagógica institucional.\n\nC. La alternativa preserva un examen previo y fundamentado de educación artística residual antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 402,
      "originalId": 122,
      "sourceExam": 3,
      "situationId": "S3-35",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referencia normativa conviene revisar primero por su relación directa con el caso?",
      "options": [
        "Decreto 1290 de 2009, art. 11",
        "Resolución MEN 003842 de 2022, gestión académica",
        "Ley 115 de 1994, objetivos, áreas y proyectos educativos"
      ],
      "correct": 2,
      "explanation": "Este marco se relaciona de modo más directo con la integralidad curricular y la función pedagógica institucional. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nB. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 403,
      "originalId": 123,
      "sourceExam": 3,
      "situationId": "S3-35",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál criterio de seguimiento refleja mejor el problema que se pretende corregir?",
      "options": [
        "Progresión de desempeños comunicativos por ciclo y grado, como parte de una decisión comunicada a los equipos que resultarían directamente involucrados.",
        "Aprendizajes pertinentes y acceso a información formativa ajustada a edad, para atender la solicitud presentada formalmente ante la dirección de la institución.",
        "Cobertura curricular integral y mejoras de competencias sin desplazar áreas."
      ],
      "correct": 2,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir cobertura curricular integral, componente esencial del resultado propuesto.\n\nB. Considera una variable relacionada con el caso, pero deja sin medir cobertura curricular integral, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 404,
      "originalId": 124,
      "sourceExam": 3,
      "situationId": "S3-36",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué disposición es el punto de partida más específico para analizar la actuación?",
      "options": [
        "Ley 715 de 2001, art. 10",
        "Resolución MEN 003842 de 2022, gestión académica",
        "Ley 115 de 1994, arts. 142-145"
      ],
      "correct": 0,
      "explanation": "Este marco se relaciona de modo más directo con la coherencia entre diagnóstico, metas, ejecución y evidencia. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "B. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nC. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 405,
      "originalId": 125,
      "sourceExam": 3,
      "situationId": "S3-36",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué medida sería menos adecuada como indicador principal para rendir cuentas sobre el resultado específico del caso?",
      "options": [
        "Proporción de juicios institucionales respaldados por evidencias pertinentes.",
        "Seguimiento desagregado por período y población de: coincidencia entre datos primarios, porcentajes publicados y conclusiones institucionales.",
        "Coincidencia entre datos primarios, porcentajes publicados y conclusiones institucionales."
      ],
      "correct": 0,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "B. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.\n\nC. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 406,
      "originalId": 126,
      "sourceExam": 3,
      "situationId": "S3-36",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué selección de soportes dejaría el vacío probatorio más importante para justificar la decisión?",
      "options": [
        "Bases originales, fórmula utilizada, cortes comparados y versión del informe.",
        "Expediente contrastado de informe con cifras incompatibles: bases originales, fórmula utilizada, cortes comparados y versión del informe, con índice y control de versiones.",
        "Bases originales, definiciones previas del indicador, cortes comparados y versión del informe."
      ],
      "correct": 2,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de depurar la consistencia aritmética e identificar si se habla de crecimiento relativo o puntos porcentuales.\n\nB. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 407,
      "originalId": 127,
      "sourceExam": 3,
      "situationId": "S3-36",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué decisión permite atender el problema sin crear uno adicional de competencia o procedimiento?",
      "options": [
        "Depurar la consistencia aritmética e identificar si se habla de crecimiento relativo o puntos porcentuales; para atender la solicitud presentada formalmente ante la dirección de la institución.",
        "Presentar el cálculo más favorable como dato principal y anexar los registros primarios para una eventual revisión externa.",
        "Conservar el porcentaje divulgado y añadir una nota metodológica que explique la diferencia respecto de la tabla original."
      ],
      "correct": 0,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la coherencia entre diagnóstico, metas, ejecución y evidencia.",
      "distractors": "B. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.\n\nC. Aunque identifica una salida posible, omite una condición sustantiva para la coherencia entre diagnóstico, metas, ejecución y evidencia.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 408,
      "originalId": 128,
      "sourceExam": 3,
      "situationId": "S3-37",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se comparan tres rutas de decisión, ¿cuál resultaría menos defendible ante una revisión de competencias y garantías?",
      "options": [
        "Documentar el interés particular, activar los mecanismos de impedimento aplicables y tramitar la decisión con transparencia, junto con una revisión administrativa de tareas y tiempos de implementación.",
        "Examinar los soportes asociados a conflicto de interés en el consejo, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Registrar el vínculo del proponente y permitirle intervenir en la comparación técnica, reservando la votación a otros consejeros; con una comunicación dirigida a los actores mencionados en el expediente institucional."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para el reparto de competencias y la participación válida del gobierno escolar.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta el reparto de competencias y la participación válida del gobierno escolar.\n\nB. La alternativa preserva un examen previo y fundamentado de conflicto de interés en el consejo antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Ley 715 de 2001, art. 10"
    },
    {
      "id": 409,
      "originalId": 129,
      "sourceExam": 3,
      "situationId": "S3-37",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Antes de cerrar el análisis, ¿qué información resulta más decisiva para contrastar las afirmaciones?",
      "options": [
        "Declaración del vínculo, actas, ofertas comparables y reglas de selección aplicables, según el informe preparado por la coordinación responsable de revisar la propuesta.",
        "Declaración del vínculo, reglas de representación, ofertas comparables y reglas de selección aplicables.",
        "Declaración del vínculo, actas, evaluación de riesgos del convenio y reglas de selección aplicables."
      ],
      "correct": 0,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de documentar el interés particular, activar los mecanismos de impedimento aplicables y tramitar la decisión con transparencia.",
      "distractors": "B. Esta selección es parcial: no integra actas, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra ofertas comparables, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Ley 715 de 2001, art. 10"
    },
    {
      "id": 410,
      "originalId": 130,
      "sourceExam": 3,
      "situationId": "S3-37",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Entre las siguientes propuestas de seguimiento, ¿cuál deja una brecha de medición más relevante?",
      "options": [
        "Proporción de acuerdos adoptados con soporte de quórum y seguimiento de ejecución.",
        "Decisiones de contratación con trazabilidad de conflictos declarados y tratamiento documentado.",
        "Seguimiento desagregado por período y población de: decisiones de contratación con trazabilidad de conflictos declarados y tratamiento documentado."
      ],
      "correct": 0,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "B. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.\n\nC. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Ley 715 de 2001, art. 10"
    },
    {
      "id": 411,
      "originalId": 131,
      "sourceExam": 3,
      "situationId": "S3-38",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál evidencia de resultado permitiría una evaluación menos sesgada?",
      "options": [
        "Quejas encauzadas con reserva, oportunidad y protección frente a represalias.",
        "Horas curriculares efectivas y distribución equitativa de cargas.",
        "Acuerdos pedagógicos implementados y evaluados respecto de los adoptados."
      ],
      "correct": 1,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir horas curriculares efectivas, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir horas curriculares efectivas, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 412,
      "originalId": 132,
      "sourceExam": 3,
      "situationId": "S3-38",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué curso de acción resuelve el problema central sin desbordar las atribuciones institucionales?",
      "options": [
        "Revisar criterios de cobertura curricular, equidad de grupos y condiciones laborales antes de distribuir horarios; con una descripción de las condiciones que la rectoría consideró relevantes en este supuesto.",
        "Reorganizar horarios según disponibilidad de docentes y ajustar después las horas de estudiantes con más interrupciones.",
        "Mantener la asignación por antigüedad y negociar redistribuciones solo con quienes presenten reclamaciones formales, con un cronograma de ejecución conocido por las instancias participantes; según el informe preparado por la coordinación responsable de revisar la propuesta."
      ],
      "correct": 0,
      "explanation": "La medida aborda directamente el hecho descrito y respeta las funciones del rector, la continuidad del servicio y las garantías del personal.",
      "distractors": "B. Aunque identifica una salida posible, omite una condición sustantiva para las funciones del rector, la continuidad del servicio y las garantías del personal.\n\nC. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 413,
      "originalId": 133,
      "sourceExam": 3,
      "situationId": "S3-38",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál conjunto documental permitiría una conclusión menos sólida sobre la actuación?",
      "options": [
        "Expediente contrastado de conflicto de horarios: intensidad de áreas, jornadas, perfiles, trayectos y restricciones institucionales, con índice y control de versiones.",
        "Intensidad de áreas, planes de aula, perfiles, trayectos y restricciones institucionales, con un resumen de los antecedentes que motivaron la convocatoria de los participantes.",
        "Intensidad de áreas, jornadas, perfiles, trayectos y restricciones institucionales."
      ],
      "correct": 1,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nC. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de revisar criterios de cobertura curricular, equidad de grupos y condiciones laborales antes de distribuir horarios.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 414,
      "originalId": 134,
      "sourceExam": 3,
      "situationId": "S3-39",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué iniciativa sería más difícil de justificar si se confronta con las obligaciones rectorales pertinentes?",
      "options": [
        "Formalizar responsabilidades, supervisión, consentimiento procedente y límites de acceso a información, con un registro de compromisos para la siguiente reunión del Consejo.",
        "Permitir prácticas en casos seleccionados bajo supervisión informal, mientras se tramitan convenio y autorizaciones durante el semestre; con registro de las decisiones tomadas durante el período de atención del asunto.",
        "Examinar los soportes asociados a alianza universidad sin rol definido, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables; con una descripción de las condiciones que la rectoría consideró relevantes en este supuesto."
      ],
      "correct": 1,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la participación significativa, la accesibilidad y el diálogo territorial.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la participación significativa, la accesibilidad y el diálogo territorial.\n\nC. La alternativa preserva un examen previo y fundamentado de alianza universidad sin rol definido antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 415,
      "originalId": 135,
      "sourceExam": 3,
      "situationId": "S3-39",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "En una revisión externa, ¿qué evidencia permitiría reconstruir con mayor rigor lo ocurrido?",
      "options": [
        "Convenio, plan formativo, seguros, planes de área y reglas de protección de información.",
        "Convenio, plan formativo, seguros, autorizaciones y reglas de protección de información, y presentar una explicación de su alcance ante los integrantes del órgano correspondiente.",
        "Convenio, criterios de tratamiento de información, seguros, autorizaciones y reglas de protección de información, con una secuencia de comunicación posterior para facilitar el seguimiento de sus efectos."
      ],
      "correct": 1,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de formalizar responsabilidades, supervisión, consentimiento procedente y límites de acceso a información.",
      "distractors": "A. Esta selección es parcial: no integra autorizaciones, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra plan formativo, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 416,
      "originalId": 136,
      "sourceExam": 3,
      "situationId": "S3-39",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referencia normativa conviene revisar primero por su relación directa con el caso?",
      "options": [
        "Decreto 459 de 2024, Alianza Familias-Escuela",
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes",
        "Ley 115 de 1994, arts. 142-145"
      ],
      "correct": 0,
      "explanation": "Este marco se relaciona de modo más directo con la participación significativa, la accesibilidad y el diálogo territorial. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "B. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nC. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 417,
      "originalId": 137,
      "sourceExam": 3,
      "situationId": "S3-39",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál formulación introduce la limitación más importante al evaluar el resultado y no solo la gestión?",
      "options": [
        "Seguimiento desagregado por período y población de: prácticas con supervisión, cobertura de riesgos y tratamiento legítimo de datos, según el informe preparado por la coordinación responsable de revisar la propuesta.",
        "Prácticas con supervisión, cobertura de riesgos y tratamiento legítimo de datos.",
        "Participación sostenida por barreras territoriales y tipo de familia, con una descripción de las condiciones que la rectoría consideró relevantes en este supuesto."
      ],
      "correct": 2,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.\n\nB. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 418,
      "originalId": 138,
      "sourceExam": 3,
      "situationId": "S3-40",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Para revisar el avance dentro de un período comparable, ¿qué indicador tiene mayor pertinencia?",
      "options": [
        "Reincidencias, percepción de seguridad y cumplimiento de medidas acordadas.",
        "Tiempo de activación de protección y cumplimiento de medidas de seguimiento.",
        "Solicitudes resueltas con justificación y protección de datos sensibles, según el informe preparado por la coordinación responsable de revisar la propuesta."
      ],
      "correct": 2,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir solicitudes resueltas con justificación, componente esencial del resultado propuesto.\n\nB. Considera una variable relacionada con el caso, pero deja sin medir solicitudes resueltas con justificación, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 419,
      "originalId": 139,
      "sourceExam": 3,
      "situationId": "S3-40",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "De las siguientes actuaciones, ¿cuál requeriría una corrección prioritaria por comprometer el procedimiento o la garantía central del caso?",
      "options": [
        "Entregar extractos de las notas clínicas al acudiente solicitante y ocultar únicamente los nombres de terceros.",
        "Examinar los soportes asociados a confidencialidad del orientador, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Proteger la información sensible, comunicar actuaciones procedentes y compartir solo lo autorizado y necesario, con una verificación posterior de costos y resultados administrativos."
      ],
      "correct": 0,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la protección de derechos, los procedimientos y la reserva de información.",
      "distractors": "B. La alternativa preserva un examen previo y fundamentado de confidencialidad del orientador antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nC. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la protección de derechos, los procedimientos y la reserva de información.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 420,
      "originalId": 140,
      "sourceExam": 3,
      "situationId": "S3-40",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué fuentes deberían triangularse para reducir el riesgo de una conclusión apresurada?",
      "options": [
        "Alcance de la solicitud, seguimiento de las partes y derechos de las personas involucradas.",
        "Alcance de la solicitud, naturaleza de datos y derechos de las personas involucradas.",
        "Alcance de la solicitud, justificación pedagógica de la regla y derechos de las personas involucradas."
      ],
      "correct": 1,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de proteger la información sensible, comunicar actuaciones procedentes y compartir solo lo autorizado y necesario.",
      "distractors": "A. Esta selección es parcial: no integra naturaleza de datos, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra naturaleza de datos, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 421,
      "originalId": 1,
      "sourceExam": 4,
      "situationId": "S4-01",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se audita la documentación propuesta, ¿qué expediente exigiría la mayor subsanación?",
      "options": [
        "Líneas de base por sede, planes de área y riesgos asociados a la inacción.",
        "Líneas de base por sede, costos de alternativas y riesgos asociados a la inacción.",
        "Expediente contrastado de dos sedes y una prioridad: líneas de base por sede, costos de alternativas y riesgos asociados a la inacción, con índice y control de versiones."
      ],
      "correct": 0,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "B. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de priorizar con criterios explícitos de gravedad, equidad, factibilidad e impacto, justificando la decisión ante la comunidad.\n\nC. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 422,
      "originalId": 2,
      "sourceExam": 4,
      "situationId": "S4-01",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué respuesta preserva mejor las garantías comprometidas en el caso?",
      "options": [
        "Distribuir recursos a ambas sedes en proporción a matrícula, dejando para otro momento la valoración de riesgos específicos.",
        "Financiar primero la sede con más estudiantes atendidos y reservar una evaluación del impacto para decidir ajustes posteriores; con una comunicación dirigida a los actores mencionados en el expediente institucional.",
        "Priorizar con criterios explícitos de gravedad, equidad, factibilidad e impacto, justificando la decisión ante la comunidad; con registro de las decisiones tomadas durante el período de atención del asunto."
      ],
      "correct": 2,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la coherencia entre diagnóstico, metas, ejecución y evidencia.",
      "distractors": "A. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.\n\nB. Aunque identifica una salida posible, omite una condición sustantiva para la coherencia entre diagnóstico, metas, ejecución y evidencia.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 423,
      "originalId": 3,
      "sourceExam": 4,
      "situationId": "S4-01",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Para revisar el avance dentro de un período comparable, ¿qué indicador tiene mayor pertinencia?",
      "options": [
        "Proporción de juicios institucionales respaldados por evidencias pertinentes, con una comunicación dirigida a los actores mencionados en el expediente institucional.",
        "Acciones cumplidas dentro del plazo y con evidencia sobre el total programado, con una descripción de las condiciones que la rectoría consideró relevantes en este supuesto.",
        "Reducción de brechas de permanencia o aprendizaje según la prioridad formalmente definida."
      ],
      "correct": 2,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.\n\nB. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 424,
      "originalId": 4,
      "sourceExam": 4,
      "situationId": "S4-02",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál propuesta es jurídicamente y pedagógicamente más defendible?",
      "options": [
        "Aprobar ascensos por recomendación unánime de docentes del grupo y comunicar luego al Consejo Directivo; y presentar una explicación de su alcance ante los integrantes del órgano correspondiente.",
        "Autorizar promoción anticipada para quienes obtengan alto puntaje en prueba única, previa entrevista con sus acudientes.",
        "Aplicar criterios y procedimiento del SIEE, valoración integral y decisiones de los órganos competentes."
      ],
      "correct": 2,
      "explanation": "La medida aborda directamente el hecho descrito y respeta las reglas del SIEE, los apoyos y la motivación de decisiones académicas.",
      "distractors": "A. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.\n\nB. Aunque identifica una salida posible, omite una condición sustantiva para las reglas del SIEE, los apoyos y la motivación de decisiones académicas.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 425,
      "originalId": 5,
      "sourceExam": 4,
      "situationId": "S4-02",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál conjunto documental permitiría una conclusión menos sólida sobre la actuación?",
      "options": [
        "SIEE, actas competentes, solicitudes, actas y recomendaciones pertinentes, con registro de las decisiones tomadas durante el período de atención del asunto.",
        "Expediente contrastado de promoción anticipada confundida: sIEE, desempeño integral, solicitudes, actas y recomendaciones pertinentes, con índice y control de versiones.",
        "SIEE, desempeño integral, solicitudes, actas y recomendaciones pertinentes."
      ],
      "correct": 0,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "B. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nC. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de aplicar criterios y procedimiento del siee, valoración integral y decisiones de los órganos competentes.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 426,
      "originalId": 6,
      "sourceExam": 4,
      "situationId": "S4-02",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué indicador tendría menor validez para establecer si se resolvió la necesidad institucional descrita?",
      "options": [
        "Familias que comprenden el avance y conocen acciones concretas de acompañamiento.",
        "Promociones anticipadas con cumplimiento documentado del procedimiento.",
        "Seguimiento desagregado por período y población de: promociones anticipadas con cumplimiento documentado del procedimiento."
      ],
      "correct": 0,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "B. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.\n\nC. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 427,
      "originalId": 7,
      "sourceExam": 4,
      "situationId": "S4-02",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referencia normativa conviene revisar primero por su relación directa con el caso?",
      "options": [
        "Resolución MEN 003842 de 2022, gestión académica",
        "Decreto 1290 de 2009, art. 11",
        "Ley 115 de 1994, objetivos, áreas y proyectos educativos"
      ],
      "correct": 1,
      "explanation": "Este marco se relaciona de modo más directo con las reglas del SIEE, los apoyos y la motivación de decisiones académicas. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nC. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 428,
      "originalId": 8,
      "sourceExam": 4,
      "situationId": "S4-03",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué decisión permite atender el problema sin crear uno adicional de competencia o procedimiento?",
      "options": [
        "Registrar públicamente niveles anónimos por curso y decidir intervenciones a partir de esas categorías agregadas.",
        "Aplicar una lista de riesgo de uso exclusivo docente y solicitar apoyos clínicos solo a los grupos con puntuación más alta.",
        "Sustituir etiquetas públicas por rutas confidenciales, profesionales competentes y apoyos escolares no estigmatizantes."
      ],
      "correct": 2,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la garantía del derecho a la educación y la articulación de protección.",
      "distractors": "A. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.\n\nB. Aunque identifica una salida posible, omite una condición sustantiva para la garantía del derecho a la educación y la articulación de protección.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 429,
      "originalId": 9,
      "sourceExam": 4,
      "situationId": "S4-03",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál formulación introduce la limitación más importante al evaluar el resultado y no solo la gestión?",
      "options": [
        "Seguimiento desagregado por período y población de: acceso oportuno a apoyos sin exposición de información sensible.",
        "Acceso oportuno a apoyos sin exposición de información sensible.",
        "Protección activada oportunamente y seguimiento articulado sin revictimización."
      ],
      "correct": 2,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.\n\nB. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 430,
      "originalId": 10,
      "sourceExam": 4,
      "situationId": "S4-03",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué combinación de documentos sería la menos adecuada para examinar las condiciones del supuesto?",
      "options": [
        "Expediente contrastado de salud mental y estigmas: finalidad del taller, competencias del equipo, consentimientos y medidas de protección, con índice y control de versiones, con una comunicación dirigida a los actores mencionados en el expediente institucional.",
        "Finalidad del taller, competencias del equipo, consentimientos y medidas de protección.",
        "Finalidad del taller, actuaciones de protección, consentimientos y medidas de protección, para que el equipo responsable conozca los efectos esperados y los pasos anunciados."
      ],
      "correct": 2,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nB. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de sustituir etiquetas públicas por rutas confidenciales, profesionales competentes y apoyos escolares no estigmatizantes.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 431,
      "originalId": 11,
      "sourceExam": 4,
      "situationId": "S4-04",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué conjunto de evidencias permitiría sustentar de manera más sólida la decisión?",
      "options": [
        "Aforo certificado, rutas, roles, fotos y antecedentes del espacio.",
        "Aforo certificado, rutas, roles, permisos y antecedentes del espacio, para atender la solicitud presentada formalmente ante la dirección de la institución.",
        "Aforo certificado, registro del incidente, roles, permisos y antecedentes del espacio."
      ],
      "correct": 1,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de ajustar aforo y logística, comprobar medidas de emergencia y autorizar solo condiciones seguras.",
      "distractors": "A. Esta selección es parcial: no integra permisos, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra rutas, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 432,
      "originalId": 12,
      "sourceExam": 4,
      "situationId": "S4-04",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Ante la situación descrita, ¿cuál actuación del rector constituye la respuesta mejor fundada?",
      "options": [
        "Ajustar aforo y logística, comprobar medidas de emergencia y autorizar solo condiciones seguras; con registro de las decisiones tomadas durante el período de atención del asunto.",
        "Mantener el aforo previsto y ampliar el número de brigadistas, tomando la asistencia real como dato para eventos posteriores.",
        "Dividir el público en dos horarios sin valorar nuevamente capacidad de salidas y seguridad de las instalaciones."
      ],
      "correct": 0,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la prevención, la protección de personas y la continuidad segura del servicio.",
      "distractors": "B. Aunque identifica una salida posible, omite una condición sustantiva para la prevención, la protección de personas y la continuidad segura del servicio.\n\nC. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 433,
      "originalId": 13,
      "sourceExam": 4,
      "situationId": "S4-04",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué observación sería más informativa al rendir cuentas sobre este caso?",
      "options": [
        "Condiciones de seguridad verificadas y tiempos de respuesta ante contingencias.",
        "Tiempo y seguridad de evacuación de toda la población, desagregados por necesidades.",
        "Cumplimiento del aforo seguro y capacidad de respuesta en los eventos, bajo una programación conocida por los integrantes responsables de examinar los resultados."
      ],
      "correct": 2,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir cumplimiento del aforo seguro, componente esencial del resultado propuesto.\n\nB. Considera una variable relacionada con el caso, pero deja sin medir cumplimiento del aforo seguro, componente esencial del resultado propuesto.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 434,
      "originalId": 14,
      "sourceExam": 4,
      "situationId": "S4-04",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referente delimita de forma más directa las responsabilidades institucionales involucradas?",
      "options": [
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes",
        "Ley 715 de 2001, art. 10, funciones del rector",
        "Resolución MEN 003842 de 2022, gestión institucional y recursos"
      ],
      "correct": 2,
      "explanation": "Este marco se relaciona de modo más directo con la prevención, la protección de personas y la continuidad segura del servicio. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nB. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 435,
      "originalId": 15,
      "sourceExam": 4,
      "situationId": "S4-05",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "De las siguientes actuaciones, ¿cuál requeriría una corrección prioritaria por comprometer el procedimiento o la garantía central del caso?",
      "options": [
        "Examinar los soportes asociados a anticipo sin soporte, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Gestionar desembolso parcial contra una carta de compromiso y exigir las garantías definitivas al recibir la primera entrega; con una comunicación dirigida a los actores mencionados en el expediente institucional.",
        "Verificar condiciones contractuales, apropiación, garantías y requisitos aplicables antes de comprometer desembolsos, con acta de socialización y seguimiento por el equipo académico; con una descripción de las condiciones que la rectoría consideró relevantes en este supuesto."
      ],
      "correct": 1,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la autorización presupuestal, el control y la destinación de recursos públicos.",
      "distractors": "A. La alternativa preserva un examen previo y fundamentado de anticipo sin soporte antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nC. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la autorización presupuestal, el control y la destinación de recursos públicos.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 436,
      "originalId": 16,
      "sourceExam": 4,
      "situationId": "S4-05",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Para orientar la motivación jurídica inicial, ¿qué marco ofrece la conexión más pertinente con los hechos?",
      "options": [
        "Ley 715 de 2001, art. 10, funciones del rector",
        "Decreto 1075 de 2015, sección del Fondo de Servicios Educativos",
        "Ley 115 de 1994, arts. 142-145"
      ],
      "correct": 1,
      "explanation": "Este marco se relaciona de modo más directo con la autorización presupuestal, el control y la destinación de recursos públicos. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nC. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 437,
      "originalId": 17,
      "sourceExam": 4,
      "situationId": "S4-05",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se audita la documentación propuesta, ¿qué expediente exigiría la mayor subsanación?",
      "options": [
        "Pliego o condiciones, rubros, disponibilidad, garantías exigibles y comprobantes.",
        "Expediente contrastado de anticipo sin soporte: pliego o condiciones, contrato, disponibilidad, garantías exigibles y comprobantes, con índice y control de versiones.",
        "Pliego o condiciones, contrato, disponibilidad, garantías exigibles y comprobantes, con registro de las decisiones tomadas durante el período de atención del asunto."
      ],
      "correct": 0,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "B. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nC. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de verificar condiciones contractuales, apropiación, garantías y requisitos aplicables antes de comprometer desembolsos.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 438,
      "originalId": 18,
      "sourceExam": 4,
      "situationId": "S4-05",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Entre las siguientes propuestas de seguimiento, ¿cuál deja una brecha de medición más relevante?",
      "options": [
        "Pagos que cumplen condiciones pactadas y respaldos de ejecución.",
        "Seguimiento desagregado por período y población de: pagos que cumplen condiciones pactadas y respaldos de ejecución.",
        "Costo total por estudiante beneficiado y continuidad efectiva del recurso."
      ],
      "correct": 2,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.\n\nB. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 439,
      "originalId": 19,
      "sourceExam": 4,
      "situationId": "S4-06",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué propuesta presenta el riesgo institucional más grave, a pesar de sus aparentes ventajas operativas?",
      "options": [
        "Atender contingencia, actualizar controles y verificar capacidad de respuesta antes de reanudar prácticas, después de comunicar los criterios y escuchar observaciones de las familias.",
        "Reponer extintores y reanudar experimentos durante la revisión de los demás controles de almacenamiento y seguridad.",
        "Examinar los soportes asociados a incendio en laboratorio, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables."
      ],
      "correct": 1,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la prevención, la protección de personas y la continuidad segura del servicio.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la prevención, la protección de personas y la continuidad segura del servicio.\n\nC. La alternativa preserva un examen previo y fundamentado de incendio en laboratorio antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 440,
      "originalId": 20,
      "sourceExam": 4,
      "situationId": "S4-06",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referencia normativa conviene revisar primero por su relación directa con el caso?",
      "options": [
        "Resolución MEN 003842 de 2022, gestión institucional y recursos",
        "Ley 715 de 2001, art. 10, funciones del rector",
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes"
      ],
      "correct": 0,
      "explanation": "Este marco se relaciona de modo más directo con la prevención, la protección de personas y la continuidad segura del servicio. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "B. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nC. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 441,
      "originalId": 21,
      "sourceExam": 4,
      "situationId": "S4-06",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál conjunto documental permitiría una conclusión menos sólida sobre la actuación?",
      "options": [
        "Registro del incidente, reportes de ruta, equipos contra incendio y análisis de riesgo.",
        "Registro del incidente, inventario, equipos contra incendio y análisis de riesgo.",
        "Expediente contrastado de incendio en laboratorio: registro del incidente, inventario, equipos contra incendio y análisis de riesgo, con índice y control de versiones."
      ],
      "correct": 0,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "B. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de atender contingencia, actualizar controles y verificar capacidad de respuesta antes de reanudar prácticas.\n\nC. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 442,
      "originalId": 22,
      "sourceExam": 4,
      "situationId": "S4-06",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué medida permitiría valorar el resultado de la intervención sin confundir actividad con impacto?",
      "options": [
        "Días de servicio seguro, continuidad pedagógica y pérdidas evitadas.",
        "Condiciones de seguridad verificadas y tiempos de respuesta ante contingencias.",
        "Condiciones de seguridad verificadas y cumplimiento del calendario de gestión, y presentar una explicación de su alcance ante los integrantes del órgano correspondiente."
      ],
      "correct": 1,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir condiciones de seguridad verificadas, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir tiempos de respuesta ante contingencias, componente esencial del resultado propuesto.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 443,
      "originalId": 23,
      "sourceExam": 4,
      "situationId": "S4-07",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se comparan tres rutas de decisión, ¿cuál resultaría menos defendible ante una revisión de competencias y garantías?",
      "options": [
        "Conciliar contrato, recibidos e inventario, investigar diferencias y activar controles y reportes pertinentes, después de revisar el calendario de trabajo de cada coordinación.",
        "Examinar los soportes asociados a inventario que no coincide, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Registrar los diecisiete equipos localizados y considerar pendientes los restantes hasta el siguiente inventario anual."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la autorización presupuestal, el control y la destinación de recursos públicos.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la autorización presupuestal, el control y la destinación de recursos públicos.\n\nB. La alternativa preserva un examen previo y fundamentado de inventario que no coincide antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 444,
      "originalId": 24,
      "sourceExam": 4,
      "situationId": "S4-07",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué disposición es el punto de partida más específico para analizar la actuación?",
      "options": [
        "Ley 715 de 2001, art. 10, funciones del rector",
        "Decreto 1075 de 2015, sección del Fondo de Servicios Educativos",
        "Ley 115 de 1994, arts. 142-145"
      ],
      "correct": 1,
      "explanation": "Este marco se relaciona de modo más directo con la autorización presupuestal, el control y la destinación de recursos públicos. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nC. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 445,
      "originalId": 25,
      "sourceExam": 4,
      "situationId": "S4-07",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Para revisar el avance dentro de un período comparable, ¿qué indicador tiene mayor pertinencia?",
      "options": [
        "Diferencias de inventario resueltas y bienes rastreables por responsable, con una constancia escrita de las razones utilizadas para orientar la actuación institucional.",
        "Pagos que cumplen condiciones pactadas y respaldos de ejecución.",
        "Procesos ejecutados conforme a cuantías reales y reglas de publicidad."
      ],
      "correct": 0,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "B. Considera una variable relacionada con el caso, pero deja sin medir diferencias de inventario resueltas, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir diferencias de inventario resueltas, componente esencial del resultado propuesto.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 446,
      "originalId": 26,
      "sourceExam": 4,
      "situationId": "S4-07",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "En una revisión externa, ¿qué evidencia permitiría reconstruir con mayor rigor lo ocurrido?",
      "options": [
        "Órdenes, actas de recibo, seriales, responsables de custodia y conteo físico, con indicación del período al que se refiere la propuesta de actuación y sus consecuencias.",
        "Órdenes, actas de recibo, seriales, flujo de caja y conteo físico.",
        "Órdenes, actas de entrega, seriales, responsables de custodia y conteo físico."
      ],
      "correct": 0,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de conciliar contrato, recibidos e inventario, investigar diferencias y activar controles y reportes pertinentes.",
      "distractors": "B. Esta selección es parcial: no integra responsables de custodia, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra actas de recibo, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 447,
      "originalId": 27,
      "sourceExam": 4,
      "situationId": "S4-08",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál de las medidas planteadas podría producir una actuación institucional objetable por su alcance o secuencia?",
      "options": [
        "Rediseñar la actividad con accesibilidad, apoyos y objetivos de aprendizaje equivalentes para todos; junto con la constancia de revisión de las condiciones informadas por los responsables.",
        "Examinar los soportes asociados a excursión sin accesibilidad, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Mantener el destino y ofrecer actividades equivalentes dentro de la sede a quienes no puedan acceder al sendero."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para el retiro de barreras y la participación educativa en igualdad de condiciones.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta el retiro de barreras y la participación educativa en igualdad de condiciones.\n\nB. La alternativa preserva un examen previo y fundamentado de excursión sin accesibilidad antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Decreto 1421 de 2017, incorporado al Decreto 1075 de 2015"
    },
    {
      "id": 448,
      "originalId": 28,
      "sourceExam": 4,
      "situationId": "S4-08",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál criterio de seguimiento refleja mejor el problema que se pretende corregir?",
      "options": [
        "Progreso en retos de mayor complejidad y participación sostenida.",
        "Participación en experiencias equivalentes sin exclusiones por barreras de acceso.",
        "Días de acceso efectivo y apoyos iniciados desde la vinculación."
      ],
      "correct": 1,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.\n\nC. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.",
      "legalBasis": "Decreto 1421 de 2017, incorporado al Decreto 1075 de 2015"
    },
    {
      "id": 449,
      "originalId": 29,
      "sourceExam": 4,
      "situationId": "S4-08",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué selección de soportes dejaría el vacío probatorio más importante para justificar la decisión?",
      "options": [
        "Barreras del itinerario, barreras de aula y alternativas técnicas disponibles.",
        "Barreras del itinerario, objetivos curriculares y alternativas técnicas disponibles.",
        "Expediente contrastado de excursión sin accesibilidad: barreras del itinerario, objetivos curriculares y alternativas técnicas disponibles, con índice y control de versiones."
      ],
      "correct": 0,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "B. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de rediseñar la actividad con accesibilidad, apoyos y objetivos de aprendizaje equivalentes para todos.\n\nC. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.",
      "legalBasis": "Decreto 1421 de 2017, incorporado al Decreto 1075 de 2015"
    },
    {
      "id": 450,
      "originalId": 30,
      "sourceExam": 4,
      "situationId": "S4-09",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué iniciativa sería más difícil de justificar si se confronta con las obligaciones rectorales pertinentes?",
      "options": [
        "Definir ámbitos reales de decisión, restricciones y mecanismos de devolución de propuestas, previa evaluación de viabilidad por el grupo directivo de la institución.",
        "Mantener abierta la consulta y seleccionar después propuestas viables, sin explicar de antemano qué rubros tienen recursos comprometidos.",
        "Examinar los soportes asociados a participación aparente, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables."
      ],
      "correct": 1,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la probidad, el criterio directivo y la rendición de cuentas.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la probidad, el criterio directivo y la rendición de cuentas.\n\nC. La alternativa preserva un examen previo y fundamentado de participación aparente antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 451,
      "originalId": 31,
      "sourceExam": 4,
      "situationId": "S4-09",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cómo debería operacionalizarse el resultado esperado en el plan de seguimiento?",
      "options": [
        "Cupos asignados según reglas y sin pagos condicionantes.",
        "Comunicaciones oportunas, precisas y respetuosas de privacidad.",
        "Propuestas respondidas con motivación y participación sobre decisiones efectivamente abiertas."
      ],
      "correct": 2,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir propuestas respondidas con motivación, componente esencial del resultado propuesto.\n\nB. Considera una variable relacionada con el caso, pero deja sin medir propuestas respondidas con motivación, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 452,
      "originalId": 32,
      "sourceExam": 4,
      "situationId": "S4-09",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué expediente sería más útil para motivar y posteriormente examinar la actuación?",
      "options": [
        "Presupuesto comprometido, criterios de selección, actas y criterios de priorización, durante la fase de evaluación definida en el cronograma de gestión de la institución.",
        "Presupuesto comprometido, opciones disponibles, entrega de llaves y criterios de priorización.",
        "Presupuesto comprometido, opciones disponibles, actas y criterios de priorización."
      ],
      "correct": 2,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de definir ámbitos reales de decisión, restricciones y mecanismos de devolución de propuestas.",
      "distractors": "A. Esta selección es parcial: no integra opciones disponibles, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nB. Esta selección es parcial: no integra actas, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 453,
      "originalId": 33,
      "sourceExam": 4,
      "situationId": "S4-10",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál propuesta es jurídicamente y pedagógicamente más defendible?",
      "options": [
        "Abrir revisión participativa, comprobar garantías de derechos y tramitar su adopción por las instancias institucionales competentes; para atender la solicitud presentada formalmente ante la dirección de la institución.",
        "Aplicar el borrador en una fase piloto de convivencia mientras se consulta a representantes sobre sus resultados, junto con una revisión administrativa de tareas y tiempos de implementación.",
        "Adoptar primero la versión externa y abrir luego una revisión participativa que permita modificar medidas cuestionadas, con reuniones de seguimiento y una matriz de compromisos documentada."
      ],
      "correct": 0,
      "explanation": "La medida aborda directamente el hecho descrito y respeta el reparto de competencias y la participación válida del gobierno escolar.",
      "distractors": "B. Aunque identifica una salida posible, omite una condición sustantiva para el reparto de competencias y la participación válida del gobierno escolar.\n\nC. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Ley 715 de 2001, art. 10"
    },
    {
      "id": 454,
      "originalId": 34,
      "sourceExam": 4,
      "situationId": "S4-10",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué conjunto de evidencias permitiría sustentar de manera más sólida la decisión?",
      "options": [
        "Trazabilidad de participación, versiones comparadas y decisiones del gobierno escolar, con una descripción de las condiciones que la rectoría consideró relevantes en este supuesto.",
        "Trazabilidad de participación, reglamento del gobierno escolar y decisiones del gobierno escolar.",
        "Trazabilidad de participación, evaluación de riesgos del convenio y decisiones del gobierno escolar, según el informe preparado por la coordinación responsable de revisar la propuesta."
      ],
      "correct": 0,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de abrir revisión participativa, comprobar garantías de derechos y tramitar su adopción por las instancias institucionales competentes.",
      "distractors": "B. Esta selección es parcial: no integra versiones comparadas, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra versiones comparadas, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Ley 715 de 2001, art. 10"
    },
    {
      "id": 455,
      "originalId": 35,
      "sourceExam": 4,
      "situationId": "S4-10",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué observación sería más informativa al rendir cuentas sobre este caso?",
      "options": [
        "Proporción de disposiciones revisadas con participación y cumplimiento del calendario de gestión, con un resumen de los antecedentes que motivaron la convocatoria de los participantes.",
        "Reclamaciones electorales resueltas con motivación y oportunidad, por etapa del proceso, y presentar una explicación de su alcance ante los integrantes del órgano correspondiente.",
        "Proporción de disposiciones revisadas con participación y compatibilidad con garantías de derechos."
      ],
      "correct": 2,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir compatibilidad con garantías de derechos, componente esencial del resultado propuesto.\n\nB. Considera una variable relacionada con el caso, pero deja sin medir proporción de disposiciones revisadas con participación, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Ley 715 de 2001, art. 10"
    },
    {
      "id": 456,
      "originalId": 36,
      "sourceExam": 4,
      "situationId": "S4-11",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuántos puntos porcentuales aumenta la aprobación?",
      "options": [
        "8 puntos",
        "20 puntos",
        "12 puntos"
      ],
      "correct": 2,
      "explanation": "72 % - 60 % = 12 puntos porcentuales.",
      "distractors": "A. Confunde una magnitud con otra o realiza una agregación que altera la base de comparación.\n\nB. Corresponde a una operación o denominador distinto del definido; no coincide con los datos.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de razonamiento cuantitativo"
    },
    {
      "id": 457,
      "originalId": 37,
      "sourceExam": 4,
      "situationId": "S4-11",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuántos puntos porcentuales faltan, desde el 72 %, para una meta del 80 %?",
      "options": [
        "6 puntos",
        "8 puntos",
        "11 puntos"
      ],
      "correct": 1,
      "explanation": "80 % - 72 % = 8 puntos porcentuales.",
      "distractors": "A. Confunde una magnitud con otra o realiza una agregación que altera la base de comparación.\n\nC. Corresponde a una operación o denominador distinto del definido; no coincide con los datos.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de razonamiento cuantitativo"
    },
    {
      "id": 458,
      "originalId": 38,
      "sourceExam": 4,
      "situationId": "S4-11",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál es el crecimiento relativo de la aprobación respecto de la base?",
      "options": [
        "16,7 %",
        "20 %",
        "12 %"
      ],
      "correct": 1,
      "explanation": "(72 - 60)/60 = 0,20 = 20 % de crecimiento relativo.",
      "distractors": "A. Confunde una magnitud con otra o realiza una agregación que altera la base de comparación.\n\nC. Corresponde a una operación o denominador distinto del definido; no coincide con los datos.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de razonamiento cuantitativo"
    },
    {
      "id": 459,
      "originalId": 39,
      "sourceExam": 4,
      "situationId": "S4-12",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué lectura del argumento realizaría la inferencia menos justificable a partir de las pruebas disponibles?",
      "options": [
        "Tres ejemplos favorables no permiten una conclusión universal sobre una metodología.",
        "La afirmación relativa a explicación selectiva de resultados requiere una comprobación complementaria antes de generalizar el efecto.",
        "Los mejores promedios permiten recomendar la estrategia para grupos semejantes sin nueva comparación."
      ],
      "correct": 2,
      "explanation": "La alternativa extrapola o sustituye indebidamente la evidencia: convierte registro de actividades o ejemplos en demostración suficiente de impacto.",
      "distractors": "A. Esta alternativa se apoya en el argumento y sus límites: la lectura distingue lo sustentado por los datos de una conclusión que excede esa evidencia.\n\nB. Distingue evidencia inicial de un resultado concluyente y delimita el alcance del texto.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de lectura crítica"
    },
    {
      "id": 460,
      "originalId": 40,
      "sourceExam": 4,
      "situationId": "S4-12",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué crítica sería menos pertinente para señalar la debilidad inferencial central del texto?",
      "options": [
        "Confundir crecimiento porcentual con aumento absoluto al comparar promedios.",
        "Generalización apresurada desde una muestra escogida por éxito.",
        "La extrapolación de datos no comparables a un resultado institucional sobre explicación selectiva de resultados."
      ],
      "correct": 0,
      "explanation": "La alternativa extrapola o sustituye indebidamente la evidencia: una definición institucional adicional no corrige la inferencia central.",
      "distractors": "B. Esta alternativa se apoya en el argumento y sus límites: el defecto señalado impide pasar con justificación suficiente de las premisas a la conclusión.\n\nC. La crítica se dirige a la inferencia y a la extensión de las conclusiones, no a cuestiones formales.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de lectura crítica"
    },
    {
      "id": 461,
      "originalId": 41,
      "sourceExam": 4,
      "situationId": "S4-12",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué fuente complementaria aportaría menos capacidad para contrastar la conclusión del documento?",
      "options": [
        "Registros alternativos y comparables sobre explicación selectiva de resultados, contrastados con las condiciones iniciales, durante la fase de evaluación definida en el cronograma de gestión de la institución.",
        "Portafolios de los tres docentes y evaluación de satisfacción de sus grupos, y presentar una explicación de su alcance ante los integrantes del órgano correspondiente.",
        "Resultados de docentes con condiciones iniciales comparables y casos no seleccionados."
      ],
      "correct": 1,
      "explanation": "La alternativa extrapola o sustituye indebidamente la evidencia: una ratificación del autor no aporta contraste independiente.",
      "distractors": "A. Los datos externos comparables permiten examinar la inferencia expuesta sin limitarse a ratificaciones de quien redactó el informe.\n\nC. Esta alternativa se apoya en el argumento y sus límites: la evidencia propuesta examina directamente el salto inferencial identificado en el texto.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de lectura crítica"
    },
    {
      "id": 462,
      "originalId": 42,
      "sourceExam": 4,
      "situationId": "S4-13",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se audita la documentación propuesta, ¿qué expediente exigiría la mayor subsanación?",
      "options": [
        "Solicitudes, cupos, comunicaciones, trazabilidad de selección y aportes ofrecidos.",
        "Solicitudes, criterios de selección, comunicaciones, trazabilidad de selección y aportes ofrecidos, con seguimiento documental del cambio anunciado en el proceso escolar de referencia.",
        "Expediente contrastado de favores por matrícula: solicitudes, cupos, comunicaciones, trazabilidad de selección y aportes ofrecidos, con índice y control de versiones."
      ],
      "correct": 1,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de garantizar criterios transparentes de acceso, rechazar condicionamientos y activar controles pertinentes.\n\nC. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 463,
      "originalId": 43,
      "sourceExam": 4,
      "situationId": "S4-13",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Entre las siguientes propuestas de seguimiento, ¿cuál deja una brecha de medición más relevante?",
      "options": [
        "Cupos asignados según reglas y sin pagos condicionantes, con una constancia escrita de las razones utilizadas para orientar la actuación institucional.",
        "Seguimiento desagregado por período y población de: cupos asignados según reglas y sin pagos condicionantes.",
        "Integridad documental y trazabilidad de actuaciones frente a instrucciones improcedentes."
      ],
      "correct": 2,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.\n\nB. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 464,
      "originalId": 44,
      "sourceExam": 4,
      "situationId": "S4-13",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál de las medidas planteadas podría producir una actuación institucional objetable por su alcance o secuencia?",
      "options": [
        "Recibir aportes voluntarios durante la asignación de cupos, siempre que un comité separado supervise su destinación.",
        "Examinar los soportes asociados a favores por matrícula, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Garantizar criterios transparentes de acceso, rechazar condicionamientos y activar controles pertinentes; durante la fase de evaluación definida en el cronograma de gestión de la institución."
      ],
      "correct": 0,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la probidad, el criterio directivo y la rendición de cuentas.",
      "distractors": "B. La alternativa preserva un examen previo y fundamentado de favores por matrícula antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nC. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la probidad, el criterio directivo y la rendición de cuentas.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 465,
      "originalId": 45,
      "sourceExam": 4,
      "situationId": "S4-14",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué fuentes deberían triangularse para reducir el riesgo de una conclusión apresurada?",
      "options": [
        "Diagnóstico ambiental, versiones públicas e insumos de participación, canales de participación y prioridades del PEI.",
        "Diagnóstico ambiental, aportes, planes de área y prioridades del PEI, con registro de las decisiones tomadas durante el período de atención del asunto.",
        "Diagnóstico ambiental, aportes, canales de participación y prioridades del PEI."
      ],
      "correct": 2,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de incorporar deliberación territorial y evidencia pertinente por los canales del gobierno escolar.",
      "distractors": "A. Esta selección es parcial: no integra aportes, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nB. Esta selección es parcial: no integra canales de participación, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 466,
      "originalId": 46,
      "sourceExam": 4,
      "situationId": "S4-14",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referencia normativa conviene revisar primero por su relación directa con el caso?",
      "options": [
        "Decreto 459 de 2024, Alianza Familias-Escuela",
        "Ley 115 de 1994, arts. 142-145",
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes"
      ],
      "correct": 0,
      "explanation": "Este marco se relaciona de modo más directo con la participación significativa, la accesibilidad y el diálogo territorial. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "B. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nC. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 467,
      "originalId": 47,
      "sourceExam": 4,
      "situationId": "S4-14",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál criterio de seguimiento refleja mejor el problema que se pretende corregir?",
      "options": [
        "Problemas territoriales atendidos mediante compromisos evaluados.",
        "Familias acompañadas individualmente sin exposición innecesaria de datos.",
        "Prácticas con supervisión, cobertura de riesgos y tratamiento legítimo de datos."
      ],
      "correct": 0,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "B. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.\n\nC. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 468,
      "originalId": 48,
      "sourceExam": 4,
      "situationId": "S4-14",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué iniciativa sería más difícil de justificar si se confronta con las obligaciones rectorales pertinentes?",
      "options": [
        "Examinar los soportes asociados a organización barrial opina sobre pei, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables; según el informe preparado por la coordinación responsable de revisar la propuesta.",
        "Incorporar deliberación territorial y evidencia pertinente por los canales del gobierno escolar, con constancia de la decisión en las actas y archivos de rectoría.",
        "Incorporar las propuestas de la organización al plan de ciencias y presentarlas después al Consejo como resultados del proyecto; con una descripción de las condiciones que la rectoría consideró relevantes en este supuesto."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la participación significativa, la accesibilidad y el diálogo territorial.",
      "distractors": "A. La alternativa preserva un examen previo y fundamentado de organización barrial opina sobre pei antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nB. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la participación significativa, la accesibilidad y el diálogo territorial.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 469,
      "originalId": 49,
      "sourceExam": 4,
      "situationId": "S4-15",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué disposición es el punto de partida más específico para analizar la actuación?",
      "options": [
        "Ley 1620 de 2013 y sus rutas institucionales",
        "Decreto 1421 de 2017, educación inclusiva y PIAR",
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes"
      ],
      "correct": 0,
      "explanation": "Este marco se relaciona de modo más directo con la protección de derechos, los procedimientos y la reserva de información. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "B. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nC. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 470,
      "originalId": 50,
      "sourceExam": 4,
      "situationId": "S4-15",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué expediente sería más útil para motivar y posteriormente examinar la actuación?",
      "options": [
        "Registros de episodios, medidas de protección, medidas previas y seguimiento de las partes.",
        "Registros de episodios, afectación, medidas previas y seguimiento de las partes, como parte de una decisión comunicada a los equipos que resultarían directamente involucrados.",
        "Registros de episodios, afectación, derechos de las personas involucradas y seguimiento de las partes."
      ],
      "correct": 1,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de combinar protección, actuación proporcional, trabajo formativo y seguimiento verificable de reincidencia.",
      "distractors": "A. Esta selección es parcial: no integra afectación, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra medidas previas, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 471,
      "originalId": 51,
      "sourceExam": 4,
      "situationId": "S4-15",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cómo debería operacionalizarse el resultado esperado en el plan de seguimiento?",
      "options": [
        "Oportunidad de respuesta y continuidad de apoyos sin revictimización.",
        "Barreras de participación eliminadas sin afectar objetivos institucionales legítimos.",
        "Reincidencias, percepción de seguridad y cumplimiento de medidas acordadas, para que el equipo responsable conozca los efectos esperados y los pasos anunciados."
      ],
      "correct": 2,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir reincidencias, percepción de seguridad, componente esencial del resultado propuesto.\n\nB. Considera una variable relacionada con el caso, pero deja sin medir reincidencias, percepción de seguridad, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 472,
      "originalId": 52,
      "sourceExam": 4,
      "situationId": "S4-15",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "De las siguientes actuaciones, ¿cuál requeriría una corrección prioritaria por comprometer el procedimiento o la garantía central del caso?",
      "options": [
        "Combinar protección, actuación proporcional, trabajo formativo y seguimiento verificable de reincidencia, con el acompañamiento del comité correspondiente y registros de avance.",
        "Realizar acciones formativas generales y dar seguimiento solo a la conducta de quienes agredieron, sin valorar seguridad de la persona afectada.",
        "Examinar los soportes asociados a reincidencia y medida restaurativa, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables."
      ],
      "correct": 1,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la protección de derechos, los procedimientos y la reserva de información.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la protección de derechos, los procedimientos y la reserva de información.\n\nC. La alternativa preserva un examen previo y fundamentado de reincidencia y medida restaurativa antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 473,
      "originalId": 53,
      "sourceExam": 4,
      "situationId": "S4-16",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué selección de soportes dejaría el vacío probatorio más importante para justificar la decisión?",
      "options": [
        "Expediente contrastado de trabajo infantil y ausencias: patrón de ausencias, diálogo protegido, apoyos disponibles y actuaciones de protección, con índice y control de versiones.",
        "Patrón de ausencias, medidas de protección, apoyos disponibles y actuaciones de protección.",
        "Patrón de ausencias, diálogo protegido, apoyos disponibles y actuaciones de protección."
      ],
      "correct": 1,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nC. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de valorar posibles vulneraciones, activar apoyos y rutas de protección pertinentes y construir estrategia de permanencia.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 474,
      "originalId": 54,
      "sourceExam": 4,
      "situationId": "S4-16",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referente delimita de forma más directa las responsabilidades institucionales involucradas?",
      "options": [
        "Decreto 1421 de 2017, educación inclusiva y PIAR",
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes",
        "Ley 1620 de 2013 y sus rutas institucionales"
      ],
      "correct": 1,
      "explanation": "Este marco se relaciona de modo más directo con la garantía del derecho a la educación y la articulación de protección. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nC. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 475,
      "originalId": 55,
      "sourceExam": 4,
      "situationId": "S4-16",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué propuesta presenta el riesgo institucional más grave, a pesar de sus aparentes ventajas operativas?",
      "options": [
        "Examinar los soportes asociados a trabajo infantil y ausencias, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Valorar posibles vulneraciones, activar apoyos y rutas de protección pertinentes y construir estrategia de permanencia; con una descripción de las condiciones que la rectoría consideró relevantes en este supuesto.",
        "Negociar un calendario académico especial con la familia sin activar la valoración de riesgos que explica las ausencias."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la garantía del derecho a la educación y la articulación de protección.",
      "distractors": "A. La alternativa preserva un examen previo y fundamentado de trabajo infantil y ausencias antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nB. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la garantía del derecho a la educación y la articulación de protección.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 476,
      "originalId": 56,
      "sourceExam": 4,
      "situationId": "S4-16",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué medida sería menos adecuada como indicador principal para rendir cuentas sobre el resultado específico del caso?",
      "options": [
        "Aprendizajes sostenidos y participación posible durante el tratamiento, con una secuencia de comunicación posterior para facilitar el seguimiento de sus efectos.",
        "Asistencia recuperada y continuidad de la estudiante sin riesgos adicionales.",
        "Seguimiento desagregado por período y población de: asistencia recuperada y continuidad de la estudiante sin riesgos adicionales, en el marco de la discusión sostenida con quienes participaron en la reunión preparatoria."
      ],
      "correct": 0,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "B. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.\n\nC. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.",
      "legalBasis": "Ley 1098 de 2006; Ley 1620 de 2013; Decreto 1075 de 2015"
    },
    {
      "id": 477,
      "originalId": 57,
      "sourceExam": 4,
      "situationId": "S4-17",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se comparan tres rutas de decisión, ¿cuál resultaría menos defendible ante una revisión de competencias y garantías?",
      "options": [
        "Entrevistar al estudiante en el siguiente comité de convivencia para determinar si la alerta requiere atención fuera de la institución; junto con la constancia de revisión de las condiciones informadas por los responsables.",
        "Priorizar valoración de riesgo y rutas inmediatas de protección y salud según circunstancias, resguardando confidencialidad.",
        "Examinar los soportes asociados a reporte tardío de autolesión, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables."
      ],
      "correct": 0,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la protección de derechos, los procedimientos y la reserva de información.",
      "distractors": "B. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la protección de derechos, los procedimientos y la reserva de información.\n\nC. La alternativa preserva un examen previo y fundamentado de reporte tardío de autolesión antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 478,
      "originalId": 58,
      "sourceExam": 4,
      "situationId": "S4-17",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál evidencia de resultado permitiría una evaluación menos sesgada?",
      "options": [
        "Atención oportuna, protección y seguimiento de situaciones sin exposición de datos.",
        "Oportunidad de respuesta y continuidad de apoyos sin revictimización, y presentar una explicación de su alcance ante los integrantes del órgano correspondiente.",
        "Barreras de participación eliminadas sin afectar objetivos institucionales legítimos, con una secuencia de comunicación posterior para facilitar el seguimiento de sus efectos."
      ],
      "correct": 1,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir oportunidad de respuesta, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir oportunidad de respuesta, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 479,
      "originalId": 59,
      "sourceExam": 4,
      "situationId": "S4-17",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se audita la documentación propuesta, ¿qué expediente exigiría la mayor subsanación?",
      "options": [
        "Información de riesgo, acciones protectoras realizadas y coordinación con servicios pertinentes.",
        "Información de riesgo, información inicial de riesgo y coordinación con servicios pertinentes, y presentar una explicación de su alcance ante los integrantes del órgano correspondiente, con un resumen de los antecedentes que motivaron la convocatoria de los participantes.",
        "Expediente contrastado de reporte tardío de autolesión: información de riesgo, acciones protectoras realizadas y coordinación con servicios pertinentes, con índice y control de versiones."
      ],
      "correct": 1,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de priorizar valoración de riesgo y rutas inmediatas de protección y salud según circunstancias, resguardando confidencialidad.\n\nC. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 480,
      "originalId": 60,
      "sourceExam": 4,
      "situationId": "S4-17",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Para orientar la motivación jurídica inicial, ¿qué marco ofrece la conexión más pertinente con los hechos?",
      "options": [
        "Ley 1620 de 2013 y sus rutas institucionales",
        "Decreto 1421 de 2017, educación inclusiva y PIAR",
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes"
      ],
      "correct": 0,
      "explanation": "Este marco se relaciona de modo más directo con la protección de derechos, los procedimientos y la reserva de información. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "B. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nC. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Ley 1620 de 2013; Ley 1098 de 2006; Decreto 1075 de 2015"
    },
    {
      "id": 481,
      "originalId": 61,
      "sourceExam": 4,
      "situationId": "S4-18",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál de las medidas planteadas podría producir una actuación institucional objetable por su alcance o secuencia?",
      "options": [
        "Justificar necesidad y presentar el traslado presupuestal ante Consejo Directivo para aprobación competente, con un cronograma de ejecución conocido por las instancias participantes.",
        "Examinar los soportes asociados a traslado presupuestal urgente, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables; con una constancia escrita de las razones utilizadas para orientar la actuación institucional.",
        "Comprometer recursos del rubro disponible y presentar al Consejo Directivo el traslado antes de efectuar el pago final; junto con la constancia de revisión de las condiciones informadas por los responsables."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la autorización presupuestal, el control y la destinación de recursos públicos.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la autorización presupuestal, el control y la destinación de recursos públicos.\n\nB. La alternativa preserva un examen previo y fundamentado de traslado presupuestal urgente antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 482,
      "originalId": 62,
      "sourceExam": 4,
      "situationId": "S4-18",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué soportes documentales aportan el mejor fundamento para la actuación institucional?",
      "options": [
        "Presupuesto aprobado, disponibilidad, flujo de caja y actas del Consejo Directivo, durante la fase de evaluación definida en el cronograma de gestión de la institución.",
        "Presupuesto aprobado, actas de recibo, flujo de caja y actas del Consejo Directivo.",
        "Presupuesto aprobado, disponibilidad, actas de entrega y actas del Consejo Directivo, como parte de la respuesta elaborada tras la reunión del personal que participó en el análisis."
      ],
      "correct": 0,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de justificar necesidad y presentar el traslado presupuestal ante consejo directivo para aprobación competente.",
      "distractors": "B. Esta selección es parcial: no integra disponibilidad, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra flujo de caja, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 483,
      "originalId": 63,
      "sourceExam": 4,
      "situationId": "S4-18",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué medida permitiría valorar el resultado de la intervención sin confundir actividad con impacto?",
      "options": [
        "Traslados con acuerdos previos y ejecución conforme a disponibilidad, como parte de una decisión comunicada a los equipos que resultarían directamente involucrados.",
        "Costo total por estudiante beneficiado y continuidad efectiva del recurso.",
        "Pagos que cumplen condiciones pactadas y respaldos de ejecución."
      ],
      "correct": 0,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "B. Considera una variable relacionada con el caso, pero deja sin medir traslados con acuerdos previos, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir traslados con acuerdos previos, componente esencial del resultado propuesto.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 484,
      "originalId": 64,
      "sourceExam": 4,
      "situationId": "S4-18",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referencia normativa conviene revisar primero por su relación directa con el caso?",
      "options": [
        "Ley 715 de 2001, art. 10, funciones del rector",
        "Decreto 1075 de 2015, sección del Fondo de Servicios Educativos",
        "Ley 115 de 1994, arts. 142-145"
      ],
      "correct": 1,
      "explanation": "Este marco se relaciona de modo más directo con la autorización presupuestal, el control y la destinación de recursos públicos. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nC. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Decreto 1075 de 2015, arts. 2.3.1.6.3.3-2.3.1.6.3.6; Decreto 4791 de 2008"
    },
    {
      "id": 485,
      "originalId": 65,
      "sourceExam": 4,
      "situationId": "S4-19",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué iniciativa sería más difícil de justificar si se confronta con las obligaciones rectorales pertinentes?",
      "options": [
        "Verificar cadena de custodia y hechos, proteger imparcialidad y tramitar actuaciones pertinentes, previa discusión con los representantes de las sedes involucradas.",
        "Solicitar reposición temporal al encargado de bodega mientras se termina la conciliación documental de las existencias; como parte de la respuesta elaborada tras la reunión del personal que participó en el análisis.",
        "Examinar los soportes asociados a pérdida atribuida sin investigación, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables."
      ],
      "correct": 1,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la probidad, el criterio directivo y la rendición de cuentas.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la probidad, el criterio directivo y la rendición de cuentas.\n\nC. La alternativa preserva un examen previo y fundamentado de pérdida atribuida sin investigación antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 486,
      "originalId": 66,
      "sourceExam": 4,
      "situationId": "S4-19",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál formulación introduce la limitación más importante al evaluar el resultado y no solo la gestión?",
      "options": [
        "Seguimiento desagregado por período y población de: diferencias de inventario investigadas con garantías y medidas de prevención, bajo una programación conocida por los integrantes responsables de examinar los resultados.",
        "Diferencias de inventario investigadas con garantías y medidas de prevención.",
        "Cupos asignados según reglas y sin pagos condicionantes, para atender la solicitud presentada formalmente ante la dirección de la institución."
      ],
      "correct": 2,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.\n\nB. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 487,
      "originalId": 67,
      "sourceExam": 4,
      "situationId": "S4-19",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "En una revisión externa, ¿qué evidencia permitiría reconstruir con mayor rigor lo ocurrido?",
      "options": [
        "Inventario, entrega de llaves, actas, entradas y salidas de materiales.",
        "Inventario, partes de atención, actas, entradas y salidas de materiales, con un resumen de los antecedentes que motivaron la convocatoria de los participantes.",
        "Inventario, entrega de llaves, actas, puntos de desacuerdo y salidas de materiales."
      ],
      "correct": 0,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de verificar cadena de custodia y hechos, proteger imparcialidad y tramitar actuaciones pertinentes.",
      "distractors": "B. Esta selección es parcial: no integra entrega de llaves, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra entradas, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022; principios de función administrativa"
    },
    {
      "id": 488,
      "originalId": 68,
      "sourceExam": 4,
      "situationId": "S4-20",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué medida sería menos adecuada como indicador principal para rendir cuentas sobre el resultado específico del caso?",
      "options": [
        "Proporción de acuerdos adoptados con soporte de quórum y seguimiento de ejecución, con referencia explícita al contexto escolar particular que originó la controversia.",
        "Porcentaje de adquisiciones pedagógicas con sustento curricular y autorizaciones pertinentes.",
        "Seguimiento desagregado por período y población de: porcentaje de adquisiciones pedagógicas con sustento curricular y autorizaciones pertinentes."
      ],
      "correct": 0,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "B. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.\n\nC. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Ley 715 de 2001, art. 10"
    },
    {
      "id": 489,
      "originalId": 69,
      "sourceExam": 4,
      "situationId": "S4-20",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué fuentes deberían triangularse para reducir el riesgo de una conclusión apresurada?",
      "options": [
        "Acta académica, presupuesto del FSE, acuerdos del Consejo Directivo y plan de compras, según el informe preparado por la coordinación responsable de revisar la propuesta.",
        "Acta académica, reglamento del Consejo, acuerdos del Consejo Directivo y plan de compras.",
        "Acta académica, presupuesto del FSE, evaluación de riesgos del convenio y plan de compras, con referencia explícita al contexto escolar particular que originó la controversia."
      ],
      "correct": 0,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de distinguir las recomendaciones pedagógicas del consejo académico y la competencia presupuestal del consejo directivo, antes de ordenar gasto.",
      "distractors": "B. Esta selección es parcial: no integra presupuesto del FSE, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra acuerdos del Consejo Directivo, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Ley 715 de 2001, art. 10"
    },
    {
      "id": 490,
      "originalId": 70,
      "sourceExam": 4,
      "situationId": "S4-20",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "De las siguientes actuaciones, ¿cuál requeriría una corrección prioritaria por comprometer el procedimiento o la garantía central del caso?",
      "options": [
        "Examinar los soportes asociados a competencias confundidas, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables; con una constancia escrita de las razones utilizadas para orientar la actuación institucional.",
        "Distinguir las recomendaciones pedagógicas del Consejo Académico y la competencia presupuestal del Consejo Directivo, antes de ordenar gasto.",
        "Tramitar las compras que aprobó el Consejo Académico y pedir al Consejo Directivo revisar su ejecución trimestral; junto con la constancia de revisión de las condiciones informadas por los responsables."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para el reparto de competencias y la participación válida del gobierno escolar.",
      "distractors": "A. La alternativa preserva un examen previo y fundamentado de competencias confundidas antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nB. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta el reparto de competencias y la participación válida del gobierno escolar.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Ley 715 de 2001, art. 10"
    },
    {
      "id": 491,
      "originalId": 71,
      "sourceExam": 4,
      "situationId": "S4-20",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referente delimita de forma más directa las responsabilidades institucionales involucradas?",
      "options": [
        "Ley 115 de 1994, arts. 142-145",
        "Ley 715 de 2001, art. 10, funciones del rector",
        "Ley 715 de 2001, art. 10"
      ],
      "correct": 0,
      "explanation": "Este marco se relaciona de modo más directo con el reparto de competencias y la participación válida del gobierno escolar. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "B. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nC. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Ley 715 de 2001, art. 10"
    },
    {
      "id": 492,
      "originalId": 72,
      "sourceExam": 4,
      "situationId": "S4-21",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cómo debería operacionalizarse el resultado esperado en el plan de seguimiento?",
      "options": [
        "Porcentaje de adquisiciones pedagógicas con sustento curricular y autorizaciones pertinentes.",
        "Proporción de disposiciones revisadas con participación y compatibilidad con garantías de derechos.",
        "Proporción de acuerdos adoptados con soporte de quórum y seguimiento de ejecución."
      ],
      "correct": 2,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir proporción de acuerdos adoptados con soporte de quórum, componente esencial del resultado propuesto.\n\nB. Considera una variable relacionada con el caso, pero deja sin medir proporción de acuerdos adoptados con soporte de quórum, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Ley 715 de 2001, art. 10"
    },
    {
      "id": 493,
      "originalId": 73,
      "sourceExam": 4,
      "situationId": "S4-21",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se audita la documentación propuesta, ¿qué expediente exigiría la mayor subsanación?",
      "options": [
        "Convocatorias, registro de asistencia, reglamento del Consejo y actas de la sesión.",
        "Convocatorias, acuerdos del Consejo Directivo, reglamento del Consejo y actas de la sesión.",
        "Expediente contrastado de votación sin quórum: convocatorias, registro de asistencia, reglamento del Consejo y actas de la sesión, con índice y control de versiones."
      ],
      "correct": 1,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de comprobar las reglas de convocatoria y quórum, convocar sesión válida y dejar constancia de la decisión competente.\n\nC. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Ley 715 de 2001, art. 10"
    },
    {
      "id": 494,
      "originalId": 74,
      "sourceExam": 4,
      "situationId": "S4-21",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué propuesta presenta el riesgo institucional más grave, a pesar de sus aparentes ventajas operativas?",
      "options": [
        "Constatar quiénes participaron y ejecutar provisionalmente el acuerdo, sujeto a confirmación en la próxima sesión ordinaria; con indicación del período al que se refiere la propuesta de actuación y sus consecuencias.",
        "Comprobar las reglas de convocatoria y quórum, convocar sesión válida y dejar constancia de la decisión competente, con participación de responsables de área para examinar su ejecución; para que el equipo responsable conozca los efectos esperados y los pasos anunciados.",
        "Examinar los soportes asociados a votación sin quórum, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables."
      ],
      "correct": 0,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para el reparto de competencias y la participación válida del gobierno escolar.",
      "distractors": "B. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta el reparto de competencias y la participación válida del gobierno escolar.\n\nC. La alternativa preserva un examen previo y fundamentado de votación sin quórum antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Ley 115 de 1994, arts. 142-145; Ley 715 de 2001, art. 10"
    },
    {
      "id": 495,
      "originalId": 75,
      "sourceExam": 4,
      "situationId": "S4-22",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué conjunto de evidencias permitiría sustentar de manera más sólida la decisión?",
      "options": [
        "Planes del proyecto, planes de área, debates y participación real de estudiantes.",
        "Planes del proyecto, actas, plan de estudios y participación real de estudiantes.",
        "Planes del proyecto, actas, debates y participación real de estudiantes."
      ],
      "correct": 2,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de planear experiencias de participación, argumentación y seguimiento a compromisos democráticos.",
      "distractors": "A. Esta selección es parcial: no integra actas, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nB. Esta selección es parcial: no integra debates, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 496,
      "originalId": 76,
      "sourceExam": 4,
      "situationId": "S4-22",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se comparan tres rutas de decisión, ¿cuál resultaría menos defendible ante una revisión de competencias y garantías?",
      "options": [
        "Examinar los soportes asociados a formación ciudadana ceremonial, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Fortalecer actividades de elección y medir participación electoral mientras se proyectan experiencias de deliberación futuras.",
        "Planear experiencias de participación, argumentación y seguimiento a compromisos democráticos, con un plan de divulgación de los acuerdos entre las partes."
      ],
      "correct": 1,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la integralidad curricular y la función pedagógica institucional.",
      "distractors": "A. La alternativa preserva un examen previo y fundamentado de formación ciudadana ceremonial antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nC. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la integralidad curricular y la función pedagógica institucional.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 497,
      "originalId": 77,
      "sourceExam": 4,
      "situationId": "S4-22",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué observación sería más informativa al rendir cuentas sobre este caso?",
      "options": [
        "Capacidad de deliberación y seguimiento de acuerdos en ejercicios formativos, con un resumen de los antecedentes que motivaron la convocatoria de los participantes.",
        "Capacidad de deliberación y cumplimiento del calendario de gestión.",
        "Seguimiento de acuerdos en ejercicios formativos y asistencia a reuniones."
      ],
      "correct": 0,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "B. Considera una variable relacionada con el caso, pero deja sin medir seguimiento de acuerdos en ejercicios formativos, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir capacidad de deliberación, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 498,
      "originalId": 78,
      "sourceExam": 4,
      "situationId": "S4-23",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Antes de cerrar el análisis, ¿qué información resulta más decisiva para contrastar las afirmaciones?",
      "options": [
        "PRAE, PEI, planes de área, muestras de clase y productos estudiantiles, con anotación de las circunstancias específicas del establecimiento en la fecha de la decisión.",
        "PRAE, plan de estudios, planes de área, diagnóstico territorial y productos estudiantiles.",
        "PRAE, PEI, planes de área, diagnóstico territorial y productos estudiantiles."
      ],
      "correct": 2,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de integrar el proyecto ambiental con pei, planes de área, problemas territoriales y evidencias de aprendizaje.",
      "distractors": "A. Esta selección es parcial: no integra diagnóstico territorial, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nB. Esta selección es parcial: no integra PEI, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 499,
      "originalId": 79,
      "sourceExam": 4,
      "situationId": "S4-23",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si la rectoría debe tomar una decisión inicial motivada, ¿cuál opción es preferible?",
      "options": [
        "Incluir afiches del PRAE en las planeaciones y evaluar únicamente productos ambientales compartidos en los eventos.",
        "Integrar el proyecto ambiental con PEI, planes de área, problemas territoriales y evidencias de aprendizaje; con seguimiento documental del cambio anunciado en el proceso escolar de referencia.",
        "Ampliar campañas y registrar indicadores de participación antes de articular sus resultados con objetivos curriculares por área."
      ],
      "correct": 1,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la integralidad curricular y la función pedagógica institucional.",
      "distractors": "A. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.\n\nC. Aunque identifica una salida posible, omite una condición sustantiva para la integralidad curricular y la función pedagógica institucional.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 500,
      "originalId": 80,
      "sourceExam": 4,
      "situationId": "S4-23",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál evidencia de resultado permitiría una evaluación menos sesgada?",
      "options": [
        "Progresión de desempeños comunicativos por ciclo y grado, durante la fase de evaluación definida en el cronograma de gestión de la institución.",
        "Horas efectivas y desempeños logrados con alternativas de enseñanza, en el marco de la discusión sostenida con quienes participaron en la reunión preparatoria.",
        "Competencias ambientales demostradas y acciones sostenidas durante el año."
      ],
      "correct": 2,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir competencias ambientales demostradas, componente esencial del resultado propuesto.\n\nB. Considera una variable relacionada con el caso, pero deja sin medir competencias ambientales demostradas, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 501,
      "originalId": 81,
      "sourceExam": 4,
      "situationId": "S4-24",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué porcentaje del presupuesto consume la combinación anterior?",
      "options": [
        "93,33 % aproximadamente",
        "88,89 % aproximadamente",
        "84,44 % aproximadamente"
      ],
      "correct": 1,
      "explanation": "40 / 45 × 100 = 88,888... % del presupuesto total.",
      "distractors": "A. Corresponde a una operación o denominador distinto del definido; no coincide con los datos.\n\nC. Confunde una magnitud con otra o realiza una agregación que altera la base de comparación.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de razonamiento cuantitativo"
    },
    {
      "id": 502,
      "originalId": 82,
      "sourceExam": 4,
      "situationId": "S4-24",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué diferencia existe entre el presupuesto y las cuatro propuestas?",
      "options": [
        "Un déficit de 5 millones",
        "Un déficit de 2 millones",
        "Un saldo de 2 millones"
      ],
      "correct": 1,
      "explanation": "18 + 12 + 10 + 7 = 47 millones; 47 - 45 = 2 millones de déficit.",
      "distractors": "A. Confunde una magnitud con otra o realiza una agregación que altera la base de comparación.\n\nC. Corresponde a una operación o denominador distinto del definido; no coincide con los datos.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de razonamiento cuantitativo"
    },
    {
      "id": 503,
      "originalId": 83,
      "sourceExam": 4,
      "situationId": "S4-24",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se aprueban solo seguridad, accesibilidad y bibliotecas, ¿qué saldo queda?",
      "options": [
        "3 millones",
        "7 millones",
        "5 millones"
      ],
      "correct": 2,
      "explanation": "45 - (18 + 12 + 10) = 5 millones.",
      "distractors": "A. Confunde una magnitud con otra o realiza una agregación que altera la base de comparación.\n\nB. Corresponde a una operación o denominador distinto del definido; no coincide con los datos.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de razonamiento cuantitativo"
    },
    {
      "id": 504,
      "originalId": 84,
      "sourceExam": 4,
      "situationId": "S4-25",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "De las siguientes actuaciones, ¿cuál requeriría una corrección prioritaria por comprometer el procedimiento o la garantía central del caso?",
      "options": [
        "Examinar los soportes asociados a plan lector de biblioteca cerrada, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables; con una comunicación dirigida a los actores mencionados en el expediente institucional.",
        "Aumentar préstamo domiciliario y contar libros circulantes antes de integrar actividades de mediación a los planes de área; para que el equipo responsable conozca los efectos esperados y los pasos anunciados.",
        "Asegurar acceso, mediación pedagógica, tiempos de uso y evidencias de comprensión, con acta de socialización y seguimiento por el equipo académico."
      ],
      "correct": 1,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la correspondencia entre objetivos curriculares, apoyos didácticos y aprendizaje.",
      "distractors": "A. La alternativa preserva un examen previo y fundamentado de plan lector de biblioteca cerrada antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nC. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la correspondencia entre objetivos curriculares, apoyos didácticos y aprendizaje.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 505,
      "originalId": 85,
      "sourceExam": 4,
      "situationId": "S4-25",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Para orientar la motivación jurídica inicial, ¿qué marco ofrece la conexión más pertinente con los hechos?",
      "options": [
        "Resolución MEN 003842 de 2022, gestión académica",
        "Decreto 1290 de 2009, art. 11",
        "Ley 115 de 1994, objetivos, áreas y proyectos educativos"
      ],
      "correct": 0,
      "explanation": "Este marco se relaciona de modo más directo con la correspondencia entre objetivos curriculares, apoyos didácticos y aprendizaje. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "B. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nC. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 506,
      "originalId": 86,
      "sourceExam": 4,
      "situationId": "S4-25",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Entre las siguientes propuestas de seguimiento, ¿cuál deja una brecha de medición más relevante?",
      "options": [
        "Seguimiento desagregado por período y población de: uso pedagógico efectivo vinculado con comprensión lectora por cohortes.",
        "Progreso de aprendizaje por condición de acceso y sede.",
        "Uso pedagógico efectivo vinculado con comprensión lectora por cohortes."
      ],
      "correct": 1,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.\n\nC. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 507,
      "originalId": 87,
      "sourceExam": 4,
      "situationId": "S4-25",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "En una revisión externa, ¿qué evidencia permitiría reconstruir con mayor rigor lo ocurrido?",
      "options": [
        "Horarios, préstamos, secuencias lectoras, desempeños previos y desempeños.",
        "Horarios, préstamos, secuencias lectoras, grupos atendidos y desempeños, y presentar una explicación de su alcance ante los integrantes del órgano correspondiente.",
        "Horarios, desempeños antes, secuencias lectoras, grupos atendidos y desempeños."
      ],
      "correct": 1,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de asegurar acceso, mediación pedagógica, tiempos de uso y evidencias de comprensión.",
      "distractors": "A. Esta selección es parcial: no integra grupos atendidos, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra préstamos, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 508,
      "originalId": 88,
      "sourceExam": 4,
      "situationId": "S4-26",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué fuentes deberían triangularse para reducir el riesgo de una conclusión apresurada?",
      "options": [
        "Variables usadas, errores, mapa de cámaras y resultados por subgrupo, durante la fase de evaluación definida en el cronograma de gestión de la institución.",
        "Variables usadas, errores, representatividad de datos y resultados por subgrupo.",
        "Variables usadas, resultados por modalidad, representatividad de datos y resultados por subgrupo."
      ],
      "correct": 1,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de revisar finalidad, calidad de datos, sesgos, derechos y validación humana antes de intervenir individualmente.",
      "distractors": "A. Esta selección es parcial: no integra representatividad de datos, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra errores, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 509,
      "originalId": 89,
      "sourceExam": 4,
      "situationId": "S4-26",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál criterio de seguimiento refleja mejor el problema que se pretende corregir?",
      "options": [
        "Errores y efectos diferenciales del modelo junto con eficacia de apoyos humanos.",
        "Diferencias de aprendizaje y participación entre modalidades de acceso, con una comunicación dirigida a los actores mencionados en el expediente institucional.",
        "Errores y cumplimiento del calendario de gestión."
      ],
      "correct": 0,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "B. Considera una variable relacionada con el caso, pero deja sin medir errores, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir efectos diferenciales del modelo junto con eficacia de apoyos humanos, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 510,
      "originalId": 90,
      "sourceExam": 4,
      "situationId": "S4-26",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál propuesta es jurídicamente y pedagógicamente más defendible?",
      "options": [
        "Revisar finalidad, calidad de datos, sesgos, derechos y validación humana antes de intervenir individualmente; junto con la constancia de revisión de las condiciones informadas por los responsables.",
        "Aplicar la puntuación de riesgo a toda la población y explicar después a las familias los criterios utilizados por la herramienta; con una constancia escrita de las razones utilizadas para orientar la actuación institucional.",
        "Utilizar el modelo como criterio principal de asignación de apoyos y someter sus resultados a revisión humana trimestral."
      ],
      "correct": 0,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la finalidad legítima, la calidad de datos y los controles de acceso.",
      "distractors": "B. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.\n\nC. Aunque identifica una salida posible, omite una condición sustantiva para la finalidad legítima, la calidad de datos y los controles de acceso.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 511,
      "originalId": 91,
      "sourceExam": 4,
      "situationId": "S4-27",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué expediente sería más útil para motivar y posteriormente examinar la actuación?",
      "options": [
        "Instrumentos, finalidad, autorizaciones, convenios y riesgos para participantes.",
        "Instrumentos, PEI, autorizaciones, convenios y riesgos para participantes, según el informe preparado por la coordinación responsable de revisar la propuesta.",
        "Instrumentos, finalidad, autorizaciones, pRAE y riesgos para participantes, con una constancia escrita de las razones utilizadas para orientar la actuación institucional."
      ],
      "correct": 0,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de valorar pertinencia, garantías éticas, autorizaciones y pertinencia curricular antes de permitir la recolección.",
      "distractors": "B. Esta selección es parcial: no integra finalidad, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra convenios, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 512,
      "originalId": 92,
      "sourceExam": 4,
      "situationId": "S4-27",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cómo debería operacionalizarse el resultado esperado en el plan de seguimiento?",
      "options": [
        "Aprovechamiento pedagógico definido y asistencia a reuniones, bajo una programación conocida por los integrantes responsables de examinar los resultados.",
        "Proyectos autorizados con salvaguardas y aprovechamiento pedagógico definido.",
        "Competencias ambientales demostradas y acciones sostenidas durante el año, con anotación de las circunstancias específicas del establecimiento en la fecha de la decisión."
      ],
      "correct": 1,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir proyectos autorizados con salvaguardas, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir proyectos autorizados con salvaguardas, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 513,
      "originalId": 93,
      "sourceExam": 4,
      "situationId": "S4-27",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué disposición es el punto de partida más específico para analizar la actuación?",
      "options": [
        "Decreto 1290 de 2009, art. 11",
        "Ley 115 de 1994, objetivos, áreas y proyectos educativos",
        "Resolución MEN 003842 de 2022, gestión académica"
      ],
      "correct": 1,
      "explanation": "Este marco se relaciona de modo más directo con la integralidad curricular y la función pedagógica institucional. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nC. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 514,
      "originalId": 94,
      "sourceExam": 4,
      "situationId": "S4-27",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se comparan tres rutas de decisión, ¿cuál resultaría menos defendible ante una revisión de competencias y garantías?",
      "options": [
        "Valorar pertinencia, garantías éticas, autorizaciones y pertinencia curricular antes de permitir la recolección; con una secuencia de comunicación posterior para facilitar el seguimiento de sus efectos.",
        "Examinar los soportes asociados a prácticas pedagógicas de universidad, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Autorizar el trabajo de campo una vez exista una carta general de la universidad, con revisión ética posterior a la recolección."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la integralidad curricular y la función pedagógica institucional.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la integralidad curricular y la función pedagógica institucional.\n\nB. La alternativa preserva un examen previo y fundamentado de prácticas pedagógicas de universidad antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Ley 115 de 1994; Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 515,
      "originalId": 95,
      "sourceExam": 4,
      "situationId": "S4-28",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Ante la situación descrita, ¿cuál actuación del rector constituye la respuesta mejor fundada?",
      "options": [
        "Aplicar los criterios institucionales vigentes y asegurar valoración individual, apoyos y trámite de reclamaciones.",
        "Resolver por mayoría los casos pendientes y habilitar reclamaciones individuales luego de emitir las promociones; con referencia explícita al contexto escolar particular que originó la controversia.",
        "Adoptar el criterio de promoción colectiva con una justificación de bienestar general y revisión académica posterior, a partir de un informe escrito con justificación de la medida."
      ],
      "correct": 0,
      "explanation": "La medida aborda directamente el hecho descrito y respeta las reglas del SIEE, los apoyos y la motivación de decisiones académicas.",
      "distractors": "B. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.\n\nC. Aunque identifica una salida posible, omite una condición sustantiva para las reglas del SIEE, los apoyos y la motivación de decisiones académicas.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 516,
      "originalId": 96,
      "sourceExam": 4,
      "situationId": "S4-28",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referente delimita de forma más directa las responsabilidades institucionales involucradas?",
      "options": [
        "Decreto 1290 de 2009, art. 11",
        "Resolución MEN 003842 de 2022, gestión académica",
        "Ley 115 de 1994, objetivos, áreas y proyectos educativos"
      ],
      "correct": 0,
      "explanation": "Este marco se relaciona de modo más directo con las reglas del SIEE, los apoyos y la motivación de decisiones académicas. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "B. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nC. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 517,
      "originalId": 97,
      "sourceExam": 4,
      "situationId": "S4-28",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué selección de soportes dejaría el vacío probatorio más importante para justificar la decisión?",
      "options": [
        "SIEE, rúbrica de área, informes de apoyo, evidencias de desempeño y actas competentes, durante la fase de evaluación definida en el cronograma de gestión de la institución.",
        "SIEE, trayectorias, informes de apoyo, evidencias de desempeño y actas competentes.",
        "Expediente contrastado de promoción sin soporte: sIEE, trayectorias, informes de apoyo, evidencias de desempeño y actas competentes, con índice y control de versiones, como parte de la respuesta elaborada tras la reunión del personal que participó en el análisis."
      ],
      "correct": 0,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "B. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de aplicar los criterios institucionales vigentes y asegurar valoración individual, apoyos y trámite de reclamaciones.\n\nC. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 518,
      "originalId": 98,
      "sourceExam": 4,
      "situationId": "S4-28",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué medida sería menos adecuada como indicador principal para rendir cuentas sobre el resultado específico del caso?",
      "options": [
        "Seguimiento desagregado por período y población de: decisiones de promoción ajustadas a criterios publicados y a evidencia individual, con indicación del período al que se refiere la propuesta de actuación y sus consecuencias.",
        "Decisiones de promoción ajustadas a criterios publicados y a evidencia individual.",
        "Reclamaciones resueltas motivadamente en los plazos establecidos, en el marco de la discusión sostenida con quienes participaron en la reunión preparatoria."
      ],
      "correct": 2,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.\n\nB. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "legalBasis": "Decreto 1290 de 2009, art. 11, compilado en el Decreto 1075 de 2015"
    },
    {
      "id": 519,
      "originalId": 99,
      "sourceExam": 4,
      "situationId": "S4-29",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se audita la documentación propuesta, ¿qué expediente exigiría la mayor subsanación?",
      "options": [
        "Expediente contrastado de seguimiento sin responsables: matriz de acciones, designaciones formales, cronograma y registros de avances, con índice y control de versiones.",
        "Matriz de acciones, designaciones formales, cronograma y registros de avances.",
        "Matriz de acciones, planes de área, cronograma y registros de avances, bajo una programación conocida por los integrantes responsables de examinar los resultados."
      ],
      "correct": 2,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nB. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de precisar responsables, entregables, fechas de corte y mecanismos de escalamiento para cada acción.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 520,
      "originalId": 100,
      "sourceExam": 4,
      "situationId": "S4-29",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué curso de acción resuelve el problema central sin desbordar las atribuciones institucionales?",
      "options": [
        "Conservar las asignaciones colectivas y publicar cada mes un consolidado de avance para estimular corresponsabilidad; con un resumen de los antecedentes que motivaron la convocatoria de los participantes.",
        "Crear un comité de seguimiento general y establecer compromisos individuales únicamente para actividades atrasadas.",
        "Precisar responsables, entregables, fechas de corte y mecanismos de escalamiento para cada acción; con anotación de las circunstancias específicas del establecimiento en la fecha de la decisión."
      ],
      "correct": 2,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la coherencia entre diagnóstico, metas, ejecución y evidencia.",
      "distractors": "A. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.\n\nB. Aunque identifica una salida posible, omite una condición sustantiva para la coherencia entre diagnóstico, metas, ejecución y evidencia.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 521,
      "originalId": 101,
      "sourceExam": 4,
      "situationId": "S4-29",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Entre las siguientes propuestas de seguimiento, ¿cuál deja una brecha de medición más relevante?",
      "options": [
        "Reducción de brechas de permanencia o aprendizaje según la prioridad formalmente definida, con anotación de las circunstancias específicas del establecimiento en la fecha de la decisión.",
        "Acciones cumplidas dentro del plazo y con evidencia sobre el total programado.",
        "Seguimiento desagregado por período y población de: acciones cumplidas dentro del plazo y con evidencia sobre el total programado."
      ],
      "correct": 0,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "B. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.\n\nC. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 522,
      "originalId": 102,
      "sourceExam": 4,
      "situationId": "S4-29",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Para orientar la motivación jurídica inicial, ¿qué marco ofrece la conexión más pertinente con los hechos?",
      "options": [
        "Resolución MEN 003842 de 2022, gestión académica",
        "Ley 115 de 1994, arts. 142-145",
        "Ley 715 de 2001, art. 10"
      ],
      "correct": 2,
      "explanation": "Este marco se relaciona de modo más directo con la coherencia entre diagnóstico, metas, ejecución y evidencia. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nB. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 523,
      "originalId": 103,
      "sourceExam": 4,
      "situationId": "S4-30",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál conjunto documental permitiría una conclusión menos sólida sobre la actuación?",
      "options": [
        "Expediente contrastado de matrícula y certificación pendiente: solicitud, barreras de acceso, información familiar y registro para apoyos educativos, con índice y control de versiones.",
        "Solicitud, barreras de aula, información familiar y registro para apoyos educativos, y presentar una explicación de su alcance ante los integrantes del órgano correspondiente.",
        "Solicitud, barreras de acceso, información familiar y registro para apoyos educativos."
      ],
      "correct": 1,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nC. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de tramitar la matrícula y activar valoración pedagógica y articulación con la entidad territorial y salud, sin convertir el diagnóstico en barrera.",
      "legalBasis": "Decreto 1421 de 2017, incorporado al Decreto 1075 de 2015"
    },
    {
      "id": 524,
      "originalId": 104,
      "sourceExam": 4,
      "situationId": "S4-30",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué alternativa es más consistente con la responsabilidad directiva frente a los hechos?",
      "options": [
        "Aceptar inscripción provisional, pero programar asistencia ordinaria después de confirmar el documento clínico de respaldo; con una comunicación dirigida a los actores mencionados en el expediente institucional.",
        "Tramitar la matrícula y activar valoración pedagógica y articulación con la entidad territorial y salud, sin convertir el diagnóstico en barrera.",
        "Ofrecer atención educativa en casa hasta que se complete la certificación y formalizar entonces la matrícula presencial."
      ],
      "correct": 1,
      "explanation": "La medida aborda directamente el hecho descrito y respeta el retiro de barreras y la participación educativa en igualdad de condiciones.",
      "distractors": "A. Aunque identifica una salida posible, omite una condición sustantiva para el retiro de barreras y la participación educativa en igualdad de condiciones.\n\nC. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.",
      "legalBasis": "Decreto 1421 de 2017, incorporado al Decreto 1075 de 2015"
    },
    {
      "id": 525,
      "originalId": 105,
      "sourceExam": 4,
      "situationId": "S4-30",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué indicador tendría menor validez para establecer si se resolvió la necesidad institucional descrita?",
      "options": [
        "Seguimiento desagregado por período y población de: días de acceso efectivo y apoyos iniciados desde la vinculación.",
        "Cumplimiento de metas individualizadas con ajustes efectivamente implementados.",
        "Días de acceso efectivo y apoyos iniciados desde la vinculación."
      ],
      "correct": 1,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.\n\nC. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "legalBasis": "Decreto 1421 de 2017, incorporado al Decreto 1075 de 2015"
    },
    {
      "id": 526,
      "originalId": 106,
      "sourceExam": 4,
      "situationId": "S4-31",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué propuesta presenta el riesgo institucional más grave, a pesar de sus aparentes ventajas operativas?",
      "options": [
        "Permitir clases en la zona no afectada mientras se consigue diagnóstico y gestionar el cambio de salón al siguiente período; en el marco de la discusión sostenida con quienes participaron en la reunión preparatoria.",
        "Examinar los soportes asociados a aula con desprendimientos, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Restringir el riesgo de manera proporcional, solicitar valoración competente y reorganizar clases de forma segura, por medio de una circular institucional y un informe posterior de resultados; como parte de la respuesta elaborada tras la reunión del personal que participó en el análisis."
      ],
      "correct": 0,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la prevención, la protección de personas y la continuidad segura del servicio.",
      "distractors": "B. La alternativa preserva un examen previo y fundamentado de aula con desprendimientos antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nC. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la prevención, la protección de personas y la continuidad segura del servicio.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 527,
      "originalId": 107,
      "sourceExam": 4,
      "situationId": "S4-31",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál formulación introduce la limitación más importante al evaluar el resultado y no solo la gestión?",
      "options": [
        "Días de exposición al riesgo y continuidad segura del aprendizaje.",
        "Seguimiento desagregado por período y población de: días de exposición al riesgo y continuidad segura del aprendizaje.",
        "Tiempo para asegurar consumo seguro y cobertura de las medidas preventivas."
      ],
      "correct": 2,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.\n\nB. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 528,
      "originalId": 108,
      "sourceExam": 4,
      "situationId": "S4-31",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué combinación de documentos sería la menos adecuada para examinar las condiciones del supuesto?",
      "options": [
        "Fotos, reportes, visitas técnicas, capacidad de espacios alternativos y cronograma.",
        "Fotos, reportes de ruta, visitas técnicas, capacidad de espacios alternativos y cronograma, en el marco de la discusión sostenida con quienes participaron en la reunión preparatoria.",
        "Expediente contrastado de aula con desprendimientos: fotos, reportes, visitas técnicas, capacidad de espacios alternativos y cronograma, con índice y control de versiones."
      ],
      "correct": 1,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de restringir el riesgo de manera proporcional, solicitar valoración competente y reorganizar clases de forma segura.\n\nC. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.",
      "legalBasis": "Resolución MEN 003842 de 2022, gestión administrativa y comunitaria; marco de gestión del riesgo aplicable"
    },
    {
      "id": 529,
      "originalId": 109,
      "sourceExam": 4,
      "situationId": "S4-32",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál criterio de seguimiento refleja mejor el problema que se pretende corregir?",
      "options": [
        "Prácticas con supervisión, cobertura de riesgos y tratamiento legítimo de datos.",
        "Problemas territoriales atendidos mediante compromisos evaluados, para atender la solicitud presentada formalmente ante la dirección de la institución.",
        "Familias acompañadas individualmente sin exposición innecesaria de datos."
      ],
      "correct": 2,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.\n\nB. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 530,
      "originalId": 110,
      "sourceExam": 4,
      "situationId": "S4-32",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referente delimita de forma más directa las responsabilidades institucionales involucradas?",
      "options": [
        "Ley 115 de 1994, arts. 142-145",
        "Decreto 459 de 2024, Alianza Familias-Escuela",
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes"
      ],
      "correct": 1,
      "explanation": "Este marco se relaciona de modo más directo con la participación significativa, la accesibilidad y el diálogo territorial. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nC. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 531,
      "originalId": 111,
      "sourceExam": 4,
      "situationId": "S4-32",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cómo debería proceder la dirección del establecimiento en este escenario?",
      "options": [
        "Informar resultados agregados y ofrecer seguimiento individual confidencial con las familias concernidas; como parte de una decisión comunicada a los equipos que resultarían directamente involucrados.",
        "Entregar listas de rendimiento únicamente a representantes elegidos, con compromiso firmado de preservar su confidencialidad.",
        "Publicar resultados nominales en reunión cerrada de padres del grado y permitir que las familias soliciten correcciones posteriores."
      ],
      "correct": 0,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la participación significativa, la accesibilidad y el diálogo territorial.",
      "distractors": "B. Aunque identifica una salida posible, omite una condición sustantiva para la participación significativa, la accesibilidad y el diálogo territorial.\n\nC. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 532,
      "originalId": 112,
      "sourceExam": 4,
      "situationId": "S4-32",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué selección de soportes dejaría el vacío probatorio más importante para justificar la decisión?",
      "options": [
        "Expediente contrastado de padres exigen ranking público: datos de desempeño, finalidad de comunicación y criterios de tratamiento de información, con índice y control de versiones.",
        "Datos de desempeño, reglas de protección de información y criterios de tratamiento de información.",
        "Datos de desempeño, finalidad de comunicación y criterios de tratamiento de información, como parte de la respuesta elaborada tras la reunión del personal que participó en el análisis."
      ],
      "correct": 1,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nC. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de informar resultados agregados y ofrecer seguimiento individual confidencial con las familias concernidas.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 533,
      "originalId": 113,
      "sourceExam": 4,
      "situationId": "S4-33",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cómo debería operacionalizarse el resultado esperado en el plan de seguimiento?",
      "options": [
        "Continuidad de atención y cumplimiento del calendario de gestión, con indicación del período al que se refiere la propuesta de actuación y sus consecuencias.",
        "Continuidad de atención y decisiones de permisos motivadas según reglas.",
        "Decisiones de permisos motivadas según reglas y asistencia a reuniones, para que el equipo responsable conozca los efectos esperados y los pasos anunciados."
      ],
      "correct": 1,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir decisiones de permisos motivadas según reglas, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir continuidad de atención, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 534,
      "originalId": 114,
      "sourceExam": 4,
      "situationId": "S4-33",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se audita la documentación propuesta, ¿qué expediente exigiría la mayor subsanación?",
      "options": [
        "Expediente contrastado de permiso y continuidad: solicitudes, normativa de permisos, carga académica y opciones de cobertura, con índice y control de versiones.",
        "Solicitudes, normativa de permisos, carga académica y opciones de cobertura.",
        "Solicitudes, planes de aula, carga académica y opciones de cobertura."
      ],
      "correct": 2,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nB. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de resolver según competencias y causales aplicables, documentando decisión y medidas pedagógicas de continuidad.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 535,
      "originalId": 115,
      "sourceExam": 4,
      "situationId": "S4-33",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Para orientar la motivación jurídica inicial, ¿qué marco ofrece la conexión más pertinente con los hechos?",
      "options": [
        "Ley 715 de 2001, art. 10",
        "Ley 115 de 1994, arts. 142-145",
        "Ley 715 de 2001, art. 10, funciones del rector"
      ],
      "correct": 2,
      "explanation": "Este marco se relaciona de modo más directo con las funciones del rector, la continuidad del servicio y las garantías del personal. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nB. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 536,
      "originalId": 116,
      "sourceExam": 4,
      "situationId": "S4-33",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál de las medidas planteadas podría producir una actuación institucional objetable por su alcance o secuencia?",
      "options": [
        "Examinar los soportes asociados a permiso y continuidad, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Conceder las solicitudes en las fechas previstas y activar después apoyos de coordinación para compensar clases faltantes; como parte de la respuesta elaborada tras la reunión del personal que participó en el análisis.",
        "Resolver según competencias y causales aplicables, documentando decisión y medidas pedagógicas de continuidad, con una verificación posterior de costos y resultados administrativos."
      ],
      "correct": 1,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para las funciones del rector, la continuidad del servicio y las garantías del personal.",
      "distractors": "A. La alternativa preserva un examen previo y fundamentado de permiso y continuidad antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.\n\nC. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta las funciones del rector, la continuidad del servicio y las garantías del personal.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 537,
      "originalId": 117,
      "sourceExam": 4,
      "situationId": "S4-34",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál es el costo por beneficiario del primer piloto?",
      "options": [
        "60.000 pesos",
        "50.000 pesos",
        "54.000 pesos"
      ],
      "correct": 0,
      "explanation": "9.000.000 / 150 = 60.000 pesos por persona.",
      "distractors": "B. Corresponde a una operación o denominador distinto del definido; no coincide con los datos.\n\nC. Confunde una magnitud con otra o realiza una agregación que altera la base de comparación.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de razonamiento cuantitativo"
    },
    {
      "id": 538,
      "originalId": 118,
      "sourceExam": 4,
      "situationId": "S4-34",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿En cuánto supera el costo unitario del primero al del segundo?",
      "options": [
        "10.000 pesos",
        "15.000 pesos",
        "3.000 pesos"
      ],
      "correct": 0,
      "explanation": "60.000 - 50.000 = 10.000 pesos por estudiante.",
      "distractors": "B. Confunde una magnitud con otra o realiza una agregación que altera la base de comparación.\n\nC. Corresponde a una operación o denominador distinto del definido; no coincide con los datos.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de razonamiento cuantitativo"
    },
    {
      "id": 539,
      "originalId": 119,
      "sourceExam": 4,
      "situationId": "S4-34",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál es el costo por beneficiario del segundo piloto?",
      "options": [
        "60.000 pesos",
        "48.000 pesos",
        "50.000 pesos"
      ],
      "correct": 2,
      "explanation": "12.000.000 / 240 = 50.000 pesos por persona.",
      "distractors": "A. Corresponde a una operación o denominador distinto del definido; no coincide con los datos.\n\nB. Confunde una magnitud con otra o realiza una agregación que altera la base de comparación.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de razonamiento cuantitativo"
    },
    {
      "id": 540,
      "originalId": 120,
      "sourceExam": 4,
      "situationId": "S4-35",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué lectura del argumento realizaría la inferencia menos justificable a partir de las pruebas disponibles?",
      "options": [
        "La simultaneidad de cambios vuelve plausible atribuir al uniforme una parte del descenso de deserción.",
        "La coincidencia temporal entre dos hechos no prueba un vínculo causal, con una constancia escrita de las razones utilizadas para orientar la actuación institucional.",
        "La afirmación relativa a causalidad en deserción requiere una comprobación complementaria antes de generalizar el efecto."
      ],
      "correct": 0,
      "explanation": "La alternativa extrapola o sustituye indebidamente la evidencia: convierte registro de actividades o ejemplos en demostración suficiente de impacto.",
      "distractors": "B. Esta alternativa se apoya en el argumento y sus límites: la lectura distingue lo sustentado por los datos de una conclusión que excede esa evidencia.\n\nC. Distingue evidencia inicial de un resultado concluyente y delimita el alcance del texto.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de lectura crítica"
    },
    {
      "id": 541,
      "originalId": 121,
      "sourceExam": 4,
      "situationId": "S4-35",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué fuente complementaria aportaría menos capacidad para contrastar la conclusión del documento?",
      "options": [
        "Series de abandono, cambios simultáneos y grupos o períodos comparables, con una constancia escrita de las razones utilizadas para orientar la actuación institucional.",
        "Registros alternativos y comparables sobre causalidad en deserción, contrastados con las condiciones iniciales.",
        "Encuestas de gusto por el uniforme y frecuencia con que se utiliza en cada sede."
      ],
      "correct": 2,
      "explanation": "La alternativa extrapola o sustituye indebidamente la evidencia: una ratificación del autor no aporta contraste independiente.",
      "distractors": "A. Esta alternativa se apoya en el argumento y sus límites: la evidencia propuesta examina directamente el salto inferencial identificado en el texto.\n\nB. Los datos externos comparables permiten examinar la inferencia expuesta sin limitarse a ratificaciones de quien redactó el informe.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de lectura crítica"
    },
    {
      "id": 542,
      "originalId": 122,
      "sourceExam": 4,
      "situationId": "S4-35",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué crítica sería menos pertinente para señalar la debilidad inferencial central del texto?",
      "options": [
        "La extrapolación de datos no comparables a un resultado institucional sobre causalidad en deserción.",
        "Atribución causal indebida desde una asociación temporal, con una constancia escrita de las razones utilizadas para orientar la actuación institucional.",
        "Extrapolación de datos urbanos a sedes rurales sin considerar matrícula."
      ],
      "correct": 2,
      "explanation": "La alternativa extrapola o sustituye indebidamente la evidencia: una definición institucional adicional no corrige la inferencia central.",
      "distractors": "A. La crítica se dirige a la inferencia y a la extensión de las conclusiones, no a cuestiones formales.\n\nB. Esta alternativa se apoya en el argumento y sus límites: el defecto señalado impide pasar con justificación suficiente de las premisas a la conclusión.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de lectura crítica"
    },
    {
      "id": 543,
      "originalId": 123,
      "sourceExam": 4,
      "situationId": "S4-36",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué fuente complementaria aportaría menos capacidad para contrastar la conclusión del documento?",
      "options": [
        "Tasa de respuesta, perfil y procedimiento de selección de participantes.",
        "Porcentaje de respuestas favorables de quienes asistieron y número de encuestas impresas.",
        "Registros alternativos y comparables sobre informe de satisfacción, contrastados con las condiciones iniciales."
      ],
      "correct": 1,
      "explanation": "La alternativa extrapola o sustituye indebidamente la evidencia: una ratificación del autor no aporta contraste independiente.",
      "distractors": "A. Esta alternativa se apoya en el argumento y sus límites: la evidencia propuesta examina directamente el salto inferencial identificado en el texto.\n\nC. Los datos externos comparables permiten examinar la inferencia expuesta sin limitarse a ratificaciones de quien redactó el informe.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de lectura crítica"
    },
    {
      "id": 544,
      "originalId": 124,
      "sourceExam": 4,
      "situationId": "S4-36",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué lectura del argumento realizaría la inferencia menos justificable a partir de las pruebas disponibles?",
      "options": [
        "El 93 % caracteriza a quienes respondieron, no automáticamente a las 800 familias.",
        "La proporción favorable permite inferir aceptación mayoritaria en las sedes con participación activa.",
        "La afirmación relativa a informe de satisfacción requiere una comprobación complementaria antes de generalizar el efecto."
      ],
      "correct": 1,
      "explanation": "La alternativa extrapola o sustituye indebidamente la evidencia: convierte registro de actividades o ejemplos en demostración suficiente de impacto.",
      "distractors": "A. Esta alternativa se apoya en el argumento y sus límites: la lectura distingue lo sustentado por los datos de una conclusión que excede esa evidencia.\n\nC. Distingue evidencia inicial de un resultado concluyente y delimita el alcance del texto.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de lectura crítica"
    },
    {
      "id": 545,
      "originalId": 125,
      "sourceExam": 4,
      "situationId": "S4-36",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué crítica sería menos pertinente para señalar la debilidad inferencial central del texto?",
      "options": [
        "La extrapolación de datos no comparables a un resultado institucional sobre informe de satisfacción, con una descripción de las condiciones que la rectoría consideró relevantes en este supuesto.",
        "Confusión entre puntos porcentuales y aumento relativo de aprobación, con registro de las decisiones tomadas durante el período de atención del asunto.",
        "Sesgo de autoselección o extrapolación sin representatividad demostrada."
      ],
      "correct": 1,
      "explanation": "La alternativa extrapola o sustituye indebidamente la evidencia: una definición institucional adicional no corrige la inferencia central.",
      "distractors": "A. La crítica se dirige a la inferencia y a la extensión de las conclusiones, no a cuestiones formales.\n\nC. Esta alternativa se apoya en el argumento y sus límites: el defecto señalado impide pasar con justificación suficiente de las premisas a la conclusión.",
      "legalBasis": "Anexo técnico de la convocatoria 2026, componente de lectura crítica"
    },
    {
      "id": 546,
      "originalId": 126,
      "sourceExam": 4,
      "situationId": "S4-37",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Si se comparan tres rutas de decisión, ¿cuál resultaría menos defendible ante una revisión de competencias y garantías?",
      "options": [
        "Aumentar la frecuencia de reuniones y exigir reportes individuales, revisando cambios de aula cuando termine el semestre.",
        "Estructurar reuniones con decisiones, responsables, productos y evaluación de resultados en enseñanza, con reuniones de seguimiento y una matriz de compromisos documentada.",
        "Examinar los soportes asociados a reuniones sin acuerdos, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables."
      ],
      "correct": 0,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para las funciones del rector, la continuidad del servicio y las garantías del personal.",
      "distractors": "B. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta las funciones del rector, la continuidad del servicio y las garantías del personal.\n\nC. La alternativa preserva un examen previo y fundamentado de reuniones sin acuerdos antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 547,
      "originalId": 127,
      "sourceExam": 4,
      "situationId": "S4-37",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Para revisar el avance dentro de un período comparable, ¿qué indicador tiene mayor pertinencia?",
      "options": [
        "Acuerdos pedagógicos implementados y evaluados respecto de los adoptados.",
        "Cumplimiento de fases y calidad de evidencias de evaluación.",
        "Evaluados respecto de los adoptados y asistencia a reuniones."
      ],
      "correct": 0,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "B. Considera una variable relacionada con el caso, pero deja sin medir acuerdos pedagógicos implementados, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir acuerdos pedagógicos implementados, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 548,
      "originalId": 128,
      "sourceExam": 4,
      "situationId": "S4-37",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "Para orientar la motivación jurídica inicial, ¿qué marco ofrece la conexión más pertinente con los hechos?",
      "options": [
        "Ley 715 de 2001, art. 10, funciones del rector",
        "Ley 115 de 1994, arts. 142-145",
        "Ley 715 de 2001, art. 10"
      ],
      "correct": 0,
      "explanation": "Este marco se relaciona de modo más directo con las funciones del rector, la continuidad del servicio y las garantías del personal. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "B. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nC. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 549,
      "originalId": 129,
      "sourceExam": 4,
      "situationId": "S4-37",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "En una revisión externa, ¿qué evidencia permitiría reconstruir con mayor rigor lo ocurrido?",
      "options": [
        "Actas, acuerdos de área, intensidad de áreas y productos de seguimiento, con indicación del período al que se refiere la propuesta de actuación y sus consecuencias.",
        "Actas, plan de estudios, planes de aula y productos de seguimiento.",
        "Actas, acuerdos de área, planes de aula y productos de seguimiento, en el marco de la discusión sostenida con quienes participaron en la reunión preparatoria."
      ],
      "correct": 2,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de estructurar reuniones con decisiones, responsables, productos y evaluación de resultados en enseñanza.",
      "distractors": "A. Esta selección es parcial: no integra planes de aula, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nB. Esta selección es parcial: no integra acuerdos de área, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 715 de 2001, art. 10; Resolución MEN 003842 de 2022"
    },
    {
      "id": 550,
      "originalId": 130,
      "sourceExam": 4,
      "situationId": "S4-38",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referencia normativa conviene revisar primero por su relación directa con el caso?",
      "options": [
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes",
        "Decreto 459 de 2024, Alianza Familias-Escuela",
        "Ley 115 de 1994, arts. 142-145"
      ],
      "correct": 1,
      "explanation": "Este marco se relaciona de modo más directo con la participación significativa, la accesibilidad y el diálogo territorial. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.\n\nC. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 551,
      "originalId": 131,
      "sourceExam": 4,
      "situationId": "S4-38",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué alternativa es más consistente con la responsabilidad directiva frente a los hechos?",
      "options": [
        "Separar aportes de finalidades comerciales y proteger derechos y datos de menores antes de cualquier acuerdo; en el marco de la discusión sostenida con quienes participaron en la reunión preparatoria.",
        "Recibir útiles y divulgar fotografías institucionales mientras se consultan autorizaciones de uso comercial a las familias.",
        "Autorizar campañas usando solo imágenes grupales y permitir al patrocinador conservar publicaciones de manera permanente."
      ],
      "correct": 0,
      "explanation": "La medida aborda directamente el hecho descrito y respeta la participación significativa, la accesibilidad y el diálogo territorial.",
      "distractors": "B. Aunque identifica una salida posible, omite una condición sustantiva para la participación significativa, la accesibilidad y el diálogo territorial.\n\nC. La alternativa sacrifica una garantía o un control necesario y no atiende íntegramente el caso.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 552,
      "originalId": 132,
      "sourceExam": 4,
      "situationId": "S4-38",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál criterio de seguimiento refleja mejor el problema que se pretende corregir?",
      "options": [
        "Apoyos recibidos sin explotación publicitaria de datos de estudiantes, con indicación del período al que se refiere la propuesta de actuación y sus consecuencias.",
        "Problemas territoriales atendidos mediante compromisos evaluados.",
        "Prácticas con supervisión, cobertura de riesgos y tratamiento legítimo de datos."
      ],
      "correct": 0,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "B. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.\n\nC. Mide una aproximación parcial o administrativa, insuficiente para establecer si ocurrió el cambio de resultado requerido.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 553,
      "originalId": 133,
      "sourceExam": 4,
      "situationId": "S4-38",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál conjunto documental permitiría una conclusión menos sólida sobre la actuación?",
      "options": [
        "Expediente contrastado de comercio vecino y publicidad: propuesta, finalidades publicitarias, autorizaciones procedentes y riesgos de exposición, con índice y control de versiones.",
        "Propuesta, finalidades publicitarias, autorizaciones procedentes y riesgos de exposición.",
        "Propuesta, planes de área, autorizaciones procedentes y riesgos de exposición."
      ],
      "correct": 2,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.\n\nB. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de separar aportes de finalidades comerciales y proteger derechos y datos de menores antes de cualquier acuerdo.",
      "legalBasis": "Decreto 459 de 2024, adicionado al Decreto 1075 de 2015; Ley 115 de 1994"
    },
    {
      "id": 554,
      "originalId": 134,
      "sourceExam": 4,
      "situationId": "S4-39",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué iniciativa sería más difícil de justificar si se confronta con las obligaciones rectorales pertinentes?",
      "options": [
        "Articular objetivos de ciencia con gestión preventiva, recursos idóneos y evaluación de riesgos, previa discusión con los representantes de las sedes involucradas.",
        "Examinar los soportes asociados a resultados de laboratorio sin seguridad, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Mantener el programa experimental con una jornada previa de sensibilización, aplazando el diagnóstico técnico de los reactivos; con referencia explícita al contexto escolar particular que originó la controversia."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la correspondencia entre objetivos curriculares, apoyos didácticos y aprendizaje.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la correspondencia entre objetivos curriculares, apoyos didácticos y aprendizaje.\n\nB. La alternativa preserva un examen previo y fundamentado de resultados de laboratorio sin seguridad antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 555,
      "originalId": 135,
      "sourceExam": 4,
      "situationId": "S4-39",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Cuál formulación introduce la limitación más importante al evaluar el resultado y no solo la gestión?",
      "options": [
        "Seguimiento desagregado por período y población de: experiencias desarrolladas con controles de seguridad y logro científico previsto.",
        "Progreso de aprendizaje por condición de acceso y sede, con registro de las decisiones tomadas durante el período de atención del asunto, para que el equipo responsable conozca los efectos esperados y los pasos anunciados.",
        "Experiencias desarrolladas con controles de seguridad y logro científico previsto."
      ],
      "correct": 1,
      "explanation": "La medida omite un componente importante del resultado principal: es un dato de gestión potencialmente útil, pero no observa directamente el resultado de interés.",
      "distractors": "A. Esta formulación conserva las variables sustantivas de resultado del caso y añade unidades comparables por período y población.\n\nC. Sí observa el resultado buscado: el indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 556,
      "originalId": 136,
      "sourceExam": 4,
      "situationId": "S4-39",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué combinación de documentos sería la menos adecuada para examinar las condiciones del supuesto?",
      "options": [
        "Inventario de materiales, fichas de seguridad, planes de clase y evaluación de riesgos.",
        "Inventario de materiales, planes de área, planes de clase y evaluación de riesgos.",
        "Expediente contrastado de resultados de laboratorio sin seguridad: inventario de materiales, fichas de seguridad, planes de clase y evaluación de riesgos, con índice y control de versiones."
      ],
      "correct": 1,
      "explanation": "Hay un vacío significativo en las fuentes ofrecidas: incluye indicios generales, pero carece de la documentación específica que discrimina el caso.",
      "distractors": "A. Incluye los datos centrales del hecho: estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de articular objetivos de ciencia con gestión preventiva, recursos idóneos y evaluación de riesgos.\n\nC. El expediente contiene los soportes necesarios y conserva la trazabilidad para auditar su interpretación.",
      "legalBasis": "Resolución MEN 003842 de 2022, competencias de gestión académica; Ley 115 de 1994"
    },
    {
      "id": 557,
      "originalId": 137,
      "sourceExam": 4,
      "situationId": "S4-40",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "De las siguientes actuaciones, ¿cuál requeriría una corrección prioritaria por comprometer el procedimiento o la garantía central del caso?",
      "options": [
        "Asignar credenciales individuales, perfiles de acceso y registro de modificaciones con control periódico, con un reporte al finalizar el siguiente período institucional.",
        "Examinar los soportes asociados a contraseña compartida, deliberar en las instancias competentes y precisar antes de ejecutar la medida las responsabilidades y garantías aplicables.",
        "Cambiar periódicamente la clave común y exigir una declaración escrita a quien realice cada modificación importante."
      ],
      "correct": 2,
      "explanation": "Esta actuación resulta objetable en este caso: aunque identifica una salida posible, omite una condición sustantiva para la finalidad legítima, la calidad de datos y los controles de acceso.",
      "distractors": "A. Es una ruta defendible: la medida aborda directamente el hecho descrito y respeta la finalidad legítima, la calidad de datos y los controles de acceso.\n\nB. La alternativa preserva un examen previo y fundamentado de contraseña compartida antes de autorizar la ejecución; su alcance requiere precisar las decisiones posteriores.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 558,
      "originalId": 138,
      "sourceExam": 4,
      "situationId": "S4-40",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué conjunto de evidencias permitiría sustentar de manera más sólida la decisión?",
      "options": [
        "Bitácoras, roles, sistema de permisos y operaciones de matrícula.",
        "Bitácoras, soportes de matrícula, sistema de permisos y operaciones de matrícula.",
        "Bitácoras, roles, permisos reales del sistema y operaciones de matrícula."
      ],
      "correct": 0,
      "explanation": "Estos soportes permiten verificar los hechos, reconstruir decisiones y evaluar la pertinencia de asignar credenciales individuales, perfiles de acceso y registro de modificaciones con control periódico.",
      "distractors": "B. Esta selección es parcial: no integra roles, evidencia necesaria para resolver la incertidumbre específica del caso.\n\nC. Esta selección es parcial: no integra sistema de permisos, evidencia necesaria para resolver la incertidumbre específica del caso.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 559,
      "originalId": 139,
      "sourceExam": 4,
      "situationId": "S4-40",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué observación sería más informativa al rendir cuentas sobre este caso?",
      "options": [
        "Publicaciones conformes a reglas de protección y sin exposición innecesaria.",
        "Cambios de información atribuibles y autorizados según perfiles, para atender la solicitud presentada formalmente ante la dirección de la institución.",
        "Errores y efectos diferenciales del modelo junto con eficacia de apoyos humanos."
      ],
      "correct": 1,
      "explanation": "El indicador corresponde al resultado sustantivo buscado en el caso, más allá de contar actividades, recursos o percepciones.",
      "distractors": "A. Considera una variable relacionada con el caso, pero deja sin medir cambios de información atribuibles, componente esencial del resultado propuesto.\n\nC. Considera una variable relacionada con el caso, pero deja sin medir cambios de información atribuibles, componente esencial del resultado propuesto.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    },
    {
      "id": 560,
      "originalId": 140,
      "sourceExam": 4,
      "situationId": "S4-40",
      "competency": "Gestión integral (sin clasificación en el documento)",
      "text": "¿Qué referente delimita de forma más directa las responsabilidades institucionales involucradas?",
      "options": [
        "Ley 1098 de 2006, protección integral de niños, niñas y adolescentes",
        "Decreto 459 de 2024, Alianza Familias-Escuela",
        "Ley 1581 de 2012, tratamiento y protección de datos personales"
      ],
      "correct": 2,
      "explanation": "Este marco se relaciona de modo más directo con la finalidad legítima, la calidad de datos y los controles de acceso. La referencia debe interpretarse junto con las demás disposiciones aplicables.",
      "distractors": "A. Regula un componente educativo distinto, sin delimitar directamente la decisión principal de este supuesto.\n\nB. Puede ser relevante para otros asuntos de la institución, pero no es el punto de partida específico aquí.",
      "legalBasis": "Ley 1581 de 2012, protección de datos; Resolución MEN 003842 de 2022"
    }
  ]
};
